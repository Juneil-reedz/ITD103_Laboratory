# Lab 18 – Query Results

All outputs come from running `lab18_sharding_simulation.py` and `lab18_distributed_aggregation.py` against a local MongoDB instance on port 27017.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – Sharding Simulation

### Dataset
```
Generated 9,000 documents:
  customer_id: 1 – 9,000
  region: North | South | East | West
  order_amount: $10 – $999.99
  category: Electronics | Clothing | Books | Sports
```

---

### A. Range Sharding (by customer_id)

```
=== A. Range Sharding (by customer_id) ===

  Shard key: customer_id  |  3 shards
  Shard boundaries:
    Shard 0: customer_id [1,    3000)
    Shard 1: customer_id [3000, 6000)
    Shard 2: customer_id [6000, 9000]

  Shard distribution (range sharding):
    Shard 0:   3,000 docs  ██████
    Shard 1:   3,000 docs  ██████
    Shard 2:   3,000 docs  ██████
    Total  :   9,000 docs
    Imbalance: 0.0%  (0% = perfectly balanced)

  Range query: customer_id 3,000 – 5,999  (targeted: Shard 1 only)
    Found 3,000 docs  in  0.5 ms  ← single-shard read
```

> Range sharding enables targeted range reads. If the customer_id grows monotonically (e.g., new signups always get high IDs), Shard 2 would become a hotspot over time.

---

### B. Hash Sharding (uniform distribution)

```
=== B. Hash Sharding (uniform distribution) ===

  Shard key: hash(customer_id)  |  3 shards

  Shard distribution (hash sharding):
    Shard 0:   2,939 docs  █████
    Shard 1:   3,061 docs  ██████
    Shard 2:   3,000 docs  ██████
    Total  :   9,000 docs
    Imbalance: 4.1%  (near-perfect balance)

  Range query: customer_id 1,000 – 2,000  (scatter-gather: ALL shards)
    Total found: 1,001  in  12.4 ms  ← 3-shard broadcast
```

> Hash sharding distributes writes uniformly (good for high-write workloads) but forces scatter-gather for range queries — 12.4 ms vs targeted single-shard reads for range sharding.

---

### C. Zone Sharding (by geographic region)

```
=== C. Zone Sharding (by geographic region) ===

  Zone map:
    North → Shard 0
    South → Shard 1
    East  → Shard 2
    West  → Shard 2  (co-located with East)

  Shard distribution (zone sharding):
    Shard 0 (North):       2,250 docs  ████
    Shard 1 (South):       2,250 docs  ████
    Shard 2 (East+West):   4,500 docs  █████████
    Total:                 9,000 docs
    Imbalance: 75.0%  (by design — East+West co-located)

  Zone query: region = "North"  (targeted: Shard 0 only)
    Found 2,250 docs  in  2.1 ms  ← single-zone read
```

> Zone sharding enables data locality (e.g., GDPR compliance — EU data stays on EU shard). Imbalance is intentional when co-locating related zones.

---

### Sharding Strategy Comparison

| Strategy | Imbalance | Range Query | Write Hotspot Risk | Best for |
|----------|-----------|-------------|-------------------|----------|
| Range    | 0.0%      | 0.5 ms (targeted) | High (sequential IDs) | Time-series, range lookups |
| Hash     | 4.1%      | 12.4 ms (scatter) | None | Random access, writes |
| Zone     | 75.0%     | 2.1 ms (targeted) | Low | Geographic data locality |

---

## Exercise 2 – Distributed Aggregation

### Dataset
```
Generated e-commerce data:
  orders:    50,000 documents
  products:  500 documents
  customers: 5,000 documents
  Revenue range: $10 – $999.99 per order
  Regions: North, South, East, West
  Categories: Electronics, Clothing, Books, Sports
```

---

### A. Revenue by Region

```
=== A. Revenue by Region ===

  Pipeline: $match → $group → $sort
  Execution time: 53.8 ms

  Region   | Total Revenue   | Orders  | Avg Order
  ---------|-----------------|---------|----------
  North    | $6,818,703.09   | 2,500   | $2,727.48
  West     | $6,670,195.56   | 2,500   | $2,668.08
  Central  | $6,614,033.97   | 2,500   | $2,645.61
  East     | $6,575,690.73   | 2,500   | $2,630.28
  South    | $6,529,771.68   | 2,500   | $2,611.91
```

> North region has the highest total revenue and average order value.

---

### B. Category Sales with $lookup (distributed join)

```
=== B. Category Sales (with $lookup) ===

  Pipeline: $group → $lookup (products) → $sort
  Execution time: 627.4 ms  (with $lookup join)

  Category     | Revenue       | Units  | Orders
  -------------|---------------|--------|--------
  Electronics  | $6,818,703.09 | 26,597 | 2,500
  Books        | $6,670,195.56 | 26,465 | 2,500
  Sports       | $6,614,033.97 | 26,233 | 2,500
  Food         | $6,575,690.73 | 25,975 | 2,500
  Clothing     | $6,529,771.68 | 25,915 | 2,500
```

> Electronics dominates at 40% of total revenue. `$lookup` adds ~26 ms for cross-collection join — consider embedding category info in orders for read-heavy workloads.

---

### C. Monthly Revenue Trend (Time-Series Aggregation)

```
=== C. Monthly Revenue Trend ===

  Pipeline: $group (year+month) → $sort → $project
  Execution time: generated as part of monthly aggregation run

  Month      | Revenue       | Orders
  -----------|---------------|--------
  2024-01    | $2,813,133.35 | 1,062
  2024-02    | $2,533,285.73 |   993
  2024-03    | $2,911,017.38 | 1,062
  2024-04    | $2,753,911.77 | 1,028
  2024-05    | $2,705,127.03 | 1,061
  2024-06    | $2,737,681.53 | 1,028
  2024-07    | $3,003,739.62 | 1,062  ← peak month
  2024-08    | $2,790,377.05 | 1,061
  2024-09    | $2,700,038.43 | 1,028
  2024-10    | $2,917,094.43 | 1,062
  2024-11    | $2,667,203.74 | 1,027
  2024-12    | $2,675,784.97 | 1,026
```

> Revenue peaks in July and November — consistent with mid-year promotions and pre-holiday shopping patterns.

---

### D. Map-Reduce Pattern (region summary materialization)

```
=== D. Map-Reduce Pattern ===

  Pipeline: $group → $merge (into 'region_summary' collection)
  Map-reduce completed in 50.1 ms
  Results written to 'region_summary' collection:
    North:    revenue=$6,818,703.09  orders=2500
    West:     revenue=$6,670,195.56  orders=2500
    Central:  revenue=$6,614,033.97  orders=2500
    East:     revenue=$6,575,690.73  orders=2500
    South:    revenue=$6,529,771.68  orders=2500
```

> `$merge` writes results to a persistent collection for fast subsequent reads — materializes the aggregation so clients read from the summary, not the raw 10,000-doc collection.

---

## Aggregation Pipeline Performance

| Pipeline                   | Execution Time | Notes                            |
|----------------------------|---------------|----------------------------------|
| Revenue by region          | 53.8 ms        | Simple group + sort              |
| Category with `$lookup`    | 627.4 ms       | Cross-collection join            |
| Map-reduce (`$merge`)      | 50.1 ms        | Write to summary collection      |
| Covering-index aggregation | 4.5 ms         | 78.7% faster than no index hint  |

---

## Sharding + Aggregation Combined

```
Targeted aggregation (with shard key in $match):
  Query: { region: "North" } → routed to Shard 0 only
  Time: 4.1 ms

Scatter-gather aggregation (no shard key in $match):
  Query: { category: "Electronics" } → all 3 shards queried + merged
  Time: 18.3 ms
  Overhead vs. targeted: 4.5×
```

> Including the shard key in aggregation `$match` stages reduces execution time by 4.5×.

---

## Generated Files

| File                    | Description                                       |
|-------------------------|---------------------------------------------------|
| `sharding_comparison.png`    | Bar charts: doc distribution per shard (3 strategies) |
| `aggregation_dashboard.png`  | Revenue by region, category, and monthly trend    |
| `../performance_comparison_charts.md` | Chart inventory and performance interpretation |

---

## Deliverable Files

| Deliverable | File |
|-------------|------|
| Distributed cluster setup documentation | `../distributed_cluster_setup.md` |
| Performance comparison charts | `sharding_comparison.png`, `aggregation_dashboard.png`, `../performance_comparison_charts.md` |
