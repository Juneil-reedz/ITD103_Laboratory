# Lab 12 – Performance Optimization Report

## Architecture Under Test

| Component | Port | Responsibility | Data Source |
|-----------|------|----------------|-------------|
| Gateway | `4000` | Federates all subgraphs into one GraphQL API | Apollo Gateway |
| books-service | `4001` | Owns `Book` entity and catalog queries | MongoDB `library_books` |
| users-service | `4002` | Owns `User` entity and graph recommendations | Neo4j |
| loans-service | `4003` | Owns `Loan` entity and borrowing workflow | MongoDB `library_loans` |

## Query Performance Characteristics

| Operation | Services Used | Expected Cost |
|-----------|---------------|---------------|
| `addBook` | books-service | Low: single MongoDB insert |
| `registerUser` | users-service | Low: single Neo4j node create |
| `createLoan` | loans-service | Low: single MongoDB insert |
| `loans { user book }` | gateway, loans, users, books | Medium: gateway resolves `Loan`, then federates `User` and `Book` references |
| `searchBooks` | books-service | Medium: regex scan unless indexed/search optimized |
| `recommendedBooks` | users-service, books-service | Medium to high: Neo4j traversal plus federated book entity resolution |

## Current Optimizations

| Optimization | Location | Benefit |
|--------------|----------|---------|
| Federation keys with `@key(fields: "id")` | `Book`, `User`, `Loan` types | Lets the gateway resolve entities by ID across services |
| Entity reference resolvers | `__resolveReference` in services | Allows cross-service joins without duplicating full records |
| Targeted service ownership | All services | Keeps each service responsible for its own data model |
| Gateway auth forwarding | `gateway/src/server.js` | Sends authenticated user context to downstream services |

## Recommended Database Indexes

Create these indexes before using larger datasets.

### MongoDB Books

```javascript
use library_books
db.books.createIndex({ isbn: 1 }, { unique: true })
db.books.createIndex({ title: "text", author: "text", genre: "text" })
db.books.createIndex({ genre: 1 })
```

### MongoDB Loans

```javascript
use library_loans
db.loans.createIndex({ userId: 1 })
db.loans.createIndex({ bookId: 1 })
db.loans.createIndex({ returnedAt: 1, dueDate: 1 })
```

### Neo4j Users

```cypher
CREATE CONSTRAINT user_id IF NOT EXISTS FOR (u:User) REQUIRE u.id IS UNIQUE;
CREATE INDEX user_email IF NOT EXISTS FOR (u:User) ON (u.email);
```

## Measurement Method

Use these checks while testing:

| Check | How To Measure |
|-------|----------------|
| Gateway startup | Time from `npm start` to `Gateway ready` |
| Single-service latency | Run `searchBooks` directly on `:4001/graphql`, compare gateway `:4000/graphql` |
| Federated latency | Run `loans { user book }` through gateway |
| Neo4j traversal cost | Prefix recommendation Cypher with `PROFILE` in Neo4j Browser |
| MongoDB query plans | Use `.explain("executionStats")` for search and loan queries |

## Optimization Opportunities

| Area | Improvement |
|------|-------------|
| Book search | Replace regex search with MongoDB text index or Atlas Search for large catalogs |
| Loan creation | Validate book availability and update available copies in a coordinated workflow |
| Cross-service entity resolution | Batch repeated entity reference lookups if large list queries cause duplicate requests |
| Gateway configuration | Use environment variables for service URLs in deployment environments |
| Neo4j recommendations | Add constraints and indexes on `User.id`, then review traversal plans with `PROFILE` |

## Conclusion

The Lab 12 architecture is suitable for demonstrating Apollo Federation across three services. The main performance risk is cross-service fan-out from federated queries such as `loans { user book }`. For larger data volumes, add the recommended indexes, measure query plans, and optimize book search and repeated entity resolution.
