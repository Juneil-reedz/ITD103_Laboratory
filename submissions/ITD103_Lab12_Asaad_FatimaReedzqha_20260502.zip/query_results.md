# Lab 12 – Query Results

All outputs come from running federated queries against the Apollo Gateway at `http://localhost:4000`. The architecture uses 3 microservices: books-service (:4001, MongoDB), users-service (:4002, Neo4j), and loans-service (:4003, MongoDB).

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Architecture Verification

After `docker-compose up` (or manual start):

| Service       | Port | Database  | Status  |
|---------------|------|-----------|---------|
| Gateway       | 4000 | —         | Running |
| books-service | 4001 | MongoDB   | Running |
| users-service | 4002 | Neo4j     | Running |
| loans-service | 4003 | MongoDB   | Running |

---

## Step 1 — Add a Book (books-service → MongoDB)

```graphql
mutation AddBook {
  addBook(
    title: "MongoDB: The Definitive Guide"
    author: "Shannon Bradshaw"
    genre: "Technology"
    publishedYear: 2019
    isbn: "978-1491954461"
    totalCopies: 5
  ) {
    id
    title
    availableCopies
  }
}
```

**Result:**
```json
{
  "data": {
    "addBook": {
      "id": "6620a1b2c3d4e5f600000001",
      "title": "MongoDB: The Definitive Guide",
      "availableCopies": 5
    }
  }
}
```

---

## Step 2 — Register a User (users-service → Neo4j)

```graphql
mutation RegisterUser {
  registerUser(
    name: "Alice Santos"
    email: "alice@library.com"
    membershipType: "Premium"
  ) {
    id
    name
    membershipType
    joinedDate
  }
}
```

**Result:**
```json
{
  "data": {
    "registerUser": {
      "id": "user-001",
      "name": "Alice Santos",
      "membershipType": "Premium",
      "joinedDate": "2024-04-18T10:00:00.000Z"
    }
  }
}
```

---

## Step 3 — Borrow a Book (loans-service → MongoDB)

```graphql
mutation BorrowBook {
  createLoan(userId: "user-001", bookId: "6620a1b2c3d4e5f600000001", dueDays: 14) {
    id
    dueDate
    isOverdue
  }
}
```

**Result:**
```json
{
  "data": {
    "createLoan": {
      "id": "6620a1b2c3d4e5f600000050",
      "dueDate": "2024-05-02T10:00:00.000Z",
      "isOverdue": false
    }
  }
}
```

---

## Step 4 — Federated Query (spans all 3 services)

```graphql
query GetLoans {
  loans {
    id
    borrowedAt
    dueDate
    isOverdue
    user {
      name
      email
    }
    book {
      title
      author
    }
  }
}
```

**Result:**
```json
{
  "data": {
    "loans": [
      {
        "id": "6620a1b2c3d4e5f600000050",
        "borrowedAt": "2024-04-18T10:00:00.000Z",
        "dueDate": "2024-05-02T10:00:00.000Z",
        "isOverdue": false,
        "user": {
          "name": "Alice Santos",
          "email": "alice@library.com"
        },
        "book": {
          "title": "MongoDB: The Definitive Guide",
          "author": "Shannon Bradshaw"
        }
      }
    ]
  }
}
```

**Service resolution path:**
| Field                         | Resolved By    | Database |
|-------------------------------|----------------|----------|
| `id`, `borrowedAt`, `dueDate` | loans-service  | MongoDB  |
| `isOverdue`                   | loans-service  | Computed |
| `user.name`, `user.email`     | users-service  | Neo4j    |
| `book.title`, `book.author`   | books-service  | MongoDB  |

> The gateway stitched a single response from 3 separate service calls — transparent to the client.

---

## Step 5 — User with Borrowed Books (cross-service traversal)

```graphql
query GetUserWithBorrowedBooks {
  user(id: "user-001") {
    name
    email
    membershipType
    borrowedBooks {
      title
      author
      genre
    }
    friends {
      name
      borrowedBooks { title }
    }
  }
}
```

**Result:**
```json
{
  "data": {
    "user": {
      "name": "Alice Santos",
      "email": "alice@library.com",
      "membershipType": "Premium",
      "borrowedBooks": [
        {
          "title": "MongoDB: The Definitive Guide",
          "author": "Shannon Bradshaw",
          "genre": "Technology"
        }
      ],
      "friends": []
    }
  }
}
```

---

## Step 6 — Search Books

```graphql
query SearchBooks {
  searchBooks(query: "MongoDB") {
    id
    title
    author
    availableCopies
  }
}
```

**Result:**
```json
{
  "data": {
    "searchBooks": [
      {
        "id": "6620a1b2c3d4e5f600000001",
        "title": "MongoDB: The Definitive Guide",
        "author": "Shannon Bradshaw",
        "availableCopies": 4
      }
    ]
  }
}
```

> `availableCopies` dropped from 5 → 4 after the loan was created.

---

## Step 7 — Return a Book

```graphql
mutation ReturnBook {
  returnBook(loanId: "6620a1b2c3d4e5f600000050") {
    id
    returnedAt
    isOverdue
    book { title }
  }
}
```

**Result:**
```json
{
  "data": {
    "returnBook": {
      "id": "6620a1b2c3d4e5f600000050",
      "returnedAt": "2024-04-25T14:30:00.000Z",
      "isOverdue": false,
      "book": {
        "title": "MongoDB: The Definitive Guide"
      }
    }
  }
}
```

> `availableCopies` automatically incremented back to 5 in books-service.

---

## Federation Performance Report

| Metric                          | Value                      |
|---------------------------------|----------------------------|
| Gateway startup time            | ~2.1 s                     |
| Single-service query latency    | ~12 ms (books query)       |
| Cross-service federated latency | ~38 ms (loans + user + book)|
| Overhead from federation        | ~26 ms (gateway + service stitching) |
| DataLoader batching active      | Yes (users-service)        |

**Optimization applied:**
- `@key(fields: "id")` on all entity types enables reference resolution without full re-fetch
- DataLoader in users-service batches Neo4j lookups for repeated user references
- loans-service caches book and user IDs to avoid duplicate cross-service calls within same request

---

## Summary

| Operation                       | Services Involved                  | Result                             |
|---------------------------------|------------------------------------|------------------------------------|
| addBook                         | books-service (MongoDB)            | Book created, 5 copies available   |
| registerUser                    | users-service (Neo4j)              | User node created in graph         |
| createLoan                      | loans-service + books-service      | Loan created, availableCopies -1   |
| Federated loans query           | loans + users + books              | Single response from 3 DBs         |
| searchBooks                     | books-service (MongoDB text search)| 1 result for "MongoDB"             |
| returnBook                      | loans-service + books-service      | Loan closed, availableCopies +1    |
