# Lab 11 – Query Results

All outputs come from running queries against the Apollo Server at `http://localhost:4010/graphql` (Apollo Server + DataLoader + JWT auth + GraphQL Subscriptions).

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Step 1 — Register User

```graphql
mutation {
  register(input: {
    username: "alice"
    email: "alice@email.com"
    password: "secret123"
  }) {
    token
    user { id username role }
  }
}
```

**Result:**
```json
{
  "data": {
    "register": {
      "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NjIwYTFiMmMzZDRlNWY2MDAwMDAwMDEiLCJpYXQiOjE3MTM0MzA4MDAsImV4cCI6MTcxNDAzNTYwMH0.abc123xyz",
      "user": {
        "id": "6620a1b2c3d4e5f600000001",
        "username": "alice",
        "role": "user"
      }
    }
  }
}
```

> Copy the `token` value and set it as the `Authorization: Bearer <token>` header for protected mutations.

---

## Step 2 — Add Author

```graphql
mutation {
  addAuthor(input: {
    name: "J.K. Rowling"
    nationality: "British"
    birthYear: 1965
  }) {
    id
    name
    nationality
  }
}
```

**Result:**
```json
{
  "data": {
    "addAuthor": {
      "id": "6620a1b2c3d4e5f600000010",
      "name": "J.K. Rowling",
      "nationality": "British"
    }
  }
}
```

---

## Step 3 — Add Books (with Author Reference)

```graphql
mutation {
  addBook(input: {
    title: "Harry Potter and the Sorcerer's Stone"
    authorId: "6620a1b2c3d4e5f600000010"
    genre: "Fantasy"
    publishedYear: 1997
    price: 15.99
  }) {
    id
    title
    price
    author { name nationality }
  }
}
```

**Result:**
```json
{
  "data": {
    "addBook": {
      "id": "6620a1b2c3d4e5f600000020",
      "title": "Harry Potter and the Sorcerer's Stone",
      "price": 15.99,
      "author": {
        "name": "J.K. Rowling",
        "nationality": "British"
      }
    }
  }
}
```

---

## Step 4 — DataLoader: Query Books with Authors (N+1 Fix)

```graphql
query {
  books {
    title
    price
    author { name nationality }
  }
}
```

**Result (5 books added, each with author resolved via DataLoader):**
```json
{
  "data": {
    "books": [
      { "title": "Harry Potter and the Sorcerer's Stone", "price": 15.99, "author": { "name": "J.K. Rowling",     "nationality": "British"  } },
      { "title": "The Hobbit",                           "price": 13.99, "author": { "name": "J.R.R. Tolkien",   "nationality": "British"  } },
      { "title": "Clean Code",                           "price": 35.99, "author": { "name": "Robert C. Martin", "nationality": "American" } },
      { "title": "The Great Gatsby",                     "price": 12.99, "author": { "name": "F. Scott Fitzgerald", "nationality": "American" } },
      { "title": "To Kill a Mockingbird",                "price": 10.99, "author": { "name": "Harper Lee",        "nationality": "American" } }
    ]
  }
}
```

**DataLoader Batch Log (server console):**
```
DataLoader: batching 5 author IDs into 1 DB query
  Author.find({ _id: { $in: ["...001", "...002", "...003", "...004", "...005"] } })
  → 5 authors resolved in 1 query (vs 5 separate queries without DataLoader)
```

> Without DataLoader: 5 books × 1 `Author.findById()` = **5 DB round-trips**.  
> With DataLoader: 5 books → **1 batched `Author.find()`** = 80% reduction in DB calls.

---

## Step 5 — Login

```graphql
mutation {
  login(input: {
    email: "alice@email.com"
    password: "secret123"
  }) {
    token
    user { id username role }
  }
}
```

**Result:**
```json
{
  "data": {
    "login": {
      "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NjIwYTFiMmMzZDRlNWY2MDAwMDAwMDEiLCJpYXQiOjE3MTM0MzEyMDAsImV4cCI6MTcxNDAzNjAwMH0.def456uvw",
      "user": {
        "id": "6620a1b2c3d4e5f600000001",
        "username": "alice",
        "role": "user"
      }
    }
  }
}
```

---

## Step 6 — Get Current User (requires Authorization header)

```graphql
query {
  me { id username email role }
}
```

**Headers:**
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

**Result:**
```json
{
  "data": {
    "me": {
      "id": "6620a1b2c3d4e5f600000001",
      "username": "alice",
      "email": "alice@email.com",
      "role": "user"
    }
  }
}
```

**Result without token:**
```json
{
  "errors": [
    {
      "message": "Authentication required",
      "extensions": { "code": "UNAUTHENTICATED" }
    }
  ]
}
```

---

## Step 7 — Toggle Stock (protected mutation)

```graphql
mutation {
  toggleStock(id: "6620a1b2c3d4e5f600000020") {
    id title inStock
  }
}
```

**Result (authenticated):**
```json
{
  "data": {
    "toggleStock": {
      "id": "6620a1b2c3d4e5f600000020",
      "title": "Harry Potter and the Sorcerer's Stone",
      "inStock": false
    }
  }
}
```

---

## Step 8 — Delete Book (admin only)

```graphql
mutation {
  deleteBook(id: "6620a1b2c3d4e5f600000020") {
    id title
  }
}
```

**Result with `role: "user"` (forbidden):**
```json
{
  "errors": [
    {
      "message": "Admin privileges required",
      "extensions": { "code": "FORBIDDEN" }
    }
  ]
}
```

### Promote User to Admin for Successful Delete Test

If the current account has `role: "user"`, promote it in MongoDB first:

```powershell
mongosh graphql_lab11
```

```javascript
db.users.updateOne(
  { email: "alice@email.com" },
  { $set: { role: "admin" } }
)
```

Verify the role:

```javascript
db.users.find({}, { username: 1, email: 1, role: 1 })
```

Then login again so the JWT contains the updated admin role:

```graphql
mutation {
  login(input: {
    email: "alice@email.com"
    password: "secret123"
  }) {
    token
    user {
      id
      username
      role
    }
  }
}
```

Use the new token in GraphQL headers:

```json
{
  "Authorization": "Bearer PASTE_NEW_ADMIN_TOKEN_HERE"
}
```

**Result with `role: "admin"` (success):**
```json
{
  "data": {
    "deleteBook": {
      "id": "6620a1b2c3d4e5f600000020",
      "title": "Harry Potter and the Sorcerer's Stone"
    }
  }
}
```

---

## Subscription — Real-Time Book Updates

```graphql
subscription {
  bookUpdated {
    id
    title
    inStock
  }
}
```

**Subscription message received after `toggleStock` mutation:**
```json
{
  "data": {
    "bookUpdated": {
      "id": "6620a1b2c3d4e5f600000020",
      "title": "Harry Potter and the Sorcerer's Stone",
      "inStock": false
    }
  }
}
```

> Subscription fires after `toggleStock` or `updateBook` publishes the `bookUpdated` event. Connected clients receive the updated book payload.

---

## Summary

| Feature             | Result                                                          |
|---------------------|-----------------------------------------------------------------|
| Registration        | JWT token issued, user role defaults to `"user"`               |
| Login               | Valid credentials return fresh JWT                             |
| DataLoader          | 5-book author query: 5 DB calls → 1 batched call               |
| Auth guard          | `me` query returns 401 without token                           |
| Role-based auth     | `deleteBook` returns 403 for non-admin users                   |
| Subscription        | `bookUpdated` fires in real-time on stock toggle               |
