# Lab 4: Advanced MQL Queries

## Objectives
- Master complex query operators
- Implement text search
- Work with geospatial queries

## Files
| File | Description |
|------|-------------|
| `part_a_import.sh` | Import `restaurants.json` into MongoDB |
| `exercise1_array_operators.js` | `$all`, `$size`, `$elemMatch`, `$addToSet`, `$push`, `$pull` |
| `exercise2_text_search.js` | Text index creation, `$text` search, regex queries |
| `exercise3_geospatial.js` | `2dsphere` index, `$near`, `$geoWithin`, `$box`, `$center` |
| `query_results.md` | Expected output for all exercises with explanations |

---

## Step 1 – Import the Dataset

> **Note:** `mongoimport` requires the MongoDB Database Tools package. If it is not installed, use the `insertMany` method below instead.

### Option A — mongoimport (if installed)

Open **Git Bash** or **PowerShell** from `C:\ITD103` and run:

```bash
mongoimport --db food --collection restaurants --file itd103-labs/datasets/restaurants.json --jsonArray
```

Expected output:
```
connected to: mongodb://localhost/
10 document(s) imported successfully into food.restaurants
```

### Option B — insertMany inside mongosh (no extra tools needed)

Open mongosh, then run:

```bash
mongosh
```

```js
use food

db.restaurants.insertMany([
  { "_id": 1, "name": "Morris Park Bake Shop", "cuisine": ["Bakery", "American"], "address": { "street": "1007 Morris Park Ave", "borough": "Bronx", "zipcode": "10462", "coord": [-73.856077, 40.848447] }, "grades": [ { "date": "2024-03-01", "grade": "A", "score": 15 }, { "date": "2023-09-15", "grade": "A", "score": 18 }, { "date": "2023-01-22", "grade": "B", "score": 25 } ] },
  { "_id": 2, "name": "Wendy'S", "cuisine": ["Hamburgers", "American"], "address": { "street": "469 Flatbush Avenue", "borough": "Brooklyn", "zipcode": "11225", "coord": [-73.961704, 40.662942] }, "grades": [ { "date": "2024-01-10", "grade": "A", "score": 8 }, { "date": "2023-06-05", "grade": "A", "score": 11 }, { "date": "2022-11-20", "grade": "A", "score": 9 } ] },
  { "_id": 3, "name": "Golden Dragon", "cuisine": ["Chinese", "Thai"], "address": { "street": "58 W 48th St", "borough": "Manhattan", "zipcode": "10036", "coord": [-73.979681, 40.757552] }, "grades": [ { "date": "2024-02-14", "grade": "A", "score": 13 }, { "date": "2023-08-30", "grade": "B", "score": 22 }, { "date": "2023-02-10", "grade": "A", "score": 10 } ] },
  { "_id": 4, "name": "Pizza Palace", "cuisine": ["Pizza", "Italian"], "address": { "street": "234 Main Street", "borough": "Queens", "zipcode": "11354", "coord": [-73.830348, 40.762759] }, "grades": [ { "date": "2024-04-01", "grade": "A", "score": 7 }, { "date": "2023-10-12", "grade": "A", "score": 9 } ] },
  { "_id": 5, "name": "Sunrise Bakery & Coffee Shop", "cuisine": ["Bakery", "Coffee"], "address": { "street": "12 Sunrise Ave", "borough": "Staten Island", "zipcode": "10301", "coord": [-74.077642, 40.641311] }, "grades": [ { "date": "2024-03-20", "grade": "A", "score": 5 }, { "date": "2023-07-18", "grade": "A", "score": 6 }, { "date": "2022-12-01", "grade": "A", "score": 4 } ] },
  { "_id": 6, "name": "Thai Spice", "cuisine": ["Thai"], "address": { "street": "99 East Broadway", "borough": "Manhattan", "zipcode": "10002", "coord": [-73.994869, 40.713824] }, "grades": [ { "date": "2024-01-28", "grade": "B", "score": 21 }, { "date": "2023-05-14", "grade": "A", "score": 14 } ] },
  { "_id": 7, "name": "Bronx Pizza Co", "cuisine": ["Pizza"], "address": { "street": "510 Willis Ave", "borough": "Bronx", "zipcode": "10455", "coord": [-73.919415, 40.816948] }, "grades": [ { "date": "2024-02-05", "grade": "A", "score": 11 }, { "date": "2023-09-01", "grade": "A", "score": 13 }, { "date": "2023-03-15", "grade": "B", "score": 28 } ] },
  { "_id": 8, "name": "Dragon Palace", "cuisine": ["Chinese"], "address": { "street": "88 Mott Street", "borough": "Manhattan", "zipcode": "10013", "coord": [-73.997141, 40.715346] }, "grades": [ { "date": "2024-03-10", "grade": "A", "score": 12 }, { "date": "2023-10-05", "grade": "A", "score": 10 } ] },
  { "_id": 9, "name": "Brooklyn Burger Bar", "cuisine": ["Hamburgers", "American"], "address": { "street": "300 Atlantic Ave", "borough": "Brooklyn", "zipcode": "11201", "coord": [-73.989723, 40.690021] }, "grades": [ { "date": "2024-04-05", "grade": "A", "score": 9 }, { "date": "2023-11-11", "grade": "A", "score": 7 }, { "date": "2023-05-20", "grade": "B", "score": 23 } ] },
  { "_id": 10, "name": "Italian Kitchen", "cuisine": ["Italian", "Pizza"], "address": { "street": "45 Mulberry Street", "borough": "Manhattan", "zipcode": "10013", "coord": [-73.997542, 40.71875] }, "grades": [ { "date": "2024-02-20", "grade": "A", "score": 6 }, { "date": "2023-08-08", "grade": "A", "score": 8 } ] }
])
```

---

## Step 2 – Verify the Import

Inside mongosh:
```js
use food
db.restaurants.countDocuments()
```

Expected: `10`. If you see `10`, proceed to the exercises.

---

## Step 3 – Exercise 1: Array Operators

Run the full file from your terminal (not inside mongosh):
```bash
mongosh --file itd103-labs/lab4-6-mongodb/lab4/exercise1_array_operators.js
```

Or paste queries manually inside mongosh (`use food` first):

### 1. `$all` – Both Chinese AND Thai cuisine
```js
db.restaurants.find(
  { cuisine: { $all: ["Chinese", "Thai"] } },
  { name: 1, cuisine: 1, _id: 0 }
)
```
Expected: `Golden Dragon` (1 result)

### 2. `$size` – Exactly 3 grades
```js
db.restaurants.find(
  { grades: { $size: 3 } },
  { name: 1, _id: 0 }
)
```
Expected (6 results): Morris Park Bake Shop, Wendy'S, Golden Dragon, Sunrise Bakery & Coffee Shop, Bronx Pizza Co, Brooklyn Burger Bar

### 3. Dot-notation – Any grade score > 20
```js
db.restaurants.find(
  { "grades.score": { $gt: 20 } },
  { name: 1, "grades.score": 1, _id: 0 }
)
```
Expected (5 results): Morris Park Bake Shop, Golden Dragon, Thai Spice, Bronx Pizza Co, Brooklyn Burger Bar

### 3b. `$elemMatch` – Grade "B" AND score > 20 on the same element
```js
db.restaurants.find(
  { grades: { $elemMatch: { grade: "B", score: { $gt: 20 } } } },
  { name: 1, grades: 1, _id: 0 }
)
```
Expected (5 results): same as above

### 4. `$addToSet` – Add "Bakery" to Morris Park Bake Shop
```js
db.restaurants.updateOne(
  { name: "Morris Park Bake Shop" },
  { $addToSet: { cuisine: "Bakery" } }
)
```
Expected: `modifiedCount: 0` — "Bakery" already exists, so nothing is added.

### BONUS: `$in`, `$nin`, `$push`, `$pull`
```js
// $in – Italian OR Pizza
db.restaurants.find({ cuisine: { $in: ["Italian", "Pizza"] } }, { name: 1, _id: 0 })
// Expected: Pizza Palace, Bronx Pizza Co, Italian Kitchen

// $nin – NOT American
db.restaurants.find({ cuisine: { $nin: ["American"] } }, { name: 1, _id: 0 })
// Expected: 7 restaurants

// $push – append a new grade to Pizza Palace
db.restaurants.updateOne(
  { name: "Pizza Palace" },
  { $push: { grades: { date: new Date(), grade: "A", score: 8 } } }
)
// Expected: modifiedCount: 1 — Pizza Palace now has 3 grades

// $pull – remove grades with score > 25 from all restaurants
db.restaurants.updateMany({}, { $pull: { grades: { score: { $gt: 25 } } } })
// Expected: modifiedCount: 1 — only Bronx Pizza Co had score 28
```

---

## Step 4 – Exercise 2: Text Search

Run the full file:
```bash
mongosh --file itd103-labs/lab4-6-mongodb/lab4/exercise2_text_search.js
```

Or run manually inside mongosh:

### 1. Create a text index
```js
db.restaurants.createIndex(
  { name: "text", "address.street": "text" },
  { name: "restaurant_text_index" }
)
```
Expected: `restaurant_text_index`

### 2. Full-text search: "bakery shop"
```js
db.restaurants.find(
  { $text: { $search: "bakery shop" } },
  { score: { $meta: "textScore" }, name: 1, _id: 0 }
).sort({ score: { $meta: "textScore" } })
```
Expected (2 results, highest score first): Sunrise Bakery & Coffee Shop, Morris Park Bake Shop

### 2b. Exact phrase: "Bake Shop"
```js
db.restaurants.find(
  { $text: { $search: "\"Bake Shop\"" } },
  { score: { $meta: "textScore" }, name: 1, _id: 0 }
)
```
Expected (1 result): Morris Park Bake Shop

### 2c. Shop but NOT coffee
```js
db.restaurants.find(
  { $text: { $search: "shop -coffee" } },
  { score: { $meta: "textScore" }, name: 1, _id: 0 }
)
```
Expected (1 result): Morris Park Bake Shop — "Sunrise Bakery & Coffee Shop" excluded by `-coffee`

> **Why not `"bakery -coffee"`?** MongoDB's English stemmer treats `"bake"` and `"bakery"` as different stems (`bake` vs `bakeri`), so `"bakery"` only matches "Sunrise Bakery" — which then gets removed by `-coffee` — leaving an empty result. Using `"shop"` correctly targets both bake shops and lets the negation do its job.

### 3. Regex queries
```js
// /pizza/i — case-insensitive match on name
db.restaurants.find({ name: { $regex: /pizza/i } }, { name: 1, _id: 0 })
// Expected: Pizza Palace, Bronx Pizza Co

// /^Dragon/i — name starts with "Dragon"
db.restaurants.find({ name: { $regex: /^Dragon/i } }, { name: 1, _id: 0 })
// Expected: Dragon Palace  (Golden Dragon excluded — "Dragon" is at the end)

// /Ave/i — street contains "Ave"
db.restaurants.find({ "address.street": { $regex: /Ave/i } }, { name: 1, "address.street": 1, _id: 0 })
// Expected: Morris Park Bake Shop, Sunrise Bakery & Coffee Shop, Bronx Pizza Co
```

---

## Step 5 – Exercise 3: Geospatial Queries

Run the full file:
```bash
mongosh --file itd103-labs/lab4-6-mongodb/lab4/exercise3_geospatial.js
```

Or run manually inside mongosh:

### 1. Create a 2dsphere index
```js
db.restaurants.createIndex({ "address.coord": "2dsphere" })
```
Expected: `address.coord_2dsphere`

### 2. `$near` – Within 1 km of [-73.856077, 40.848447]
```js
db.restaurants.find({
  "address.coord": {
    $near: {
      $geometry: { type: "Point", coordinates: [-73.856077, 40.848447] },
      $maxDistance: 1000
    }
  }
}, { name: 1, "address.street": 1, _id: 0 })
```
Expected (1 result): Morris Park Bake Shop — nearest other restaurant is ~6.4 km away

### 2b. `$near` – Within 5 km of Midtown Manhattan [-73.9857, 40.7484]
```js
db.restaurants.find({
  "address.coord": {
    $near: {
      $geometry: { type: "Point", coordinates: [-73.9857, 40.7484] },
      $maxDistance: 5000
    }
  }
}, { name: 1, "address.borough": 1, _id: 0 })
```
Expected (4 results, sorted nearest first):

| Restaurant | Distance |
|---|---|
| Golden Dragon | ~1.1 km |
| Italian Kitchen | ~3.4 km |
| Dragon Palace | ~3.8 km |
| Thai Spice | ~3.9 km |

### 3. `$geoWithin` polygon – Northeastern Bronx area
```js
const polygon = {
  type: "Polygon",
  coordinates: [[
    [-73.9, 40.8], [-73.9, 40.9], [-73.8, 40.9], [-73.8, 40.8], [-73.9, 40.8]
  ]]
}
db.restaurants.find({
  "address.coord": { $geoWithin: { $geometry: polygon } }
}, { name: 1, "address.borough": 1, _id: 0 })
```
Expected (1 result): Morris Park Bake Shop

### 4. `$geoWithin $box` – Bounding box (Manhattan)
```js
db.restaurants.find({
  "address.coord": {
    $geoWithin: { $box: [[-74.02, 40.70], [-73.93, 40.78]] }
  }
}, { name: 1, "address.borough": 1, _id: 0 })
```
Expected (4 results): Golden Dragon, Thai Spice, Dragon Palace, Italian Kitchen

### 5. `$geoWithin $center` – Circular area (~2 km radius)
```js
db.restaurants.find({
  "address.coord": {
    $geoWithin: { $center: [[-73.856077, 40.848447], 0.02] }
  }
}, { name: 1, "address.borough": 1, _id: 0 })
```
Expected (1 result): Morris Park Bake Shop

---

## Key Operators Reference
| Operator | Use Case |
|----------|----------|
| `$all` | Array contains ALL specified values |
| `$size` | Array has exact number of elements |
| `$elemMatch` | Array element matches multiple conditions |
| `$addToSet` | Add to array only if not already present |
| `$text` | Full-text search on text-indexed fields |
| `$near` | Find documents by proximity (sorted by distance) |
| `$geoWithin` | Find documents within a shape |

---

## Deliverables
- [x] Complete query solutions → `exercise1_array_operators.js`, `exercise2_text_search.js`, `exercise3_geospatial.js`
- [x] Search implementation results → `query_results.md` (Exercise 2)
- [x] Geospatial query results → `query_results.md` (Exercise 3)
