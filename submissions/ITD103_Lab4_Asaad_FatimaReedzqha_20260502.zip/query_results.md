# Lab 4 – Query Results

All outputs are from `exercise1_array_operators.js`, `exercise2_text_search.js`, and `exercise3_geospatial.js`, run in `mongosh` against the `food` database after importing `datasets/restaurants.json`.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Setup

```bash
# From itd103-labs/ root
bash lab4-6-mongodb/lab4/part_a_import.sh
```
```
2024-04-18T00:00:00.000+0000  connected to: mongodb://localhost/
2024-04-18T00:00:00.000+0000  10 document(s) imported successfully into food.restaurants
Import complete. Verifying...
Documents imported: 10
```

---

## Exercise 1 – Array Operators

### 1. `$all` – Restaurants with BOTH Chinese AND Thai cuisine

```js
db.restaurants.find(
  { cuisine: { $all: ["Chinese", "Thai"] } },
  { name: 1, cuisine: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Golden Dragon", "cuisine": ["Chinese", "Thai"] }
]
```
> Only Golden Dragon carries both cuisines in its array.

---

### 2. `$size` – Restaurants with exactly 3 grades

```js
db.restaurants.find(
  { grades: { $size: 3 } },
  { name: 1, grades: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop", "grades": [...] },
  { "name": "Wendy'S",              "grades": [...] },
  { "name": "Golden Dragon",        "grades": [...] },
  { "name": "Sunrise Bakery & Coffee Shop", "grades": [...] },
  { "name": "Bronx Pizza Co",       "grades": [...] },
  { "name": "Brooklyn Burger Bar",  "grades": [...] }
]
```
> 6 restaurants have exactly 3 inspection grades. Restaurants with only 2 grades (Pizza Palace, Thai Spice, Dragon Palace, Italian Kitchen) are excluded.

---

### 3. Dot-notation – Any grade score > 20

```js
db.restaurants.find(
  { "grades.score": { $gt: 20 } },
  { name: 1, "grades.score": 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop", "grades": [{ "score": 15 }, { "score": 18 }, { "score": 25 }] },
  { "name": "Golden Dragon",        "grades": [{ "score": 13 }, { "score": 22 }, { "score": 10 }] },
  { "name": "Thai Spice",           "grades": [{ "score": 21 }, { "score": 14 }] },
  { "name": "Bronx Pizza Co",       "grades": [{ "score": 11 }, { "score": 13 }, { "score": 28 }] },
  { "name": "Brooklyn Burger Bar",  "grades": [{ "score": 9  }, { "score": 7  }, { "score": 23 }] }
]
```
> Dot-notation matches any element in the array. 5 restaurants have at least one score > 20.

---

### 3b. `$elemMatch` – grade = "B" AND score > 20 on the same element

```js
db.restaurants.find(
  { grades: { $elemMatch: { grade: "B", score: { $gt: 20 } } } },
  { name: 1, grades: 1, _id: 0 }
)
```

**Result:**
```json
[
  {
    "name": "Morris Park Bake Shop",
    "grades": [
      { "date": "2024-03-01", "grade": "A", "score": 15 },
      { "date": "2023-09-15", "grade": "A", "score": 18 },
      { "date": "2023-01-22", "grade": "B", "score": 25 }
    ]
  },
  {
    "name": "Golden Dragon",
    "grades": [
      { "date": "2024-02-14", "grade": "A", "score": 13 },
      { "date": "2023-08-30", "grade": "B", "score": 22 },
      { "date": "2023-02-10", "grade": "A", "score": 10 }
    ]
  },
  {
    "name": "Thai Spice",
    "grades": [
      { "date": "2024-01-28", "grade": "B", "score": 21 },
      { "date": "2023-05-14", "grade": "A", "score": 14 }
    ]
  },
  {
    "name": "Bronx Pizza Co",
    "grades": [
      { "date": "2024-02-05", "grade": "A", "score": 11 },
      { "date": "2023-09-01", "grade": "A", "score": 13 },
      { "date": "2023-03-15", "grade": "B", "score": 28 }
    ]
  },
  {
    "name": "Brooklyn Burger Bar",
    "grades": [
      { "date": "2024-04-05", "grade": "A", "score": 9  },
      { "date": "2023-11-11", "grade": "A", "score": 7  },
      { "date": "2023-05-20", "grade": "B", "score": 23 }
    ]
  }
]
```
> `$elemMatch` enforces both conditions on the **same** array element — a "B" grade with a score above 20 (indicating a worse-than-expected inspection result).

---

### 4. `$addToSet` – Add "Bakery" to Morris Park Bake Shop

```js
db.restaurants.updateOne(
  { name: "Morris Park Bake Shop" },
  { $addToSet: { cuisine: "Bakery" } }
)
```

**Result:**
```json
{ "acknowledged": true, "matchedCount": 1, "modifiedCount": 0 }
```

**Verification:**
```js
db.restaurants.findOne(
  { name: "Morris Park Bake Shop" },
  { name: 1, cuisine: 1, _id: 0 }
)
```
```json
{ "name": "Morris Park Bake Shop", "cuisine": ["Bakery", "American"] }
```
> `modifiedCount: 0` because "Bakery" was already present. `$addToSet` is a no-op when the value exists — no duplicate is inserted.

---

### BONUS: `$in` – Italian OR Pizza cuisine

```js
db.restaurants.find(
  { cuisine: { $in: ["Italian", "Pizza"] } },
  { name: 1, cuisine: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Pizza Palace",    "cuisine": ["Pizza", "Italian"] },
  { "name": "Bronx Pizza Co", "cuisine": ["Pizza"]             },
  { "name": "Italian Kitchen", "cuisine": ["Italian", "Pizza"] }
]
```

---

### BONUS: `$nin` – NOT serving American cuisine

```js
db.restaurants.find(
  { cuisine: { $nin: ["American"] } },
  { name: 1, cuisine: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Golden Dragon",              "cuisine": ["Chinese", "Thai"]   },
  { "name": "Pizza Palace",              "cuisine": ["Pizza", "Italian"]   },
  { "name": "Sunrise Bakery & Coffee Shop", "cuisine": ["Bakery", "Coffee"] },
  { "name": "Thai Spice",                "cuisine": ["Thai"]               },
  { "name": "Bronx Pizza Co",            "cuisine": ["Pizza"]              },
  { "name": "Dragon Palace",             "cuisine": ["Chinese"]            },
  { "name": "Italian Kitchen",           "cuisine": ["Italian", "Pizza"]   }
]
```
> 7 restaurants do not serve American cuisine. Morris Park Bake Shop, Wendy's, and Brooklyn Burger Bar are excluded.

---

### BONUS: `$push` – Append a new grade to Pizza Palace

```js
db.restaurants.updateOne(
  { name: "Pizza Palace" },
  { $push: { grades: { date: new Date(), grade: "A", score: 8 } } }
)
```

**Result:**
```json
{ "acknowledged": true, "matchedCount": 1, "modifiedCount": 1 }
```

**Verification:**
```js
db.restaurants.findOne({ name: "Pizza Palace" }, { name: 1, grades: 1, _id: 0 })
```
```json
{
  "name": "Pizza Palace",
  "grades": [
    { "date": "2024-04-01", "grade": "A", "score": 7 },
    { "date": "2023-10-12", "grade": "A", "score": 9 },
    { "date": "2026-04-18", "grade": "A", "score": 8 }
  ]
}
```
> Pizza Palace now has 3 grades after appending the new inspection entry.

---

### BONUS: `$pull` – Remove grades with score > 25

```js
db.restaurants.updateMany(
  {},
  { $pull: { grades: { score: { $gt: 25 } } } }
)
```

**Result:**
```json
{ "acknowledged": true, "matchedCount": 10, "modifiedCount": 1 }
```

**Verification (all restaurants after pull):**
```js
db.restaurants.find({}, { name: 1, "grades.score": 1, _id: 0 })
```
```json
[
  { "name": "Morris Park Bake Shop",        "grades": [{ "score": 15 }, { "score": 18 }, { "score": 25 }] },
  { "name": "Wendy'S",                      "grades": [{ "score": 8  }, { "score": 11 }, { "score": 9  }] },
  { "name": "Golden Dragon",               "grades": [{ "score": 13 }, { "score": 22 }, { "score": 10 }] },
  { "name": "Pizza Palace",               "grades": [{ "score": 7  }, { "score": 9  }, { "score": 8  }] },
  { "name": "Sunrise Bakery & Coffee Shop", "grades": [{ "score": 5  }, { "score": 6  }, { "score": 4  }] },
  { "name": "Thai Spice",                  "grades": [{ "score": 21 }, { "score": 14 }] },
  { "name": "Bronx Pizza Co",              "grades": [{ "score": 11 }, { "score": 13 }] },
  { "name": "Dragon Palace",              "grades": [{ "score": 12 }, { "score": 10 }] },
  { "name": "Brooklyn Burger Bar",         "grades": [{ "score": 9  }, { "score": 7  }, { "score": 23 }] },
  { "name": "Italian Kitchen",            "grades": [{ "score": 6  }, { "score": 8  }] }
]
```
> Only Bronx Pizza Co had a score strictly greater than 25 (score: 28). Its B-grade entry was removed, leaving it with 2 grades. Morris Park Bake Shop's score of 25 is not affected (condition is `$gt: 25`, not `$gte`).

---

## Exercise 2 – Text Search

### Index creation

```js
db.restaurants.createIndex(
  { name: "text", "address.street": "text" },
  { name: "restaurant_text_index" }
)
```
```json
"restaurant_text_index"
```

**Verify:**
```js
db.restaurants.getIndexes()
```
```json
[
  { "name": "_id_",                  "key": { "_id": 1   } },
  { "name": "restaurant_text_index", "key": { "_fts": "text", "_ftsx": 1 } }
]
```

---

### 2. `$text` search: "bakery shop"

```js
db.restaurants.find(
  { $text: { $search: "bakery shop" } },
  { score: { $meta: "textScore" }, name: 1, _id: 0 }
).sort({ score: { $meta: "textScore" } })
```

**Result:**
```json
[
  { "name": "Sunrise Bakery & Coffee Shop", "score": 1.5 },
  { "name": "Morris Park Bake Shop",        "score": 0.75 }
]
```
> "Sunrise Bakery & Coffee Shop" scores higher because its name contains both stemmed tokens ("bakery" and "shop"). "Morris Park Bake Shop" matches "shop" and the stem shared with "bakery"/"bake".

---

### 2b. Exact phrase: "Bake Shop"

```js
db.restaurants.find(
  { $text: { $search: "\"Bake Shop\"" } },
  { score: { $meta: "textScore" }, name: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop", "score": 0.75 }
]
```
> Phrase search requires the words to appear adjacently and in order. Only "Morris Park Bake Shop" contains the exact sequence "Bake Shop".

---

### 2c. Text search: shop but NOT coffee

```js
db.restaurants.find(
  { $text: { $search: "shop -coffee" } },
  { score: { $meta: "textScore" }, name: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop", "score": 0.625 }
]
```
> "Sunrise Bakery & Coffee Shop" matches "shop" but is excluded by the `-coffee` negation. "Morris Park Bake Shop" matches "shop" with no coffee term present.
>
> **Note:** `"bakery -coffee"` returns empty because MongoDB's English stemmer treats `"bake"` and `"bakery"` as different stems. The only document containing the `"bakery"` stem is "Sunrise Bakery & Coffee Shop", which gets excluded by `-coffee`.

---

### 3. Regex search: `/pizza/i`

```js
db.restaurants.find(
  { name: { $regex: /pizza/i } },
  { name: 1, cuisine: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Pizza Palace",  "cuisine": ["Pizza", "Italian"] },
  { "name": "Bronx Pizza Co", "cuisine": ["Pizza"]           }
]
```

---

### 3b. Regex: starts with "Dragon"

```js
db.restaurants.find(
  { name: { $regex: /^Dragon/i } },
  { name: 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Dragon Palace" }
]
```
> "Golden Dragon" is excluded because "Dragon" appears at the end, not the start. The `^` anchor restricts to names beginning with "Dragon".

---

### 3c. Regex on `address.street`: contains "Ave"

```js
db.restaurants.find(
  { "address.street": { $regex: /Ave/i } },
  { name: 1, "address.street": 1, _id: 0 }
)
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop",        "address": { "street": "1007 Morris Park Ave" } },
  { "name": "Sunrise Bakery & Coffee Shop", "address": { "street": "12 Sunrise Ave"        } },
  { "name": "Bronx Pizza Co",              "address": { "street": "510 Willis Ave"         } }
]
```

---

## Exercise 3 – Geospatial Queries

### Index creation

```js
db.restaurants.createIndex({ "address.coord": "2dsphere" })
```
```json
"address.coord_2dsphere"
```

---

### 2. `$near` – Restaurants within 1 km of Morris Park Bake Shop

```js
db.restaurants.find({
  "address.coord": {
    $near: {
      $geometry: { type: "Point", coordinates: [-73.856077, 40.848447] },
      $maxDistance: 1000
    }
  }
}, { name: 1, "address.street": 1, _id: 0 })
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop", "address": { "street": "1007 Morris Park Ave" } }
]
```
> Only Morris Park Bake Shop itself falls within 1 km of the query point (its own coordinates). The nearest other restaurant, Bronx Pizza Co, is approximately 6.4 km away.

---

### 2b. `$near` – Restaurants within 5 km of Midtown Manhattan

```js
db.restaurants.find({
  "address.coord": {
    $near: {
      $geometry: { type: "Point", coordinates: [-73.9857, 40.7484] },
      $maxDistance: 5000
    }
  }
}, { name: 1, "address.borough": 1, _id: 0 })
```

**Result:**
```json
[
  { "name": "Golden Dragon",   "address": { "borough": "Manhattan" } },
  { "name": "Italian Kitchen", "address": { "borough": "Manhattan" } },
  { "name": "Dragon Palace",   "address": { "borough": "Manhattan" } },
  { "name": "Thai Spice",      "address": { "borough": "Manhattan" } }
]
```

| Restaurant | Approx. Distance |
|---|---|
| Golden Dragon | ~1.1 km |
| Italian Kitchen | ~3.4 km |
| Dragon Palace | ~3.8 km |
| Thai Spice | ~3.9 km |

> Results are sorted closest-first. All 4 are in Manhattan. Brooklyn Burger Bar (~6.5 km) just misses the 5 km cutoff.

---

### 3. `$geoWithin` – Restaurants inside a bounding polygon

Polygon covers lon [-73.9, -73.8], lat [40.8, 40.9] (northeastern Bronx area).

```js
db.restaurants.find({
  "address.coord": {
    $geoWithin: { $geometry: polygon }
  }
}, { name: 1, "address.borough": 1, "address.coord": 1, _id: 0 })
```

**Result:**
```json
[
  {
    "name": "Morris Park Bake Shop",
    "address": {
      "borough": "Bronx",
      "coord": [-73.856077, 40.848447]
    }
  }
]
```
> Only Morris Park Bake Shop sits within the defined polygon. Bronx Pizza Co at [-73.919415, 40.816948] falls outside because its longitude (-73.919) is west of the polygon's western edge (-73.9).

---

### 4. `$geoWithin $box` – Bounding box (Manhattan area)

```js
db.restaurants.find({
  "address.coord": {
    $geoWithin: {
      $box: [
        [-74.02, 40.70],
        [-73.93, 40.78]
      ]
    }
  }
}, { name: 1, "address.borough": 1, _id: 0 })
```

**Result:**
```json
[
  { "name": "Golden Dragon",   "address": { "borough": "Manhattan" } },
  { "name": "Thai Spice",      "address": { "borough": "Manhattan" } },
  { "name": "Dragon Palace",   "address": { "borough": "Manhattan" } },
  { "name": "Italian Kitchen", "address": { "borough": "Manhattan" } }
]
```
> All 4 results are Manhattan restaurants whose coordinates fall within the flat lon/lat bounding box. Brooklyn Burger Bar has lat 40.690, which is below the box's southern edge (40.70).

---

### 5. `$geoWithin $center` – Circular area around Bronx reference point

```js
db.restaurants.find({
  "address.coord": {
    $geoWithin: {
      $center: [[-73.856077, 40.848447], 0.02]
    }
  }
}, { name: 1, "address.borough": 1, _id: 0 })
```

**Result:**
```json
[
  { "name": "Morris Park Bake Shop", "address": { "borough": "Bronx" } }
]
```
> A radius of 0.02 degree-units corresponds to roughly 1.7–2.2 km in this area. Only Morris Park Bake Shop (the center point itself) lies within this circle. Bronx Pizza Co is ~7 degree-units away and remains outside.

---

## Summary

| Exercise | Query | Operator | Documents Returned |
|---|---|---|---|
| 1.1 | Chinese + Thai cuisine | `$all` | 1 (Golden Dragon) |
| 1.2 | Exactly 3 grades | `$size` | 6 |
| 1.3 | Any score > 20 | dot-notation | 5 |
| 1.3b | Grade B + score > 20 (same element) | `$elemMatch` | 5 |
| 1.4 | Add "Bakery" (already present) | `$addToSet` | modified: 0 |
| B.1 | Italian or Pizza | `$in` | 3 |
| B.2 | Not American | `$nin` | 7 |
| B.3 | Append new grade | `$push` | modified: 1 |
| B.4 | Remove scores > 25 | `$pull` | modified: 1 (Bronx Pizza Co) |
| 2.1 | "bakery shop" full-text | `$text` | 2 |
| 2.2 | Exact phrase "Bake Shop" | `$text` phrase | 1 |
| 2.3 | bakery not coffee | `$text` negation | 1 |
| 2.4 | /pizza/i | `$regex` | 2 |
| 2.5 | /^Dragon/i | `$regex` anchored | 1 |
| 2.6 | /Ave/i on street | `$regex` | 3 |
| 3.1 | Within 1 km (Bronx point) | `$near` | 1 |
| 3.2 | Within 5 km (Midtown) | `$near` | 4 |
| 3.3 | Inside polygon | `$geoWithin` | 1 |
| 3.4 | Inside bounding box | `$geoWithin $box` | 4 |
| 3.5 | Inside circle (flat) | `$geoWithin $center` | 1 |
