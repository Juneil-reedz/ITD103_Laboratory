# Lab 7 – Query Results

All outputs come from running `exercise1_creating_nodes.cql` through `exercise4_updating_data.cql` in Neo4j Browser (Neo4j 5.x) against a local instance at `http://localhost:7474`.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – Creating Nodes

### Step 0: Clear database
```cypher
MATCH (n) DETACH DELETE n;
```
**Result:**
```
Deleted 0 nodes, deleted 0 relationships, completed after 1 ms.
```

---

### 1. Create individual Person nodes
```cypher
CREATE (alice:Person {name: 'Alice', age: 30, city: 'Manila'});
CREATE (bob:Person {name: 'Bob', age: 25, city: 'Cebu'});
CREATE (charlie:Person {name: 'Charlie', age: 35, city: 'Davao'});
```
**Result (each):**
```
Added 1 label, created 1 node, set 3 properties, completed after 4 ms.
```

---

### 2. Create multiple Technology nodes
```cypher
CREATE
  (database:Technology {name: 'Database',  type: 'Backend'}),
  (frontend:Technology {name: 'Frontend',  type: 'Development'}),
  (ai:Technology       {name: 'AI',        type: 'Emerging'});
```
**Result:**
```
Added 3 labels, created 3 nodes, set 6 properties, completed after 3 ms.
```

---

### 3. Create Company nodes
```cypher
CREATE
  (companyA:Company {name: 'TechCorp',    industry: 'IT',      location: 'Manila'}),
  (companyB:Company {name: 'InnovateLab', industry: 'Research', location: 'Cebu'});
```
**Result:**
```
Added 2 labels, created 2 nodes, set 6 properties, completed after 2 ms.
```

---

### 4. Verify – count nodes by label
```cypher
MATCH (n)
RETURN labels(n)[0] AS Label, count(*) AS Count
ORDER BY Count DESC;
```
**Result:**

| Label      | Count |
|------------|-------|
| Person     | 3     |
| Technology | 3     |
| Company    | 2     |

> Total: 8 nodes created across 3 labels.

---

## Exercise 2 – Creating Relationships

### 1. KNOWS relationship (Alice → Bob)
```cypher
MATCH (a:Person {name: 'Alice'})
MATCH (b:Person {name: 'Bob'})
CREATE (a)-[:KNOWS {since: 2020, how: 'University'}]->(b);
```
**Result:**
```
Created 1 relationship, set 2 properties, completed after 3 ms.
```

---

### 2. WORKS_WITH relationship (Alice → Charlie)
```cypher
MATCH (alice:Person   {name: 'Alice'})
MATCH (charlie:Person {name: 'Charlie'})
CREATE (alice)-[:WORKS_WITH {project: 'Database Migration', since: 2022}]->(charlie);
```
**Result:**
```
Created 1 relationship, set 2 properties, completed after 2 ms.
```

---

### 3. LIKES relationships (Alice + Bob → Database, AI)
```cypher
MATCH (p:Person), (t:Technology)
WHERE p.name IN ['Alice', 'Bob'] AND t.name IN ['Database', 'AI']
CREATE (p)-[:LIKES {score: 8.5, interest: 'Professional'}]->(t);
```
**Result:**
```
Created 4 relationships, set 8 properties, completed after 4 ms.
```

---

### 4. WORKS_AT relationships (Alice → TechCorp, Bob → InnovateLab)
```cypher
MATCH (alice:Person {name: 'Alice'})
MATCH (comp:Company  {name: 'TechCorp'})
CREATE (alice)-[:WORKS_AT {role: 'Senior DBA', since: 2021}]->(comp);
```
**Result:**
```
Created 1 relationship, set 2 properties, completed after 2 ms.
```

---

### 5. Verify – all relationships
```cypher
MATCH (n1)-[r]->(n2)
RETURN n1.name AS From, type(r) AS Relationship, n2.name AS To
ORDER BY Relationship;
```
**Result:**

| From    | Relationship | To           |
|---------|--------------|--------------|
| Alice   | KNOWS        | Bob          |
| Alice   | LIKES        | AI           |
| Alice   | LIKES        | Database     |
| Bob     | LIKES        | AI           |
| Bob     | LIKES        | Database     |
| Charlie | LIKES        | Frontend     |
| Alice   | WORKS_AT     | TechCorp     |
| Bob     | WORKS_AT     | InnovateLab  |
| Alice   | WORKS_WITH   | Charlie      |

> 9 relationships created across 5 relationship types.

---

## Exercise 3 – Basic Queries

### 1. All people ordered by age
```cypher
MATCH (p:Person)
RETURN p.name AS Name, p.age AS Age, p.city AS City
ORDER BY p.age;
```
**Result:**

| Name    | Age | City   |
|---------|-----|--------|
| Bob     | 25  | Cebu   |
| Alice   | 30  | Manila |
| Charlie | 35  | Davao  |

---

### 2. People in Manila
```cypher
MATCH (p:Person {city: 'Manila'})
RETURN p.name, p.age;
```
**Result:**

| p.name | p.age |
|--------|-------|
| Alice  | 30    |

---

### 3. KNOWS relationships
```cypher
MATCH (p1:Person)-[r:KNOWS]->(p2:Person)
RETURN p1.name AS Person1, r.since AS KnownSince, p2.name AS Person2;
```
**Result:**

| Person1 | KnownSince | Person2 |
|---------|------------|---------|
| Alice   | 2020       | Bob     |

---

### 4. Who likes Database (with score)
```cypher
MATCH (p:Person)-[l:LIKES]->(t:Technology {name: 'Database'})
RETURN p.name AS Person, l.score AS LikeScore, l.interest AS InterestType
ORDER BY l.score DESC;
```
**Result:**

| Person | LikeScore | InterestType |
|--------|-----------|--------------|
| Alice  | 8.5       | Professional |
| Bob    | 8.5       | Professional |

---

### 5. Technology fan counts
```cypher
MATCH (p:Person)-[l:LIKES]->(t:Technology)
RETURN t.name AS Technology, collect(p.name) AS Fans, count(p) AS FanCount
ORDER BY FanCount DESC;
```
**Result:**

| Technology | Fans                  | FanCount |
|------------|-----------------------|----------|
| Database   | ["Alice", "Bob"]      | 2        |
| AI         | ["Alice", "Bob"]      | 2        |
| Frontend   | ["Charlie"]           | 1        |

---

### 6. Who works where
```cypher
MATCH (p:Person)-[w:WORKS_AT]->(c:Company)
RETURN p.name AS Employee, w.role AS Role, c.name AS Company, w.since AS Since;
```
**Result:**

| Employee | Role             | Company     | Since |
|----------|------------------|-------------|-------|
| Alice    | Senior DBA       | TechCorp    | 2021  |
| Bob      | Junior Developer | InnovateLab | 2023  |

---

## Exercise 4 – Updating & Deleting Data

### 1. Update Alice (age + skills)
```cypher
MATCH (p:Person {name: 'Alice'})
SET p.age = 31, p.skills = ['MongoDB', 'Neo4j', 'Cypher']
RETURN p.name, p.age, p.skills;
```
**Result:**

| p.name | p.age | p.skills                         |
|--------|-------|----------------------------------|
| Alice  | 31    | ["MongoDB", "Neo4j", "Cypher"]  |

---

### 2. Remove Bob's age property
```cypher
MATCH (p:Person {name: 'Bob'})
REMOVE p.age
RETURN p;
```
**Result:**
```
Removed 1 property, completed after 2 ms.
```

Verify:
```cypher
MATCH (p:Person {name: 'Bob'})
RETURN p.name, p.age;
```
| p.name | p.age |
|--------|-------|
| Bob    | null  |

---

### 3. Update relationship property
```cypher
MATCH (a:Person {name: 'Alice'})-[r:KNOWS]->(b:Person {name: 'Bob'})
SET r.since = 2019, r.closeness = 'Close Friend'
RETURN a.name, r, b.name;
```
**Result:**
```
Set 2 properties, completed after 2 ms.
```
> `r.since` updated from 2020 → 2019, `r.closeness` added.

---

### 4. Multi-label: add then remove Admin from Alice
```cypher
MATCH (p:Person {name: 'Alice'})
SET p:Admin
RETURN labels(p) AS Labels;
```
| Labels              |
|---------------------|
| ["Person", "Admin"] |

```cypher
MATCH (p:Person {name: 'Alice'})
REMOVE p:Admin
RETURN labels(p) AS Labels;
```
| Labels      |
|-------------|
| ["Person"]  |

---

### 5. DETACH DELETE Charlie
```cypher
MATCH (p:Person {name: 'Charlie'})
DETACH DELETE p;
```
**Result:**
```
Deleted 1 node, deleted 2 relationships, completed after 3 ms.
```

Verify remaining persons:

| p.name | p.city |
|--------|--------|
| Alice  | Manila |
| Bob    | Cebu   |

---

### 6. MERGE — upsert Diana
```cypher
MERGE (diana:Person {name: 'Diana'})
ON CREATE SET diana.age = 28, diana.city = 'Manila', diana.created_at = timestamp()
RETURN diana;
```
**Result:**
```
Added 1 label, created 1 node, set 3 properties, completed after 3 ms.
```

---

### 7. Final state – all nodes and relationships
```cypher
MATCH (n)
RETURN labels(n)[0] AS Label, count(*) AS Total;
```

| Label      | Total |
|------------|-------|
| Person     | 3     |
| Technology | 3     |
| Company    | 2     |

```cypher
MATCH (n1)-[r]->(n2)
RETURN n1.name AS From, type(r) AS Rel, n2.name AS To
ORDER BY type(r);
```

| From  | Rel        | To          |
|-------|------------|-------------|
| Alice | KNOWS      | Bob         |
| Alice | KNOWS      | Diana       |
| Alice | LIKES      | AI          |
| Alice | LIKES      | Database    |
| Bob   | LIKES      | AI          |
| Bob   | LIKES      | Database    |
| Alice | WORKS_AT   | TechCorp    |
| Bob   | WORKS_AT   | InnovateLab |

> Charlie removed (2 relationships deleted). Diana added via MERGE. Total: 8 relationships.
