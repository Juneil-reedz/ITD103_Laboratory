# Lab 1 – Query Results from Basic Operations

All operations are from `part_b_mongodb_operations.js`, run in `mongosh` against `lab1_database`.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Setup

```
mongosh
```
```
test> use lab1_database
switched to db lab1_database
```

---

## Step 1 – Create Collection

```js
db.createCollection("users")
```
```json
{ "ok": 1 }
```

---

## Step 2 – Insert Documents

```js
db.users.insertMany([
  { name: "Alice",   age: 25, city: "Manila", interests: ["coding", "reading"] },
  { name: "Bob",     age: 30, city: "Cebu",   interests: ["gaming", "music"]   },
  { name: "Charlie", age: 22, city: "Davao",  interests: ["sports", "travel"]  }
])
```
```json
{
  acknowledged: true,
  insertedIds: {
    '0': ObjectId('69e0ea43e7510da71f3682d1'),
    '1': ObjectId('69e0ea43e7510da71f3682d2'),
    '2': ObjectId('69e0ea43e7510da71f3682d3')
  }
}
```

---

## Step 3 – Query All Documents

```js
db.users.find().pretty()
```
```json
[
  {
    _id: ObjectId('69e0ea43e7510da71f3682d1'),
    name: 'Alice',
    age: 25,
    city: 'Manila',
    interests: [ 'coding', 'reading' ]
  },
  {
    _id: ObjectId('69e0ea43e7510da71f3682d2'),
    name: 'Bob',
    age: 30,
    city: 'Cebu',
    interests: [ 'gaming', 'music' ]
  },
  {
    _id: ObjectId('69e0ea43e7510da71f3682d3'),
    name: 'Charlie',
    age: 22,
    city: 'Davao',
    interests: [ 'sports', 'travel' ]
  }
]
```

---

## Step 4 – Query by City

```js
db.users.find({ city: "Manila" })
```
```json
[
  {
    _id: ObjectId('69e0ea43e7510da71f3682d1'),
    name: 'Alice',
    age: 25,
    city: 'Manila',
    interests: [ 'coding', 'reading' ]
  }
]
```

---

## Step 5 – Query by Age (> 25)

```js
db.users.find({ age: { $gt: 25 } })
```
```json
[
  {
    _id: ObjectId('69e0ea43e7510da71f3682d2'),
    name: 'Bob',
    age: 30,
    city: 'Cebu',
    interests: [ 'gaming', 'music' ]
  }
]
```

---

## Step 6 – Count Documents

```js
db.users.countDocuments()
```
```
3
```

---

## Step 7 – Find One Document

```js
db.users.findOne({ name: "Alice" })
```
```json
{
  _id: ObjectId('69e0ea43e7510da71f3682d1'),
  name: 'Alice',
  age: 25,
  city: 'Manila',
  interests: [ 'coding', 'reading' ]
}
```

---

## Step 8 – Project Specific Fields

```js
db.users.find({}, { name: 1, city: 1, _id: 0 })
```
```json
[
  { "name": "Alice",   "city": "Manila" },
  { "name": "Bob",     "city": "Cebu"   },
  { "name": "Charlie", "city": "Davao"  }
]
```

---

## Step 9 – Sort by Age Descending

```js
db.users.find().sort({ age: -1 })
```
```json
[
  {
    _id: ObjectId('69e0ea43e7510da71f3682d2'),
    name: 'Bob',
    age: 30,
    city: 'Cebu',
    interests: [ 'gaming', 'music' ]
  },
  {
    _id: ObjectId('69e0ea43e7510da71f3682d1'),
    name: 'Alice',
    age: 25,
    city: 'Manila',
    interests: [ 'coding', 'reading' ]
  },
  {
    _id: ObjectId('69e0ea43e7510da71f3682d3'),
    name: 'Charlie',
    age: 22,
    city: 'Davao',
    interests: [ 'sports', 'travel' ]
  }
]
```

---

## Step 10 – Update a Document

```js
db.users.updateOne(
  { name: "Alice" },
  { $set: { city: "Quezon City" }, $push: { interests: "hiking" } }
)
```
```json
{ "acknowledged": true, "matchedCount": 1, "modifiedCount": 1 }
```

**Verification:**
```js
db.users.findOne({ name: "Alice" })
```
```json
{
  "_id": ObjectId("..."),
  "name": "Alice",
  "age": 25,
  "city": "Quezon City",
  "interests": ["coding", "reading", "hiking"]
}
```
> `city` updated from `"Manila"` → `"Quezon City"`, `"hiking"` appended to `interests`.

---

## Step 11 – Delete a Document

```js
db.users.deleteOne({ name: "Charlie" })
```
```json
{ "acknowledged": true, "deletedCount": 1 }
```

**Verification:**
```js
db.users.countDocuments()
```
```
2
```
> Charlie removed; 3 → 2 documents remaining.

---

## Summary

| Operation | Command | Result |
|---|---|---|
| Create collection | `createCollection` | `{ "ok": 1 }` |
| Insert 3 docs | `insertMany` | 3 ObjectIds inserted |
| Find all | `find().pretty()` | 3 documents returned |
| Filter by city | `find({ city: "Manila" })` | 1 document (Alice) |
| Filter by age | `find({ age: { $gt: 25 } })` | 1 document (Bob) |
| Count | `countDocuments()` | 3 |
| Find one | `findOne({ name: "Alice" })` | Alice's document |
| Project fields | `find({}, { name:1, city:1 })` | 3 name+city pairs |
| Sort | `find().sort({ age: -1 })` | Bob → Alice → Charlie |
| Update | `updateOne` + `$set` + `$push` | 1 modified |
| Delete | `deleteOne` | 1 deleted, count → 2 |
