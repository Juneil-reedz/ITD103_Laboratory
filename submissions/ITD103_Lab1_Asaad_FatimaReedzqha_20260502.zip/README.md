# Lab 1: Understanding CAP Theorem

## Objectives
- Understand CAP Theorem trade-offs
- Compare different NoSQL databases
- Install and configure MongoDB

## Files
| File | Description |
|------|-------------|
| `part_a_cap_analysis.md` | CAP Theorem scenario analysis and database selection |
| `cap_theorem_report.pdf` | CAP Theorem analysis report (PDF) |
| `cap_theorem_report.html` | CAP Theorem analysis report (HTML source) |
| `part_b_mongodb_operations.js` | MongoDB basic CRUD operations (run in mongosh) |
| `mongodb_connection_log.md` | mongosh connection output and session details |
| `query_results.md` | Expected output for all CRUD operations with explanations |

## Quick Start

### Start MongoDB
```bash
mongod --dbpath ./data --port 27017
```

### Connect with shell
```bash
mongosh
```

### Run Part B
Copy and paste commands from `part_b_mongodb_operations.js` into mongosh, or load the file:
```bash
mongosh --file part_b_mongodb_operations.js
```

## Deliverables
- [x] CAP Theorem analysis report → `cap_theorem_report.pdf` *(generated from `part_a_cap_analysis.md`)*
- [x] MongoDB connection screenshot → `mongodb_connection_log.md`
- [x] Query results from basic operations → `query_results.md`

### Export CAP report to PDF
```bash
# Using pandoc
pandoc part_a_cap_analysis.md -o cap_theorem_report.pdf

# Or open in VS Code → right-click → "Open Preview" → Print to PDF
```
