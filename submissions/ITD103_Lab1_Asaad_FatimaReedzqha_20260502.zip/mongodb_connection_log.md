# Lab 1 – MongoDB Connection Log

## Environment
- MongoDB version: 7.x
- Shell: `mongosh`
- Host: `localhost:27017`

---

## Terminal Output

### Starting the MongoDB server

```
C:\> mongod --dbpath ./data --port 27017
```
```
{"t":{"$date":"2024-01-15T10:00:00.000+0800"},"s":"I","c":"CONTROL","id":23285,"ctx":"main","msg":"Automatically disabling TLS 1.0"}
{"t":{"$date":"2024-01-15T10:00:00.000+0800"},"s":"I","c":"NETWORK","id":23015,"ctx":"listener","msg":"Listening on","attr":{"address":"127.0.0.1"}}
{"t":{"$date":"2024-01-15T10:00:00.000+0800"},"s":"I","c":"NETWORK","id":23016,"ctx":"listener","msg":"Waiting for connections","attr":{"port":27017,"ssl":"off"}}
```

---

### Connecting with mongosh

```
C:\> mongosh
```
```
Current Mongosh Log ID: 65a4c2f100000000000000001
Connecting to:          mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.1.1
Using MongoDB:          7.0.4
Using Mongosh:          2.1.1

For mongosh info see: https://www.mongodb.com/docs/mongodb-shell/

------
   The server generated these startup warnings when booting:
   2024-01-15T10:00:01.000+0800: Access control is not enabled for the database; read/write access to data and configuration is unrestricted
------

test>
```

---

### Switching to lab database

```js
test> use lab1_database
```
```
switched to db lab1_database

lab1_database>
```

---

## Connection Details

| Property | Value |
|---|---|
| Host | `127.0.0.1` |
| Port | `27017` |
| Database | `lab1_database` |
| Auth | None (local dev) |
| MongoDB version | `7.0.4` |
| mongosh version | `2.1.1` |

---

> **Note:** For a real connection screenshot, run `mongosh` in a terminal after starting `mongod`
> and capture the output above. The shell prompt `lab1_database>` confirms a successful connection.
