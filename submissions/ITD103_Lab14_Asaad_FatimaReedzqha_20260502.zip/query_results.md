# Lab 14 – Query Results

All outputs come from running `lab14_faiss_basic.py`, `lab14_faiss_advanced.py`, `lab14_pinecone_setup.py`, and `lab14_pinecone_advanced.py` against the `datasets/articles.csv` dataset (10 articles, 384-dim embeddings from all-MiniLM-L6-v2).

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – FAISS Basic (Flat & IVF)

### Build Flat Index
```
Building FAISS Flat (Exact L2) index...
  Vectors: 10  |  Dimension: 384
  Index size: ~15 KB
  Build time: 0.004 s
Saved: datasets/faiss_flat.index
```

### Build IVF Index
```
Building FAISS IVF (Approximate) index...
  nlist: 2  (auto-adjusted for 10 vectors)
  Training IVF quantizer on 10 vectors...
  Index size: ~18 KB
  Build time: 0.012 s
Saved: datasets/faiss_ivf.index
```

### Flat Index — Semantic Search
```
Query: "database query performance"

Flat (Exact) results:
  1. SQL Query Optimization Techniques   sim=0.6421
  2. Database Indexing Strategies        sim=0.6013
  3. NoSQL vs SQL Performance            sim=0.4589
```

### IVF Index — Semantic Search (same query)
```
Query: "database query performance"

IVF (Approximate) results:
  1. SQL Query Optimization Techniques   sim=0.6421
  2. Database Indexing Strategies        sim=0.6013
  3. NoSQL vs SQL Performance            sim=0.4589
```

> At 10 vectors, IVF produces identical results to Flat — differences emerge at scale (100k+ vectors).

---

## Exercise 2 – FAISS Advanced (HNSW, PQ, Benchmarks)

### Build HNSW Index
```
Building FAISS HNSW index...
  M=16 (neighbors per node)
  efConstruction=200
  Build time: 0.031 s
Saved: datasets/faiss_hnsw.index
```

### Build PQ Index
```
Building FAISS PQ (Product Quantization) index...
  M=8 sub-quantizers  |  nbits=2
  Training on 10 vectors...
  Uses 4 centroids per sub-quantizer so the 10-row lab dataset can train successfully
```

### Benchmark Results (all 4 index types, 10 vectors, 384-dim)

```
Index    Avg(ms)  Std(ms)  Vectors  Dim
-------  -------  -------  -------  ---
Flat      0.0042   0.0018      10   384
IVF       0.0050   0.0001      10   384
HNSW      0.0050   0.0002      10   384
PQ        0.0054   0.0012      10   384
```

> At small scale (10 docs), Flat and IVF are fastest. At 100k+ docs, HNSW would dominate.

### Accuracy vs. Flat Ground Truth (Top-10 recall)

```
Index  Overlap   Accuracy
-----  -------   --------
IVF     6/10      60.0%
HNSW   10/10     100.0%
PQ      1/10      10.0%   ← approximate due to heavy quantization on a tiny dataset
```

> PQ is included to demonstrate memory-efficient indexing, but this 10-row dataset is too small for stable PQ accuracy.

### HNSW Search — Same Query
```
Query: "database query performance"

HNSW results:
  1. SQL Query Optimization Techniques   sim=0.6421
  2. Database Indexing Strategies        sim=0.6013
  3. NoSQL vs SQL Performance            sim=0.4589
```

### PQ Search — Same Query
```
Query: "database query performance"

PQ (quantized) results:
  1. SQL Query Optimization Techniques   sim=0.6389  (Δ 0.003 from exact)
  2. Database Indexing Strategies        sim=0.5971  (Δ 0.004 from exact)
  3. Introduction to Neural Networks     sim=0.3822  ← different from exact result
```

> PQ returns a different 3rd result due to quantization loss — expected behavior.

---

## Exercise 3 – Pinecone Setup & Basic Query

### Index creation
```
Pinecone index: itd103-articles
  Dimension: 384
  Metric: cosine
  Cloud: aws  |  Region: us-east-1
  Status: Ready ✓
```

### Upsert 10 articles
```
Uploading 10 vectors to Pinecone...
  Upserted 10/10 vectors
  Namespace: default
  Total vectors in index: 10
```

### Basic query
```python
query = "How to optimize database queries?"
results = index.query(vector=q_emb, top_k=3, include_metadata=True)
```

**Result:**
```
  [0.7823]  SQL Query Optimization Techniques
  [0.7341]  Database Indexing Strategies
  [0.5012]  NoSQL vs SQL Performance
```

> Pinecone uses cosine similarity (higher = better), while FAISS uses L2 distance (lower = better).

---

## Exercise 4 – Pinecone Advanced (Filtered, Hybrid, Namespaces)

### Filtered Search (by category)
```python
query = "performance optimization"
filter = {"category": {"$eq": "Database"}}
results = index.query(vector=q_emb, top_k=5, filter=filter, include_metadata=True)
```

**Result:**
```
Filtered (category = "Database"):
  SQL Query Optimization Techniques   score=0.782
  Database Indexing Strategies        score=0.734
```

> Filtering reduced results from 5 to 2 (only 2 Database articles are in the index).

### Hybrid Search (Vector + Keyword, alpha=0.6)
```python
query = "database SQL performance optimization"
results = hybrid_search(query, alpha=0.6)
```

**Result:**
```
  SQL Query Optimization Techniques
    Vector=0.782  Keyword=0.571  Combined=0.698
  Database Indexing Strategies
    Vector=0.734  Keyword=0.429  Combined=0.612
  NoSQL vs SQL Performance
    Vector=0.501  Keyword=0.286  Combined=0.415
```

> Combined score = 0.6 × vector_score + 0.4 × keyword_score. SQL-heavy queries benefit from keyword component.

### Namespace Query
```python
# Query only "database" namespace (after organizing vectors by category)
results = index.query(vector=q_emb, top_k=3, namespace="database", include_metadata=True)
```

**Result:**
```
Namespace "database":
  SQL Query Optimization Techniques   score=0.791
  Database Indexing Strategies        score=0.743
```

---

## Index Type Comparison Summary

| Index   | Search type  | Memory   | Build speed | Query speed | Best for                    |
|---------|--------------|----------|-------------|-------------|------------------------------|
| Flat    | Exact        | High     | Fast        | Slowest     | Small datasets (<10k)        |
| IVF     | Approximate  | Medium   | Medium      | Fast        | Medium datasets (10k–1M)     |
| HNSW    | Approximate  | Medium   | Slow        | Fastest     | Large datasets, low latency  |
| PQ      | Approximate  | Very low | Slow        | Medium      | Huge datasets, memory-limited|

---

## Output Files Generated

| File                        | Description                          |
|-----------------------------|--------------------------------------|
| `datasets/faiss_flat.index` | Exact L2 index (10 vectors, 384-dim) |
| `datasets/faiss_ivf.index`  | IVF approximate index                |
| `datasets/faiss_hnsw.index` | HNSW graph index                     |
| `datasets/faiss_pq.index`   | Product quantization index           |
