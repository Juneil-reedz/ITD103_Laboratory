# Lab 10 – GraphQL API Documentation

## Server

| Item | Value |
|------|-------|
| Server URL | `http://localhost:4000/graphql` |
| GraphiQL UI | `http://localhost:4000/graphql` |
| Health Check | `http://localhost:4000/health` |
| Database | MongoDB `graphql_lab` |

## Data Model

### Book

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | `ID!` | Yes | MongoDB document ID |
| `title` | `String!` | Yes | Book title |
| `author` | `String!` | Yes | Book author |
| `genre` | `String!` | Yes | Book category or genre |
| `publishedYear` | `Int` | No | Publication year |
| `price` | `Float!` | Yes | Book price |
| `inStock` | `Boolean!` | Yes | Stock status |

### Author

| Field | Type | Description |
|-------|------|-------------|
| `id` | `ID!` | Generated author identifier |
| `name` | `String!` | Author name |
| `books` | `[Book!]!` | Books written by the author |

## Queries

### Get All Books

```graphql
query GetAllBooks {
  books {
    id
    title
    author
    genre
    price
    inStock
  }
}
```

### Get Book By ID

```graphql
query GetBook($id: ID!) {
  book(id: $id) {
    id
    title
    author
    genre
    publishedYear
    price
    inStock
  }
}
```

### Get Books By Genre

```graphql
query GetFantasyBooks {
  booksByGenre(genre: "Fantasy") {
    title
    author
    publishedYear
  }
}
```

### Get Books By Author

```graphql
query GetBooksByAuthor {
  booksByAuthor(author: "J.K. Rowling") {
    title
    genre
    publishedYear
    price
  }
}
```

### Get Authors With Books

```graphql
query GetAuthors {
  authors {
    name
    books {
      title
      genre
    }
  }
}
```

### Get Author By Name

```graphql
query GetAuthor {
  author(name: "J.K. Rowling") {
    name
    books {
      title
      publishedYear
    }
  }
}
```

## Mutations

### Add Book

```graphql
mutation AddBook {
  addBook(input: {
    title: "1984"
    author: "George Orwell"
    genre: "Dystopian"
    publishedYear: 1949
    price: 11.99
    inStock: true
  }) {
    id
    title
    author
  }
}
```

### Add Multiple Books

```graphql
mutation SeedBooks {
  addBooks(books: [
    { title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: "Classic", publishedYear: 1925, price: 12.99, inStock: true }
    { title: "The Hobbit", author: "J.R.R. Tolkien", genre: "Fantasy", publishedYear: 1937, price: 13.99, inStock: true }
  ]) {
    id
    title
    author
  }
}
```

### Update Book

```graphql
mutation UpdateBook($id: ID!) {
  updateBook(id: $id, input: {
    price: 14.99
    inStock: false
  }) {
    id
    title
    price
    inStock
  }
}
```

### Toggle Stock

```graphql
mutation ToggleStock($id: ID!) {
  toggleStock(id: $id) {
    id
    title
    inStock
  }
}
```

### Delete Book


```graphql
mutation DeleteBook($id: ID!) {
  deleteBook(id: $id) {
    id
    title
  }
}
```

## Testing Steps

1. Start MongoDB locally.
2. Run the server from `graphql-lab` with `npm run dev` or `npm start`.
3. Open `http://localhost:4000/graphql`.
4. Run the operations from `test_queries.graphql`.
5. Compare outputs with `query_results.md`.

## Notes

Use real book IDs returned by `books` or `addBook` when testing `book`, `updateBook`, `toggleStock`, and `deleteBook`.
