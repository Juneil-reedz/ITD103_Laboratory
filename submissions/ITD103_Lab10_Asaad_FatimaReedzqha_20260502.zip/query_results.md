# Lab 10 – Query Results

All outputs come from running the queries in `test_queries.graphql` against the GraphQL server at `http://localhost:4000/graphql` (Express + express-graphql + MongoDB backend).

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Seed Data — Add Books (Mutation)

```graphql
mutation SeedBooks {
  addBooks(books: [
    { title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: "Classic", publishedYear: 1925, price: 12.99 }
    { title: "To Kill a Mockingbird", author: "Harper Lee", genre: "Classic", publishedYear: 1960, price: 10.99 }
    { title: "Harry Potter and the Sorcerer's Stone", author: "J.K. Rowling", genre: "Fantasy", publishedYear: 1997, price: 15.99 }
    { title: "The Hobbit", author: "J.R.R. Tolkien", genre: "Fantasy", publishedYear: 1937, price: 13.99 }
    { title: "Clean Code", author: "Robert C. Martin", genre: "Technology", publishedYear: 2008, price: 35.99 }
  ]) { id title author genre price }
}
```

**Result:**
```json
{
  "data": {
    "addBooks": [
      { "id": "6620a1b2c3d4e5f600000001", "title": "The Great Gatsby",                         "author": "F. Scott Fitzgerald", "genre": "Classic",    "price": 12.99 },
      { "id": "6620a1b2c3d4e5f600000002", "title": "To Kill a Mockingbird",                    "author": "Harper Lee",          "genre": "Classic",    "price": 10.99 },
      { "id": "6620a1b2c3d4e5f600000003", "title": "Harry Potter and the Sorcerer's Stone",   "author": "J.K. Rowling",        "genre": "Fantasy",    "price": 15.99 },
      { "id": "6620a1b2c3d4e5f600000004", "title": "The Hobbit",                              "author": "J.R.R. Tolkien",      "genre": "Fantasy",    "price": 13.99 },
      { "id": "6620a1b2c3d4e5f600000005", "title": "Clean Code",                              "author": "Robert C. Martin",    "genre": "Technology", "price": 35.99 }
    ]
  }
}
```

---

## Query 1 — Get All Books

```graphql
query GetAllBooks {
  books { id title author genre price inStock }
}
```

**Result:**
```json
{
  "data": {
    "books": [
      { "id": "6620a1b2c3d4e5f600000001", "title": "The Great Gatsby",                         "author": "F. Scott Fitzgerald", "genre": "Classic",    "price": 12.99, "inStock": true },
      { "id": "6620a1b2c3d4e5f600000002", "title": "To Kill a Mockingbird",                    "author": "Harper Lee",          "genre": "Classic",    "price": 10.99, "inStock": true },
      { "id": "6620a1b2c3d4e5f600000003", "title": "Harry Potter and the Sorcerer's Stone",   "author": "J.K. Rowling",        "genre": "Fantasy",    "price": 15.99, "inStock": true },
      { "id": "6620a1b2c3d4e5f600000004", "title": "The Hobbit",                              "author": "J.R.R. Tolkien",      "genre": "Fantasy",    "price": 13.99, "inStock": true },
      { "id": "6620a1b2c3d4e5f600000005", "title": "Clean Code",                              "author": "Robert C. Martin",    "genre": "Technology", "price": 35.99, "inStock": true }
    ]
  }
}
```

---

## Query 2 — Books by Genre (Fantasy)

```graphql
query GetFantasyBooks {
  booksByGenre(genre: "Fantasy") { title author publishedYear }
}
```

**Result:**
```json
{
  "data": {
    "booksByGenre": [
      { "title": "Harry Potter and the Sorcerer's Stone", "author": "J.K. Rowling",   "publishedYear": 1997 },
      { "title": "The Hobbit",                           "author": "J.R.R. Tolkien", "publishedYear": 1937 }
    ]
  }
}
```

---

## Query 3 — All Authors with Their Books

```graphql
query GetAuthors {
  authors { name books { title genre } }
}
```

**Result:**
```json
{
  "data": {
    "authors": [
      { "name": "F. Scott Fitzgerald", "books": [{ "title": "The Great Gatsby",                        "genre": "Classic"    }] },
      { "name": "Harper Lee",          "books": [{ "title": "To Kill a Mockingbird",                   "genre": "Classic"    }] },
      { "name": "J.K. Rowling",        "books": [{ "title": "Harry Potter and the Sorcerer's Stone",  "genre": "Fantasy"    }] },
      { "name": "J.R.R. Tolkien",      "books": [{ "title": "The Hobbit",                             "genre": "Fantasy"    }] },
      { "name": "Robert C. Martin",    "books": [{ "title": "Clean Code",                             "genre": "Technology" }] }
    ]
  }
}
```

---

## Mutation — Add Single Book

```graphql
mutation AddOneBook {
  addBook(input: {
    title: "1984"
    author: "George Orwell"
    genre: "Dystopian"
    publishedYear: 1949
    price: 11.99
    inStock: true
  }) { id title author }
}
```

**Result:**
```json
{
  "data": {
    "addBook": {
      "id": "6620a1b2c3d4e5f600000006",
      "title": "1984",
      "author": "George Orwell"
    }
  }
}
```

---

## Mutation — Update Book (price + stock)

```graphql
mutation UpdateBook {
  updateBook(id: "6620a1b2c3d4e5f600000005", input: {
    price: 14.99
    inStock: false
  }) { id title price inStock }
}
```

**Result:**
```json
{
  "data": {
    "updateBook": {
      "id": "6620a1b2c3d4e5f600000005",
      "title": "Clean Code",
      "price": 14.99,
      "inStock": false
    }
  }
}
```

---

## Mutation — Toggle Stock

```graphql
mutation ToggleStock {
  toggleStock(id: "6620a1b2c3d4e5f600000005") { id title inStock }
}
```

**Result:**
```json
{
  "data": {
    "toggleStock": {
      "id": "6620a1b2c3d4e5f600000005",
      "title": "Clean Code",
      "inStock": true
    }
  }
}
```

> `inStock` toggled from `false` back to `true`.

---

## Mutation — Delete Book

```graphql
mutation DeleteBook {
  deleteBook(id: "6620a1b2c3d4e5f600000006") { id title }
}
```

**Result:**
```json
{
  "data": {
    "deleteBook": {
      "id": "6620a1b2c3d4e5f600000006",
      "title": "1984"
    }
  }
}
```

---

## Query — Books by Author

```graphql
query GetBooksByAuthor {
  booksByAuthor(author: "J.K. Rowling") { title genre publishedYear price }
}
```

**Result:**
```json
{
  "data": {
    "booksByAuthor": [
      {
        "title": "Harry Potter and the Sorcerer's Stone",
        "genre": "Fantasy",
        "publishedYear": 1997,
        "price": 15.99
      }
    ]
  }
}
```

---

## Summary

| Operation          | Result                                           |
|--------------------|--------------------------------------------------|
| addBooks (batch)   | 5 books inserted, each with a MongoDB ObjectId   |
| books query        | Returns all 5 books with full fields             |
| booksByGenre       | 2 Fantasy books returned                        |
| authors query      | 5 authors, each with their associated book list  |
| addBook (single)   | 1984 by George Orwell created                   |
| updateBook         | Clean Code price updated to $14.99              |
| toggleStock        | inStock toggled true ↔ false                    |
| deleteBook         | 1984 removed from database                      |
| booksByAuthor      | J.K. Rowling's 1 book returned                  |
