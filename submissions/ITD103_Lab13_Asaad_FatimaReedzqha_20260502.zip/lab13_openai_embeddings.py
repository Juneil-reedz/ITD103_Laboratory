# =============================================================
# Lab 13 - Exercise 2: OpenAI-style Embeddings
# Requires OPENAI_API_KEY for real API embeddings.
# Falls back to deterministic 1536-dim local embeddings when no key/client exists.
# Run: python lab13_openai_embeddings.py
# =============================================================

import hashlib
import os
import re

import numpy as np
import pandas as pd

DATASET_PATH = '../../datasets/articles.csv'
EMBEDDING_PATH = '../../datasets/openai_embeddings.npy'
DIMENSION = 1536


def fallback_embed(texts, dimension=DIMENSION):
    vectors = np.zeros((len(texts), dimension), dtype=np.float32)
    for row, text in enumerate(texts):
        tokens = re.findall(r'[a-z0-9]+', text.lower())
        for token in tokens:
            digest = hashlib.sha256(token.encode('utf-8')).digest()
            index = int.from_bytes(digest[:4], 'little') % dimension
            sign = 1.0 if digest[4] % 2 == 0 else -1.0
            vectors[row, index] += sign
        norm = np.linalg.norm(vectors[row])
        if norm:
            vectors[row] /= norm
    return vectors


def cosine_similarity(query_vector, matrix):
    query_norm = np.linalg.norm(query_vector)
    matrix_norms = np.linalg.norm(matrix, axis=1)
    denominator = np.maximum(query_norm * matrix_norms, 1e-12)
    return matrix @ query_vector / denominator


df = pd.read_csv(DATASET_PATH)
texts = df['content'].tolist()
api_key = os.getenv('OPENAI_API_KEY')

embeddings = None
model_name = 'Offline OpenAI-style hashing fallback, 1536-dim'

if api_key:
    try:
        from openai import OpenAI

        client = OpenAI(api_key=api_key)
        response = client.embeddings.create(model='text-embedding-3-small', input=texts)
        embeddings = np.array([item.embedding for item in response.data], dtype=np.float32)
        model_name = 'OpenAI text-embedding-3-small'
    except Exception as error:
        print(f'OpenAI embedding call unavailable, using fallback: {error}')

if embeddings is None:
    embeddings = fallback_embed(texts)

os.makedirs(os.path.dirname(EMBEDDING_PATH), exist_ok=True)
np.save(EMBEDDING_PATH, embeddings)

print(f'Loaded articles: {len(df)}')
print(f'Model: {model_name}')
print(f'Embeddings shape: {embeddings.shape}')
print(f'Saved to: {EMBEDDING_PATH}')


def semantic_search(query, top_k=3):
    query_embedding = fallback_embed([query], embeddings.shape[1])[0]
    scores = cosine_similarity(query_embedding, embeddings)
    top_indices = np.argsort(-scores)[:top_k]

    print(f"\nQuery: {query}")
    for rank, idx in enumerate(top_indices, 1):
        print(f"{rank}. {df.iloc[idx]['title']} [{df.iloc[idx]['category']}] score={scores[idx]:.4f}")


for query in [
    'database optimization techniques',
    'healthy nutrition and lifestyle',
    'machine learning applications'
]:
    semantic_search(query)
