# =============================================================
# Lab 13 - Exercise 3: Embedding Visualization
# Run AFTER embedding generation scripts.
# Run: python lab13_visualization.py
# =============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATASET_PATH = '../../datasets/articles.csv'
ST_PATH = '../../datasets/article_embeddings.npy'
OPENAI_PATH = '../../datasets/openai_embeddings.npy'
OUTPUT_PATH = '../../datasets/embedding_visualization.png'


def pca_2d(matrix):
    centered = matrix - matrix.mean(axis=0, keepdims=True)
    _, _, vt = np.linalg.svd(centered, full_matrices=False)
    return centered @ vt[:2].T


def cosine_matrix(matrix):
    norms = np.maximum(np.linalg.norm(matrix, axis=1, keepdims=True), 1e-12)
    normalized = matrix / norms
    return normalized @ normalized.T


def silhouette_by_category(matrix, categories):
    similarities = cosine_matrix(matrix)
    distances = 1 - similarities
    scores = []
    categories = np.array(categories)

    for idx, category in enumerate(categories):
        same = np.where(categories == category)[0]
        other_categories = [c for c in np.unique(categories) if c != category]

        same = same[same != idx]
        a = distances[idx, same].mean() if len(same) else 0.0
        b = min(distances[idx, categories == other].mean() for other in other_categories)
        scores.append((b - a) / max(a, b, 1e-12))

    return float(np.mean(scores))


df = pd.read_csv(DATASET_PATH)
st_embeddings = np.load(ST_PATH)
openai_embeddings = np.load(OPENAI_PATH)

st_2d = pca_2d(st_embeddings)
openai_2d = pca_2d(openai_embeddings)
categories = df['category'].to_numpy()
unique_categories = sorted(df['category'].unique())
colors = plt.cm.Set2(np.linspace(0, 1, len(unique_categories)))
category_color = dict(zip(unique_categories, colors))

fig, axes = plt.subplots(1, 2, figsize=(15, 6))

for ax, data, title in [
    (axes[0], st_2d, 'SentenceTransformer/Fallback Embeddings - PCA'),
    (axes[1], openai_2d, 'OpenAI-style Embeddings - PCA')
]:
    for category in unique_categories:
        mask = categories == category
        ax.scatter(data[mask, 0], data[mask, 1], label=category, color=category_color[category], s=90, alpha=0.85)
    for idx, row in df.iterrows():
        ax.annotate(str(row['id']), (data[idx, 0], data[idx, 1]), fontsize=9, xytext=(4, 4), textcoords='offset points')
    ax.set_title(title)
    ax.set_xlabel('PC1')
    ax.set_ylabel('PC2')
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8)

plt.tight_layout()
plt.savefig(OUTPUT_PATH, dpi=300, bbox_inches='tight')

st_silhouette = silhouette_by_category(st_embeddings, categories)
openai_silhouette = silhouette_by_category(openai_embeddings, categories)

print(f'SentenceTransformer embeddings: {st_embeddings.shape}')
print(f'OpenAI-style embeddings: {openai_embeddings.shape}')
print(f'SentenceTransformer silhouette: {st_silhouette:.4f}')
print(f'OpenAI-style silhouette: {openai_silhouette:.4f}')
print(f'Visualization saved to: {OUTPUT_PATH}')
