# Lab 13 - Performance Comparison Between Models

## Models Compared

| Model | Output File | Dimensions | Runtime Requirement |
|-------|-------------|------------|---------------------|
| SentenceTransformer `all-MiniLM-L6-v2` or offline fallback | `article_embeddings.npy` | 384 | Local CPU |
| OpenAI embedding model or offline OpenAI-style fallback | `openai_embeddings.npy` | 1536 | API key for real OpenAI, local CPU for fallback |

## Comparison

| Metric | SentenceTransformer / 384-dim | OpenAI-style / 1536-dim |
|--------|--------------------------------|--------------------------|
| Storage for 10 articles | ~15 KB | ~60 KB |
| Search implementation | Cosine similarity over NumPy arrays | Cosine similarity over NumPy arrays |
| Expected latency | Lower because vectors are smaller | Higher because vectors are 4x larger |
| Accuracy expectation | Good for local/offline semantic search | Usually stronger with real OpenAI embeddings |
| Cost | Free/local | API cost when using real OpenAI embeddings |
| Best use case | Offline labs, privacy, low latency | Production quality semantic search |

## Analysis

The 384-dimensional model is more efficient for storage and local similarity search. The 1536-dimensional OpenAI-style embedding uses more memory and compute but represents the architecture used by higher-capacity cloud embedding models.

For this small 10-article dataset, both models are fast. The main difference is operational: local embeddings are free and reproducible, while OpenAI embeddings require network access and an API key but normally provide stronger semantic matching quality.
