# =============================================================
# Lab 13 - Exercise 1: Sentence Transformers Embeddings
# Run: python lab13_sentence_transformers.py
# =============================================================

import hashlib
import os
import re

import numpy as np
import pandas as pd

DATASET_PATH = '../../datasets/articles.csv'
EMBEDDING_PATH = '../../datasets/article_embeddings.npy'
DIMENSION = 384


def fallback_embed(texts, dimension=DIMENSION):
    """Deterministic local fallback used when sentence-transformers is unavailable."""
    vectors = np.zeros((len(texts), dimension), dtype=np.float32)
    for row, text in enumerate(texts):
        tokens = re.findall(r'[a-z0-9]+', text.lower())
        for token in tokens:
            digest = hashlib.md5(token.encode('utf-8')).digest()
            index = int.from_bytes(digest[:4], 'little') % dimension
            sign = 1.0 if digest[4] % 2 == 0 else -1.0
            vectors[row, index] += sign
        norm = np.linalg.norm(vectors[row])
        if norm:
            vectors[row] /= norm
    return vectors


def cosine_similarity(query_vector, matrix):
    query_norm = np.linalg.norm(query_vector)
    matrix_norms = np.linalg.norm(matrix, axis=1)
    denominator = np.maximum(query_norm * matrix_norms, 1e-12)
    return matrix @ query_vector / denominator


df = pd.read_csv(DATASET_PATH)
texts = df['content'].tolist()

try:
    from sentence_transformers import SentenceTransformer

    print('Loading SentenceTransformer model: all-MiniLM-L6-v2')
    model = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = model.encode(texts, show_progress_bar=True).astype(np.float32)
    encode_query = lambda query: model.encode([query]).astype(np.float32)[0]
    model_name = 'SentenceTransformer all-MiniLM-L6-v2'
except Exception as error:
    print(f'SentenceTransformers unavailable, using offline fallback: {error}')
    embeddings = fallback_embed(texts)
    encode_query = lambda query: fallback_embed([query])[0]
    model_name = 'Offline hashing fallback, 384-dim'

os.makedirs(os.path.dirname(EMBEDDING_PATH), exist_ok=True)
np.save(EMBEDDING_PATH, embeddings)

print(f'Loaded articles: {len(df)}')
print(f'Model: {model_name}')
print(f'Embeddings shape: {embeddings.shape}')
print(f'Saved to: {EMBEDDING_PATH}')


def semantic_search(query, top_k=3):
    query_embedding = encode_query(query)
    scores = cosine_similarity(query_embedding, embeddings)
    top_indices = np.argsort(-scores)[:top_k]

    print(f"\nQuery: {query}")
    for rank, idx in enumerate(top_indices, 1):
        print(f"{rank}. {df.iloc[idx]['title']} [{df.iloc[idx]['category']}] score={scores[idx]:.4f}")


for query in [
    'How to improve database performance?',
    'What are the benefits of healthy food?',
    'Latest trends in artificial intelligence',
    'Environmental and climate issues'
]:
    semantic_search(query)
