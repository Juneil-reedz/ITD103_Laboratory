# =============================================================
# Lab 13 - Similarity Search Implementation
# Run after generating embeddings: python lab13_similarity_search.py
# =============================================================

import hashlib
import re

import numpy as np
import pandas as pd

DATASET_PATH = '../../datasets/articles.csv'
ST_PATH = '../../datasets/article_embeddings.npy'
OPENAI_PATH = '../../datasets/openai_embeddings.npy'


def fallback_embed(texts, dimension, algorithm='md5'):
    vectors = np.zeros((len(texts), dimension), dtype=np.float32)
    for row, text in enumerate(texts):
        for token in re.findall(r'[a-z0-9]+', text.lower()):
            digest = (hashlib.md5 if algorithm == 'md5' else hashlib.sha256)(token.encode('utf-8')).digest()
            index = int.from_bytes(digest[:4], 'little') % dimension
            vectors[row, index] += 1.0 if digest[4] % 2 == 0 else -1.0
        norm = np.linalg.norm(vectors[row])
        if norm:
            vectors[row] /= norm
    return vectors


def search(query, embeddings, dimension, algorithm, top_k=3):
    query_vector = fallback_embed([query], dimension, algorithm)[0]
    scores = embeddings @ query_vector / np.maximum(np.linalg.norm(embeddings, axis=1) * np.linalg.norm(query_vector), 1e-12)
    return np.argsort(-scores)[:top_k], scores


df = pd.read_csv(DATASET_PATH)
models = [
    ('SentenceTransformer/fallback', np.load(ST_PATH), 'md5'),
    ('OpenAI-style/fallback', np.load(OPENAI_PATH), 'sha256')
]

queries = [
    'database query optimization',
    'artificial intelligence machine learning',
    'healthy lifestyle and mental health',
    'climate and renewable energy'
]

for query in queries:
    print(f'\nQuery: {query}')
    for name, embeddings, algorithm in models:
        indices, scores = search(query, embeddings, embeddings.shape[1], algorithm)
        print(f'  {name}')
        for rank, idx in enumerate(indices, 1):
            print(f"    {rank}. {df.iloc[idx]['title']} [{df.iloc[idx]['category']}] score={scores[idx]:.4f}")
