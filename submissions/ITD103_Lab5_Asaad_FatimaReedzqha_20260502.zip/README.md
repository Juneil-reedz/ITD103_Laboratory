# Lab 5: Aggregation Framework

## Objectives
- Master aggregation pipeline stages
- Implement complex data transformations
- Optimize aggregation performance

## Files
| File | Description |
|------|-------------|
| `part_a_import.sh` | Import `sales.json` and `customers.json` |
| `exercise1_basic_aggregation.js` | `$group`, `$sort`, `$bucket`, `$bucketAuto` |
| `exercise2_complex_pipeline.js` | `$match`, `$lookup`, `$unwind`, `$addFields`, `$project` |
| `exercise3_facets_buckets.js` | `$facet`, `$bucketAuto`, `$sortByCount`, `$setWindowFields` |
| `query_results.md` | Expected output for all exercises with explanations |

---

## Step 1 – Import the Datasets

> **Note:** `mongoimport` requires the MongoDB Database Tools package. If it is not installed, use the `insertMany` method below instead.

### Option A — mongoimport (if installed)

```bash
mongoimport --db sales --collection transactions --file itd103-labs/datasets/sales.json --jsonArray
mongoimport --db sales --collection customers    --file itd103-labs/datasets/customers.json --jsonArray
```

### Option B — insertMany inside mongosh (no extra tools needed)

Open mongosh, then run:

```bash
mongosh
```

```js
use sales

db.transactions.insertMany([
  { "_id": 1,  "customer_id": "C001", "category": "Electronics", "product": "Laptop",         "amount": 1200.00, "date": new Date("2024-01-05T10:30:00Z"), "region": "North" },
  { "_id": 2,  "customer_id": "C002", "category": "Clothing",    "product": "Jacket",          "amount": 89.99,   "date": new Date("2024-01-12T14:00:00Z"), "region": "South" },
  { "_id": 3,  "customer_id": "C001", "category": "Electronics", "product": "Mouse",           "amount": 35.00,   "date": new Date("2024-01-18T09:00:00Z"), "region": "North" },
  { "_id": 4,  "customer_id": "C003", "category": "Books",       "product": "NoSQL Guide",     "amount": 45.00,   "date": new Date("2024-02-03T11:00:00Z"), "region": "East"  },
  { "_id": 5,  "customer_id": "C002", "category": "Electronics", "product": "Headphones",      "amount": 150.00,  "date": new Date("2024-02-14T16:30:00Z"), "region": "South" },
  { "_id": 6,  "customer_id": "C004", "category": "Books",       "product": "Python Basics",   "amount": 39.99,   "date": new Date("2024-02-20T08:00:00Z"), "region": "West"  },
  { "_id": 7,  "customer_id": "C003", "category": "Clothing",    "product": "Shoes",           "amount": 120.00,  "date": new Date("2024-03-01T13:00:00Z"), "region": "East"  },
  { "_id": 8,  "customer_id": "C005", "category": "Electronics", "product": "Tablet",          "amount": 499.00,  "date": new Date("2024-03-10T10:00:00Z"), "region": "North" },
  { "_id": 9,  "customer_id": "C001", "category": "Books",       "product": "MongoDB Docs",    "amount": 55.00,   "date": new Date("2024-03-22T15:00:00Z"), "region": "North" },
  { "_id": 10, "customer_id": "C004", "category": "Clothing",    "product": "T-Shirt",         "amount": 25.00,   "date": new Date("2024-04-05T09:30:00Z"), "region": "West"  },
  { "_id": 11, "customer_id": "C005", "category": "Electronics", "product": "Keyboard",        "amount": 75.00,   "date": new Date("2024-04-12T11:00:00Z"), "region": "North" },
  { "_id": 12, "customer_id": "C002", "category": "Books",       "product": "Graph Databases", "amount": 49.00,   "date": new Date("2024-04-18T14:30:00Z"), "region": "South" },
  { "_id": 13, "customer_id": "C006", "category": "Electronics", "product": "Monitor",         "amount": 320.00,  "date": new Date("2024-05-03T10:00:00Z"), "region": "East"  },
  { "_id": 14, "customer_id": "C003", "category": "Clothing",    "product": "Pants",           "amount": 65.00,   "date": new Date("2024-05-15T16:00:00Z"), "region": "East"  },
  { "_id": 15, "customer_id": "C006", "category": "Books",       "product": "Data Science",    "amount": 60.00,   "date": new Date("2024-05-25T08:30:00Z"), "region": "East"  },
  { "_id": 16, "customer_id": "C001", "category": "Electronics", "product": "USB Hub",         "amount": 28.00,   "date": new Date("2024-06-01T12:00:00Z"), "region": "North" },
  { "_id": 17, "customer_id": "C005", "category": "Clothing",    "product": "Hat",             "amount": 18.00,   "date": new Date("2024-06-10T14:00:00Z"), "region": "North" },
  { "_id": 18, "customer_id": "C004", "category": "Electronics", "product": "Webcam",          "amount": 90.00,   "date": new Date("2024-06-20T10:30:00Z"), "region": "West"  },
  { "_id": 19, "customer_id": "C002", "category": "Clothing",    "product": "Hoodie",          "amount": 55.00,   "date": new Date("2024-07-04T09:00:00Z"), "region": "South" },
  { "_id": 20, "customer_id": "C006", "category": "Electronics", "product": "SSD Drive",       "amount": 110.00,  "date": new Date("2024-07-15T11:00:00Z"), "region": "East"  }
])

db.customers.insertMany([
  { "_id": "C001", "name": "Alice Santos",  "email": "alice@email.com",   "city": "Manila",      "joined": new Date("2023-01-10T00:00:00Z") },
  { "_id": "C002", "name": "Bob Reyes",     "email": "bob@email.com",     "city": "Cebu",        "joined": new Date("2023-03-22T00:00:00Z") },
  { "_id": "C003", "name": "Charlie Cruz",  "email": "charlie@email.com", "city": "Davao",       "joined": new Date("2023-05-15T00:00:00Z") },
  { "_id": "C004", "name": "Diana Lim",     "email": "diana@email.com",   "city": "Quezon City", "joined": new Date("2023-07-01T00:00:00Z") },
  { "_id": "C005", "name": "Edward Tan",    "email": "edward@email.com",  "city": "Makati",      "joined": new Date("2023-09-18T00:00:00Z") },
  { "_id": "C006", "name": "Fiona Garcia",  "email": "fiona@email.com",   "city": "Pasig",       "joined": new Date("2023-11-05T00:00:00Z") }
])
```

---

## Step 2 – Verify the Import

Inside mongosh:
```js
use sales
db.transactions.countDocuments()  // should return 20
db.customers.countDocuments()     // should return 6
```

---

## Step 3 – Exercise 1: Basic Aggregation

Run the full file:
```bash
mongosh --file itd103-labs/lab4-6-mongodb/lab5/exercise1_basic_aggregation.js
```

Or run manually inside mongosh (`use sales` first):

### 1. Total sales per category
```js
db.transactions.aggregate([
  { $group: { _id: "$category", totalSales: { $sum: "$amount" }, transactionCount: { $sum: 1 } } },
  { $sort: { totalSales: -1 } }
])
```
Expected:
```
Electronics  $2507.00   9 transactions
Clothing     $372.99    6 transactions
Books        $248.99    5 transactions
```

### 2. Average transaction amount per month
```js
db.transactions.aggregate([
  { $group: { _id: { year: { $year: "$date" }, month: { $month: "$date" } }, avgAmount: { $avg: "$amount" }, count: { $sum: 1 } } },
  { $sort: { "_id.year": 1, "_id.month": 1 } }
])
```
Expected: Jan avg $441.66 (highest — Laptop purchase), Jun avg $45.33 (lowest)

### BONUS 3. Sales by region
```js
db.transactions.aggregate([
  { $group: { _id: "$region", totalSales: { $sum: "$amount" }, avgSale: { $avg: "$amount" }, count: { $sum: 1 } } },
  { $sort: { totalSales: -1 } }
])
```
Expected: North $1,910 › East $720 › South $343.99 › West $154.99

### BONUS 4. Top 5 products by revenue
```js
db.transactions.aggregate([
  { $group: { _id: "$product", revenue: { $sum: "$amount" }, unitsSold: { $sum: 1 } } },
  { $sort: { revenue: -1 } },
  { $limit: 5 },
  { $project: { product: "$_id", revenue: { $round: ["$revenue", 2] }, unitsSold: 1, _id: 0 } }
])
```
Expected: Laptop($1200) › Tablet($499) › Monitor($320) › Headphones($150) › Shoes($120)

### BONUS 5. `$bucket` – Transactions by price range
```js
db.transactions.aggregate([
  { $bucket: { groupBy: "$amount", boundaries: [0, 50, 100, 200, 500, 1500], default: "Other", output: { count: { $sum: 1 }, totalRevenue: { $sum: "$amount" } } } }
])
```
Expected: 7 transactions under $50, 7 between $50-$100, 3 between $100-$200, 2 between $200-$500, 1 over $500

---

## Step 4 – Exercise 2: Complex Pipeline (Customer Lifetime Value)

Run the full file:
```bash
mongosh --file itd103-labs/lab4-6-mongodb/lab5/exercise2_complex_pipeline.js
```

Or run manually inside mongosh:

### CLV Pipeline (7 stages)
```js
db.transactions.aggregate([
  { $match: { date: { $gte: new Date("2024-01-01") } } },
  { $lookup: { from: "customers", localField: "customer_id", foreignField: "_id", as: "customer" } },
  { $unwind: "$customer" },
  { $group: {
      _id: "$customer._id",
      customerName:     { $first: "$customer.name" },
      city:             { $first: "$customer.city" },
      totalSpent:       { $sum: "$amount" },
      transactionCount: { $sum: 1 },
      firstPurchase:    { $min: "$date" },
      lastPurchase:     { $max: "$date" }
  }},
  { $addFields: {
      avgTransaction: { $divide: ["$totalSpent", "$transactionCount"] },
      customerSinceDays: { $floor: { $divide: [{ $subtract: [new Date(), "$firstPurchase"] }, 86400000] } },
      daysSinceLastPurchase: { $floor: { $divide: [{ $subtract: [new Date(), "$lastPurchase"] }, 86400000] } }
  }},
  { $sort: { totalSpent: -1 } },
  { $project: { _id: 0, customerName: 1, city: 1, totalSpent: { $round: ["$totalSpent", 2] }, transactionCount: 1, avgTransaction: { $round: ["$avgTransaction", 2] }, customerSinceDays: 1, daysSinceLastPurchase: 1 } }
])
```
Expected (sorted by total spend):
```
1. Alice Santos   Manila       $1318.00  4 txns  avg $329.50
2. Edward Tan     Makati       $592.00   3 txns  avg $197.33
3. Fiona Garcia   Pasig        $490.00   3 txns  avg $163.33
4. Bob Reyes      Cebu         $343.99   4 txns  avg $86.00
5. Charlie Cruz   Davao        $230.00   3 txns  avg $76.67
6. Diana Lim      Quezon City  $154.99   3 txns  avg $51.66
```

### BONUS: Top category per customer
```js
db.transactions.aggregate([
  { $group: { _id: { customer: "$customer_id", category: "$category" }, spent: { $sum: "$amount" } } },
  { $sort: { "_id.customer": 1, spent: -1 } },
  { $group: { _id: "$_id.customer", topCategory: { $first: "$_id.category" }, topCategorySpend: { $first: "$spent" } } },
  { $sort: { _id: 1 } }
])
```
Expected: 5 of 6 customers top in Electronics; only Charlie Cruz tops in Clothing ($185)

---

## Step 5 – Exercise 3: Facets & Buckets

Run the full file:
```bash
mongosh --file itd103-labs/lab4-6-mongodb/lab5/exercise3_facets_buckets.js
```

Or run manually inside mongosh:

### `$facet` – Multi-dimensional analysis in one pass
```js
db.transactions.aggregate([{
  $facet: {
    byCategory:   [{ $group: { _id: "$category", total: { $sum: "$amount" } } }, { $sort: { total: -1 } }],
    byMonth:      [{ $group: { _id: { $month: "$date" }, total: { $sum: "$amount" }, count: { $sum: 1 } } }, { $sort: { _id: 1 } }],
    topCustomers: [{ $group: { _id: "$customer_id", total: { $sum: "$amount" } } }, { $sort: { total: -1 } }, { $limit: 10 }],
    summary:      [{ $group: { _id: null, totalSales: { $sum: "$amount" }, avgSale: { $avg: "$amount" }, minSale: { $min: "$amount" }, maxSale: { $max: "$amount" }, transactionCount: { $sum: 1 } } }, { $project: { _id: 0, totalSales: { $round: ["$totalSales", 2] }, avgSale: { $round: ["$avgSale", 2] }, minSale: 1, maxSale: 1, transactionCount: 1 } }],
    byRegion:     [{ $group: { _id: "$region", total: { $sum: "$amount" }, count: { $sum: 1 } } }, { $sort: { total: -1 } }]
  }
}])
```
Expected summary: totalSales $3128.98, avgSale $156.45, min $18, max $1200, 20 transactions

### `$bucketAuto` – 5 auto-sized price buckets
```js
db.transactions.aggregate([
  { $bucketAuto: { groupBy: "$amount", buckets: 5, output: { count: { $sum: 1 }, totalRevenue: { $sum: "$amount" }, avgAmount: { $avg: "$amount" } } } }
])
```
Expected: 5 buckets auto-distributed from $18 to $1,200

### `$sortByCount` – Most common categories
```js
db.transactions.aggregate([
  { $unwind: "$category" },
  { $sortByCount: "$category" }
])
```
Expected: Electronics(9) › Clothing(6) › Books(5)

### BONUS: `$setWindowFields` – Running total by date
```js
db.transactions.aggregate([
  { $sort: { date: 1 } },
  { $setWindowFields: { sortBy: { date: 1 }, output: { runningTotal: { $sum: "$amount", window: { documents: ["unbounded", "current"] } } } } },
  { $project: { _id: 0, date: 1, amount: 1, category: 1, runningTotal: { $round: ["$runningTotal", 2] } } }
])
```
Expected: starts at $1,200.00 (Jan 5 Laptop), ends at $3,128.98 (Jul 15 SSD Drive)

---

## Aggregation Stage Reference
| Stage | Purpose |
|-------|---------|
| `$match` | Filter documents (use early to reduce pipeline input) |
| `$group` | Group by field, apply accumulators (`$sum`, `$avg`, `$min`, `$max`) |
| `$lookup` | Left outer join with another collection |
| `$unwind` | Deconstruct array into separate documents |
| `$addFields` | Add computed fields without removing existing ones |
| `$project` | Shape output — include, exclude, rename, compute |
| `$facet` | Run multiple independent pipelines in one pass |
| `$bucket` | Group into user-defined numeric ranges |
| `$setWindowFields` | Running totals, moving averages (MongoDB 5.0+) |

---

## Deliverables
- [x] Complete aggregation pipelines → `exercise1_basic_aggregation.js`, `exercise2_complex_pipeline.js`, `exercise3_facets_buckets.js`
- [x] Performance analysis → `query_results.md` (pipeline stage breakdown)
- [x] Business insights report → `query_results.md` (CLV analysis, category trends, regional breakdown)
