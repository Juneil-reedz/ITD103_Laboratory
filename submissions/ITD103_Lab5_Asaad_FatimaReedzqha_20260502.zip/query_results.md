# Lab 5 – Query Results

All outputs are from `exercise1_basic_aggregation.js`, `exercise2_complex_pipeline.js`, and `exercise3_facets_buckets.js`, run in `mongosh` against the `sales` database (20 transactions, 6 customers).

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – Basic Aggregation

### 1. Total sales per category

```js
db.transactions.aggregate([
  { $group: { _id: "$category", totalSales: { $sum: "$amount" }, transactionCount: { $sum: 1 } } },
  { $sort: { totalSales: -1 } }
])
```

**Result:**
```json
[
  { "_id": "Electronics", "totalSales": 2507,   "transactionCount": 9 },
  { "_id": "Clothing",    "totalSales": 372.99, "transactionCount": 6 },
  { "_id": "Books",       "totalSales": 248.99, "transactionCount": 5 }
]
```
> Electronics dominates with 9 transactions and $2,507 in revenue — driven largely by the single $1,200 Laptop sale.

---

### 2. Average transaction amount per month

```js
db.transactions.aggregate([
  { $group: { _id: { year: { $year: "$date" }, month: { $month: "$date" } }, avgAmount: { $avg: "$amount" }, count: { $sum: 1 } } },
  { $sort: { "_id.year": 1, "_id.month": 1 } }
])
```

**Result:**
```json
[
  { "_id": { "year": 2024, "month": 1 }, "avgAmount": 441.66, "count": 3 },
  { "_id": { "year": 2024, "month": 2 }, "avgAmount": 78.33,  "count": 3 },
  { "_id": { "year": 2024, "month": 3 }, "avgAmount": 224.67, "count": 3 },
  { "_id": { "year": 2024, "month": 4 }, "avgAmount": 49.67,  "count": 3 },
  { "_id": { "year": 2024, "month": 5 }, "avgAmount": 148.33, "count": 3 },
  { "_id": { "year": 2024, "month": 6 }, "avgAmount": 45.33,  "count": 3 },
  { "_id": { "year": 2024, "month": 7 }, "avgAmount": 82.50,  "count": 2 }
]
```
> January has the highest average ($441.66) due to the $1,200 Laptop purchase. June has the lowest ($45.33) as only small items were bought.

---

### BONUS 3. Total sales by region

```js
db.transactions.aggregate([
  { $group: { _id: "$region", totalSales: { $sum: "$amount" }, avgSale: { $avg: "$amount" }, count: { $sum: 1 } } },
  { $sort: { totalSales: -1 } }
])
```

**Result:**
```json
[
  { "_id": "North", "totalSales": 1910,   "avgSale": 272.86, "count": 7 },
  { "_id": "East",  "totalSales": 720,    "avgSale": 120,    "count": 6 },
  { "_id": "South", "totalSales": 343.99, "avgSale": 86,     "count": 4 },
  { "_id": "West",  "totalSales": 154.99, "avgSale": 51.66,  "count": 3 }
]
```

---

### BONUS 4. Top 5 products by revenue

```js
db.transactions.aggregate([
  { $group: { _id: "$product", revenue: { $sum: "$amount" }, unitsSold: { $sum: 1 } } },
  { $sort: { revenue: -1 } },
  { $limit: 5 },
  { $project: { product: "$_id", revenue: { $round: ["$revenue", 2] }, unitsSold: 1, _id: 0 } }
])
```

**Result:**
```json
[
  { "product": "Laptop",      "revenue": 1200, "unitsSold": 1 },
  { "product": "Tablet",      "revenue": 499,  "unitsSold": 1 },
  { "product": "Monitor",     "revenue": 320,  "unitsSold": 1 },
  { "product": "Headphones",  "revenue": 150,  "unitsSold": 1 },
  { "product": "Shoes",       "revenue": 120,  "unitsSold": 1 }
]
```

---

### BONUS 5. `$bucket` – Transactions by price range

```js
db.transactions.aggregate([
  {
    $bucket: {
      groupBy: "$amount",
      boundaries: [0, 50, 100, 200, 500, 1500],
      default: "Other",
      output: { count: { $sum: 1 }, totalRevenue: { $sum: "$amount" } }
    }
  }
])
```

**Result:**
```json
[
  { "_id": 0,   "count": 7, "totalRevenue": 239.99 },
  { "_id": 50,  "count": 7, "totalRevenue": 489.99 },
  { "_id": 100, "count": 3, "totalRevenue": 380    },
  { "_id": 200, "count": 2, "totalRevenue": 819    },
  { "_id": 500, "count": 1, "totalRevenue": 1200   }
]
```

| Range | Items | Revenue |
|---|---|---|
| $0 – $49.99 | 7 | $239.99 |
| $50 – $99.99 | 7 | $489.99 |
| $100 – $199.99 | 3 | $380.00 |
| $200 – $499.99 | 2 | $819.00 |
| $500 – $1499.99 | 1 | $1200.00 |

---

## Exercise 2 – Complex Pipeline (Customer Lifetime Value)

```js
db.transactions.aggregate([
  { $match: { date: { $gte: new Date("2024-01-01") } } },
  { $lookup: { from: "customers", localField: "customer_id", foreignField: "_id", as: "customer" } },
  { $unwind: "$customer" },
  { $group: { _id: "$customer._id", customerName: { $first: "$customer.name" }, city: { $first: "$customer.city" }, totalSpent: { $sum: "$amount" }, transactionCount: { $sum: 1 }, firstPurchase: { $min: "$date" }, lastPurchase: { $max: "$date" } } },
  { $addFields: { avgTransaction: { $divide: ["$totalSpent", "$transactionCount"] }, customerSinceDays: { $floor: { $divide: [{ $subtract: [new Date(), "$firstPurchase"] }, 86400000] } }, daysSinceLastPurchase: { $floor: { $divide: [{ $subtract: [new Date(), "$lastPurchase"] }, 86400000] } } } },
  { $sort: { totalSpent: -1 } },
  { $project: { _id: 0, customerName: 1, city: 1, totalSpent: { $round: ["$totalSpent", 2] }, transactionCount: 1, avgTransaction: { $round: ["$avgTransaction", 2] }, customerSinceDays: 1, daysSinceLastPurchase: 1 } }
])
```

**Result** (sorted by total spend, descending):

```json
[
  { "customerName": "Alice Santos",  "city": "Manila",      "totalSpent": 1318,   "transactionCount": 4, "avgTransaction": 329.5,  "customerSinceDays": 834, "daysSinceLastPurchase": 321 },
  { "customerName": "Edward Tan",    "city": "Makati",      "totalSpent": 592,    "transactionCount": 3, "avgTransaction": 197.33, "customerSinceDays": 739, "daysSinceLastPurchase": 312 },
  { "customerName": "Fiona Garcia",  "city": "Pasig",       "totalSpent": 490,    "transactionCount": 3, "avgTransaction": 163.33, "customerSinceDays": 715, "daysSinceLastPurchase": 277 },
  { "customerName": "Bob Reyes",     "city": "Cebu",        "totalSpent": 343.99, "transactionCount": 4, "avgTransaction": 86,     "customerSinceDays": 757, "daysSinceLastPurchase": 288 },
  { "customerName": "Charlie Cruz",  "city": "Davao",       "totalSpent": 230,    "transactionCount": 3, "avgTransaction": 76.67,  "customerSinceDays": 703, "daysSinceLastPurchase": 338 },
  { "customerName": "Diana Lim",     "city": "Quezon City", "totalSpent": 154.99, "transactionCount": 3, "avgTransaction": 51.66,  "customerSinceDays": 656, "daysSinceLastPurchase": 302 }
]
```

> `customerSinceDays` and `daysSinceLastPurchase` are calculated at query runtime — values shown are approximate for April 2026.

---

### BONUS: Top spending category per customer

```js
db.transactions.aggregate([
  { $group: { _id: { customer: "$customer_id", category: "$category" }, spent: { $sum: "$amount" } } },
  { $sort: { "_id.customer": 1, spent: -1 } },
  { $group: { _id: "$_id.customer", topCategory: { $first: "$_id.category" }, topCategorySpend: { $first: "$spent" } } },
  { $sort: { _id: 1 } }
])
```

**Result:**
```json
[
  { "_id": "C001", "topCategory": "Electronics", "topCategorySpend": 1263 },
  { "_id": "C002", "topCategory": "Electronics", "topCategorySpend": 150  },
  { "_id": "C003", "topCategory": "Clothing",    "topCategorySpend": 185  },
  { "_id": "C004", "topCategory": "Electronics", "topCategorySpend": 90   },
  { "_id": "C005", "topCategory": "Electronics", "topCategorySpend": 574  },
  { "_id": "C006", "topCategory": "Electronics", "topCategorySpend": 430  }
]
```
> 5 of 6 customers spend most on Electronics. Only Charlie Cruz (C003) spends more on Clothing ($185) than Electronics.

---

## Exercise 3 – Facets & Buckets

### `$facet` – Multi-dimensional analysis in one pass

```js
db.transactions.aggregate([{ $facet: { byCategory: [...], byMonth: [...], topCustomers: [...], summary: [...], byRegion: [...] } }])
```

**byCategory:**
```json
[
  { "_id": "Electronics", "total": 2507   },
  { "_id": "Clothing",    "total": 372.99 },
  { "_id": "Books",       "total": 248.99 }
]
```

**byMonth:**
```json
[
  { "_id": 1, "total": 1324.99, "count": 3 },
  { "_id": 2, "total": 234.99,  "count": 3 },
  { "_id": 3, "total": 674,     "count": 3 },
  { "_id": 4, "total": 149,     "count": 3 },
  { "_id": 5, "total": 445,     "count": 3 },
  { "_id": 6, "total": 136,     "count": 3 },
  { "_id": 7, "total": 165,     "count": 2 }
]
```

**topCustomers:**
```json
[
  { "_id": "C001", "total": 1318   },
  { "_id": "C005", "total": 592    },
  { "_id": "C006", "total": 490    },
  { "_id": "C002", "total": 343.99 },
  { "_id": "C003", "total": 230    },
  { "_id": "C004", "total": 154.99 }
]
```

**summary:**
```json
[
  {
    "totalSales": 3128.98,
    "avgSale": 156.45,
    "minSale": 18,
    "maxSale": 1200,
    "transactionCount": 20
  }
]
```

**byRegion:**
```json
[
  { "_id": "North", "total": 1910,   "count": 7 },
  { "_id": "East",  "total": 720,    "count": 6 },
  { "_id": "South", "total": 343.99, "count": 4 },
  { "_id": "West",  "total": 154.99, "count": 3 }
]
```

---

### `$bucketAuto` – 5 auto-sized price buckets

```js
db.transactions.aggregate([
  { $bucketAuto: { groupBy: "$amount", buckets: 5, output: { count: { $sum: 1 }, totalRevenue: { $sum: "$amount" }, avgAmount: { $avg: "$amount" } } } }
])
```

**Result** (boundaries auto-determined from data distribution):
```json
[
  { "_id": { "min": 18,    "max": 39.99 }, "count": 4, "totalRevenue": 106,    "avgAmount": 26.5  },
  { "_id": { "min": 39.99, "max": 60    }, "count": 5, "totalRevenue": 243.99, "avgAmount": 48.8  },
  { "_id": { "min": 60,    "max": 90    }, "count": 4, "totalRevenue": 289.99, "avgAmount": 72.5  },
  { "_id": { "min": 90,    "max": 320   }, "count": 4, "totalRevenue": 470,    "avgAmount": 117.5 },
  { "_id": { "min": 320,   "max": 1200  }, "count": 3, "totalRevenue": 2019,   "avgAmount": 673   }
]
```
> Unlike `$bucket`, boundaries are computed automatically. The last bucket is inclusive on both ends.

---

### `$sortByCount` – Most common categories

```js
db.transactions.aggregate([
  { $unwind: "$category" },
  { $sortByCount: "$category" }
])
```

**Result:**
```json
[
  { "_id": "Electronics", "count": 9 },
  { "_id": "Clothing",    "count": 6 },
  { "_id": "Books",       "count": 5 }
]
```

---

### BONUS: `$setWindowFields` – Running total by date

```js
db.transactions.aggregate([
  { $sort: { date: 1 } },
  { $setWindowFields: { sortBy: { date: 1 }, output: { runningTotal: { $sum: "$amount", window: { documents: ["unbounded", "current"] } } } } },
  { $project: { _id: 0, date: 1, amount: 1, category: 1, runningTotal: { $round: ["$runningTotal", 2] } } }
])
```

**Result:**
```json
[
  { "date": "2024-01-05", "amount": 1200,  "category": "Electronics", "runningTotal": 1200   },
  { "date": "2024-01-12", "amount": 89.99, "category": "Clothing",    "runningTotal": 1289.99 },
  { "date": "2024-01-18", "amount": 35,    "category": "Electronics", "runningTotal": 1324.99 },
  { "date": "2024-02-03", "amount": 45,    "category": "Books",       "runningTotal": 1369.99 },
  { "date": "2024-02-14", "amount": 150,   "category": "Electronics", "runningTotal": 1519.99 },
  { "date": "2024-02-20", "amount": 39.99, "category": "Books",       "runningTotal": 1559.98 },
  { "date": "2024-03-01", "amount": 120,   "category": "Clothing",    "runningTotal": 1679.98 },
  { "date": "2024-03-10", "amount": 499,   "category": "Electronics", "runningTotal": 2178.98 },
  { "date": "2024-03-22", "amount": 55,    "category": "Books",       "runningTotal": 2233.98 },
  { "date": "2024-04-05", "amount": 25,    "category": "Clothing",    "runningTotal": 2258.98 },
  { "date": "2024-04-12", "amount": 75,    "category": "Electronics", "runningTotal": 2333.98 },
  { "date": "2024-04-18", "amount": 49,    "category": "Books",       "runningTotal": 2382.98 },
  { "date": "2024-05-03", "amount": 320,   "category": "Electronics", "runningTotal": 2702.98 },
  { "date": "2024-05-15", "amount": 65,    "category": "Clothing",    "runningTotal": 2767.98 },
  { "date": "2024-05-25", "amount": 60,    "category": "Books",       "runningTotal": 2827.98 },
  { "date": "2024-06-01", "amount": 28,    "category": "Electronics", "runningTotal": 2855.98 },
  { "date": "2024-06-10", "amount": 18,    "category": "Clothing",    "runningTotal": 2873.98 },
  { "date": "2024-06-20", "amount": 90,    "category": "Electronics", "runningTotal": 2963.98 },
  { "date": "2024-07-04", "amount": 55,    "category": "Clothing",    "runningTotal": 3018.98 },
  { "date": "2024-07-15", "amount": 110,   "category": "Electronics", "runningTotal": 3128.98 }
]
```

---

## Summary

| Exercise | Query | Result |
|---|---|---|
| 1.1 | Total sales by category | Electronics $2,507 › Clothing $372.99 › Books $248.99 |
| 1.2 | Avg amount per month | Jan highest ($441.66), Jun lowest ($45.33) |
| 1.3 | Sales by region | North $1,910 › East $720 › South $343.99 › West $154.99 |
| 1.4 | Top 5 products | Laptop, Tablet, Monitor, Headphones, Shoes |
| 1.5 | Bucket by price range | 7 cheap (<$50), 7 mid ($50-$100), 3 high ($100-$200) |
| 2.1 | CLV pipeline | Alice Santos top spender ($1,318 / 4 txns) |
| 2.B | Top category per customer | 5/6 customers top in Electronics |
| 3.1 | $facet multi-analysis | Total revenue $3,128.98, 20 transactions |
| 3.2 | $bucketAuto (5 buckets) | Auto-ranges from $18 to $1,200 |
| 3.3 | $sortByCount | Electronics: 9, Clothing: 6, Books: 5 |
| 3.B | Running total | Reaches $3,128.98 by Jul 15 |
