# Lab 3 – Optimization Recommendations

Based on the performance testing results from 100,000 documents.

---

## 1. Always Index High-Frequency Filter Fields

**Finding:** Q1 (category filter) went from 44 ms → 18 ms with a single-field index.

**Recommendation:** Add indexes to fields that appear frequently in `find()` conditions.

```js
// Good: field used repeatedly in queries
db.products.createIndex({ category: 1 })

// Identify which fields are most queried using $indexStats
db.products.aggregate([{ $indexStats: {} }])
```

---

## 2. Use Compound Indexes for Multi-Condition Queries

**Finding:** Q4 (category + price) improved 8.4× using the compound index vs any single-field index.

**Recommendation:** Follow the **ESR Rule** when building compound indexes:
1. **E**quality fields first (`category = "X"`)
2. **S**ort fields second
3. **R**ange fields last (`price < 300`)

```js
// Correct ESR order
db.products.createIndex({ category: 1, price: -1 })

// Wrong — range first makes the index less selective
db.products.createIndex({ price: -1, category: 1 })
```

---

## 3. Add Dedicated Indexes for Range-Only Queries

**Finding:** Q2 (`price > 500` with no category filter) was *slower* with the compound index (186 ms vs 42 ms baseline) because the compound index requires a category prefix to be selective.

**Recommendation:** Add a standalone `{ price: 1 }` index for queries that filter on price alone.

```js
db.products.createIndex({ price: 1 })
```

| Query Pattern | Best Index |
|---|---|
| `{ category: X }` | `{ category: 1 }` |
| `{ category: X, price: Y }` | `{ category: 1, price: -1 }` |
| `{ price: { $gt: Y } }` | `{ price: 1 }` ← add this |

---

## 4. Avoid Over-Indexing

**Finding:** Each index adds storage overhead (~6.5 MB total for 4 indexes on a 37 MB collection = 17% overhead).

**Recommendation:**
- Every index **slows down writes** (INSERT, UPDATE, DELETE must update all indexes)
- Remove unused indexes regularly

```js
// Check which indexes are actually being used
db.products.aggregate([{ $indexStats: {} }])

// Drop an index that is never accessed
db.products.dropIndex("category_1")
```

---

## 5. Use Text Index for Keyword Search (Not Regex)

**Recommendation:** Avoid `{ name: /keyword/i }` — it triggers a COLLSCAN even on indexed fields.

```js
// Bad — bypasses all indexes
db.products.find({ name: /Product 5/i })

// Good — uses text index
db.products.find({ $text: { $search: "Product 5" } })
```

---

## 6. Use `explain("executionStats")` Regularly

**Recommendation:** Always profile slow queries before and after index changes.

```js
// Check query plan
db.products.find({ category: "Category 5" }).explain("executionStats")

// Key fields to check:
// executionStats.executionTimeMillis  → actual time
// executionStats.totalDocsExamined   → lower = better
// executionStats.executionStages.stage → IXSCAN = good, COLLSCAN = investigate
```

---

## Summary Table

| Recommendation | Impact | Effort |
|---|---|---|
| Index high-frequency filter fields | High | Low |
| Use compound indexes (ESR rule) | High | Medium |
| Add dedicated index for price-only queries | Medium | Low |
| Remove unused indexes | Medium | Low |
| Use text index instead of regex | Medium | Low |
| Monitor with `explain()` and `$indexStats` | High (ongoing) | Low |
