# Lab 3 – Index Analysis Report

**Collection:** `performance_lab.products`
**Documents:** 100,000
**MongoDB:** 8.2.6

---

## Indexes Created

| Index Name | Fields | Type | Purpose |
|---|---|---|---|
| `_id_` | `{ _id: 1 }` | Default | Primary key lookup |
| `category_1` | `{ category: 1 }` | Single-field | Filter by category |
| `category_1_price_-1` | `{ category: 1, price: -1 }` | Compound | Category filter + price range/sort |
| `tags_1` | `{ tags: 1 }` | Multikey | Array field lookup |
| `name_text` | `{ name: "text" }` | Text | Full-text keyword search |

---

## Index Analysis

### 1. Single-field Index – `{ category: 1 }`
- **Size:** 572 KB
- **Effective for:** Equality filters on `category` alone
- **Result:** Reduced docs examined from 100,000 → 9,931 (Q1)
- **Limitation:** Cannot assist with price-range queries without category

### 2. Compound Index – `{ category: 1, price: -1 }`
- **Size:** 1.6 MB
- **Effective for:** Queries filtering by `category` AND sorting/filtering by `price`
- **Result:** Best performer — reduced docs examined to 2,965 on compound query (Q4)
- **Limitation:** Not efficient for price-only queries (Q2) — requires category prefix to be selective
- **Note:** Follows the **ESR rule** — Equality fields first, Sort fields second, Range fields last

### 3. Multikey Index – `{ tags: 1 }`
- **Size:** 2.7 MB (largest — one entry per array element per document)
- **Effective for:** Queries searching within array fields
- **Result:** Reduced docs examined from 100,000 → 9,647 (Q3)
- **Trade-off:** Larger storage due to multiple index entries per document (5 tags × 100k docs = 500k entries)

### 4. Text Index – `{ name: "text" }`
- **Size:** 1.6 MB
- **Effective for:** Full-text search using `$text: { $search: "..." }`
- **Limitation:** Only one text index allowed per collection; cannot use `hint()` with text indexes
- **Alternative:** Use regex `/keyword/i` for simple patterns (but avoids index; text index is preferred)

---

## Query Planner Behavior

MongoDB's query planner (the "multiplanner") tests candidate indexes in parallel and selects the **winning plan** with the lowest cost. Key behaviors observed:

| Scenario | Planner Action |
|---|---|
| Single equality filter on indexed field | Selects matching single-field or compound index |
| Compound query with equality + range | Prefers compound index — covers both conditions in one pass |
| Array field query | Selects multikey index automatically |
| Price-only range (no category) | Falls back to COLLSCAN (no suitable index) |

---

## Collection & Index Storage Summary

```
Collection size:     ~37 MB  (100,000 documents)
Total index size:    ~6.5 MB
Index overhead:      ~17% of collection size
```

### Index Size vs. Selectivity Trade-off
- `category_1` (572 KB) — high selectivity, small size → **best value**
- `tags_1` (2.7 MB) — moderate selectivity, large size due to multikey expansion
- `category_1_price_-1` (1.6 MB) — high selectivity for compound queries → **most impactful**
