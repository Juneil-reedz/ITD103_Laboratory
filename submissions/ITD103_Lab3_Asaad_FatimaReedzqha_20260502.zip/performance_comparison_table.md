# Lab 3 – Performance Comparison Table (COLLSCAN vs IXSCAN)

**Dataset:** 100,000 documents in `performance_lab.products`
**MongoDB version:** 8.2.6

---

## Results

| Query | Stage (Before) | Time Before (ms) | Docs Examined Before | Stage (After) | Time After (ms) | Docs Examined After | Keys Examined | Improvement |
|---|---|---|---|---|---|---|---|---|
| Q1: `category = "Category 5"` | COLLSCAN | 44 ms | 100,000 | IXSCAN | 18 ms | 9,931 | 9,931 | **2.4× faster** |
| Q2: `price > 500` | COLLSCAN | 42 ms | 100,000 | IXSCAN | 186 ms | 100,000 | 100,000 | Slower* |
| Q3: `tags = "tag25"` | COLLSCAN | 60 ms | 100,000 | IXSCAN | 19 ms | 9,647 | 9,647 | **3.2× faster** |
| Q4: `category = "3" + price < 300` | COLLSCAN | 42 ms | 100,000 | IXSCAN | 5 ms | 2,965 | 2,965 | **8.4× faster** |

---

## Notes

### Q2 – Price Range Query (Anomaly)
Q2 (`price > 500`) was *slower* with the compound index (`category_1_price_-1`) because:
- The query has **no category filter**, so the index must scan all 100,000 price entries across every category
- The compound index is not selective for price-only queries — it must traverse every category partition
- A dedicated single-field `{ price: 1 }` index would be more efficient for this query pattern

### Q4 – Best Improvement (8.4×)
The compound index `{ category: 1, price: -1 }` is most effective on Q4 because:
- The equality filter on `category` narrows the index scan to a small subset (~10,000 docs)
- The range filter on `price` is then applied within that narrow set
- Only 2,965 documents examined vs 100,000 — a **97% reduction**

---

## Index Sizes

| Index | Size |
|---|---|
| `_id_` | 4 KB |
| `category_1` | 572 KB |
| `category_1_price_-1` | 1.6 MB |
| `tags_1` | 2.7 MB |
| `name_text` | 1.6 MB |

---

## Key Metrics Explained

| Metric | Meaning |
|---|---|
| `stage = COLLSCAN` | Full collection scan — reads every document |
| `stage = IXSCAN` | Index scan — only reads matching index entries |
| `totalDocsExamined` | Number of documents read from disk |
| `totalKeysExamined` | Number of index entries scanned |
| `executionTimeMillis` | Actual query execution time |
