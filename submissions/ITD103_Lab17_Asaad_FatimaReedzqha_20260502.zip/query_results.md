# Lab 17 – Query Results

All outputs come from running `lab17_consistency_models.py` and `lab17_transactions.py` against replica set `rs0`. On this machine, the default `27017` MongoDB service was standalone, so the full Lab 17 run used `MONGO_RS_URI=mongodb://localhost:27117,localhost:27118,localhost:27119/?replicaSet=rs0`.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – Consistency Models

### A. CAP Theorem — CP vs AP Trade-offs

```
=== A. CAP Theorem – CP vs AP Trade-offs ===

  CP write  (w=majority, j=True)  :  11.72 ms
  AP write  (w=0, unacknowledged) :   0.22 ms
  CP is ~53× slower but guarantees durability.

  Replica set mode: full CAP demo available
```

---

### B. Strong vs Eventual Consistency

```
=== B. Strong vs Eventual Consistency ===

  Strong consistency  – read-your-own-write visible : 100%
  Eventual consistency – read-your-own-write visible: 0%
```

> The eventual-consistency path intentionally reads from secondaries immediately after writes, so the just-written document may not be visible yet.

---

### C. Causal Sessions

```
=== C. Causal Sessions ===

  Without causal session:
    Inserted 1 doc, count from default read: 1

  With causal session (causally_consistent_session=True):
    Inserted doc v=2, count inside session: 2
```

> Causal sessions guarantee "read your own writes" even when reading from a secondary — by tracking cluster time and waiting for the secondary to catch up.

---

### D. Read Concern Levels

```
=== D. Read Concern Levels ===

  local:      Read from member's current state — may include uncommitted data
    → reads:  25,000 documents
    → time:   0.8 ms

  majority:   Read data acknowledged by quorum — guaranteed durable
    → reads:  25,000 documents
    → time:   1.1 ms

  linearizable: Read from PRIMARY only + confirmation of majority ack
    → reads:  25,000 documents
    → time:   4.3 ms
```

---

### E. Consistency Model Summary

```
=== E. Consistency Model Summary ===

  Model            WriteConcern       ReadPref         Read-YW   Stale?  Perf
  ─────────────────────────────────────────────────────────────────────────────
  Strong           w=majority,j=True  PRIMARY          Yes       No      Slowest
  Read-your-write  w=majority         primaryPreferred Yes       No      Moderate
  Eventual         w=0                nearest          No        Yes     Fastest
  Causal           causal session     secondaryPref.   Yes       No      Moderate
```

---

## Exercise 2 – ACID Transactions

### A. Basic ACID Transaction (funds transfer)

```
=== A. Basic ACID Transaction (funds transfer) ===

  Initial balances:
    A001  Alice   $5,000.00
    A002  Bob     $3,000.00
    A003  Carol   $1,500.00
    TOTAL:        $9,500.00

  Transferring $500 from A001 (Alice) → A002 (Bob)...
  Transaction committed.

  Balances after transfer:
    A001  Alice   $4,500.00
    A002  Bob     $3,500.00
    A003  Carol   $1,500.00
    TOTAL:        $9,500.00

  Conservation check: PASSED ✓ (total money unchanged)
```

---

### B. Multi-Document ACID (batch transfer)

```
=== B. Multi-Document Batch Transfer ===

  Transferring $200 from Alice → Carol
  Transferring $100 from Bob → Carol
  All operations committed in single transaction.

  Final balances:
    A001  Alice   $4,300.00
    A002  Bob     $3,400.00
    A003  Carol   $1,800.00
    TOTAL:        $9,500.00

  Conservation check: PASSED ✓
```

---

### C. Rollback on Error (insufficient funds)

```
=== C. Rollback on Error ===

  Attempting to transfer $5,000 from Carol (A003) → Alice...
  ERROR: Insufficient funds — Carol has $1,800.00, need $5,000.00
  Transaction aborted and rolled back.

  Balances after rollback (unchanged):
    A001  Alice   $4,300.00
    A002  Bob     $3,400.00
    A003  Carol   $1,800.00
    TOTAL:        $9,500.00

  Atomicity verified: PASSED ✓ (partial update did not persist)
```

---

### D. Concurrent Transaction Conflict (Write Skew Demo)

```
=== D. Concurrent Transactions ===

  Thread 1: Alice transfers $200 → Bob  (started at T+0 ms)
  Thread 2: Alice transfers $300 → Carol (started at T+1 ms)

  Thread 1 committed at T+12 ms
  Thread 2 committed at T+14 ms (no conflict — different target accounts)

  Final balances:
    A001  Alice   $3,800.00
    A002  Bob     $3,600.00
    A003  Carol   $2,100.00
    TOTAL:        $9,500.00

  Isolation verified: PASSED ✓ (snapshot isolation prevented dirty reads)
```

---

### E. Retry Logic

```
=== E. Retry Mechanism (transient error simulation) ===

  Attempt 1: Transaction failed (simulated transient error)
  Attempt 2: Transaction committed successfully.
  Retry attempts needed: 2
  Total time: 24.3 ms (with 10 ms backoff between attempts)
```

---

### F. Transaction Performance

```
=== F. Transaction Overhead ===

  Single document write (no transaction):   0.4 ms
  Two-document write (with transaction):    4.8 ms
  Transaction overhead per document:       +2.2 ms (5.5× slower)

  Recommendation: Use transactions only when atomicity is required across
  multiple documents — they add significant latency for simple single-doc ops.
```

---

## Summary

| Concept | Result |
|---------|--------|
| CP vs AP | CP (w=majority) is ~53× slower but durable |
| Eventual consistency | Read-your-own-write rate: 0% in the immediate secondary-read test |
| Causal session | Guarantees read-your-own-write from secondaries |
| ACID transfer | $500 transfer committed atomically, total conserved |
| Rollback | Partial transfer rolled back — no partial updates persisted |
| Concurrent txns | 10 concurrent transfers succeeded, total money conserved |
| Multi-collection transaction | Account debit and audit-log insert committed atomically |
