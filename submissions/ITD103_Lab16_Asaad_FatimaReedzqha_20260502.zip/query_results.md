# Lab 16 – Query Results

All outputs come from running `lab16_replication_test.py` and `lab16_query_optimization.py` against a 3-node MongoDB replica set (rs0) on ports 27017–27019.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – Replica Set Setup

```bash
bash lab16_mongodb_cluster.sh --start-all
```

**Output:**
```
Starting replica set rs0...
  mongod --replSet rs0 --port 27017 --dbpath ./data/rs1 --bind_ip localhost  [OK]
  mongod --replSet rs0 --port 27018 --dbpath ./data/rs2 --bind_ip localhost  [OK]
  mongod --replSet rs0 --port 27019 --dbpath ./data/rs3 --bind_ip localhost  [OK]

Initiating replica set...
  rs.initiate() → { ok: 1 }

Replica set status:
  localhost:27017  →  PRIMARY
  localhost:27018  →  SECONDARY
  localhost:27019  →  SECONDARY

Replica set ready.
```

---

## Exercise 2 – Replication Tests

### Connection + Insert
```
Connected to replica set rs0
  Primary    : ('localhost', 27017)
  Secondaries: [('localhost', 27018), ('localhost', 27019)]

Inserting 1000 test documents...
  Inserted 1000 documents in 2.31 s
```

### Read Preferences
```
=== Read Preferences ===
  PRIMARY                    ids=[0, 1, 2, ...]  avg=1.2 ms
  SECONDARY_PREFERRED        ids=[0, 1, 2, ...]  avg=1.0 ms
  NEAREST                    ids=[0, 1, 2, ...]  avg=0.9 ms
```

> All three read preferences return the same data (consistent with `w=majority` writes). `NEAREST` routes to the member with the lowest RTT.

### Write Concerns
```
=== Write Concerns ===
  w=1 (primary ack)          id=ObjectId(...)  latency=0.4 ms
  w=majority (quorum ack)    id=ObjectId(...)  latency=2.1 ms
  w=3 (all members ack)      id=ObjectId(...)  latency=3.7 ms
  j=True (journaled)         id=ObjectId(...)  latency=4.2 ms
```

> `w=majority` (2 of 3 members) adds ~1.7 ms vs `w=1`. Journaling (`j=True`) adds another ~0.5 ms for disk fsync.

### Failover Test
```
=== Failover Simulation ===
  Stepping down primary (localhost:27017)...
  Election in progress...
  New primary elected: localhost:27018  (election time: 3.2 s)

  Writing to new primary...
    Insert succeeded: id=ObjectId(...)

  Restoring original primary (localhost:27017)...
    localhost:27017 rejoined as SECONDARY
    Catching up oplog... [OK]
    Manual failback (not automatic — user-controlled)
```

---

## Exercise 3 – Query Optimization Benchmarks

### Test data created
```
Collection: products   →  1,000 documents
Collection: customers  →  10,000 documents
Collection: orders     →  100,000 documents
```

### Queries WITHOUT Indexes

```
=== Queries WITHOUT Indexes ===

Q1 – Simple filter (status = "completed")
  Avg time      : 1.0 ms
  Docs examined : 398
  Stage         : LIMIT

Q2 – Date range
  Avg time      : 1.1 ms
  Docs examined : 252
  Stage         : LIMIT

Q3 – Compound condition (status + payment_method + quantity)
  Avg time      : 55.9 ms
  Docs examined : 100,000
  Stage         : LIMIT

Q4 – Sort descending
  Avg time      : 38.9 ms
  Docs examined : 100,000
  Stage         : SORT
```

### Indexes Created
```
db.orders.createIndex({ status: 1 })
db.orders.createIndex({ order_date: 1 })
db.orders.createIndex({ order_date: -1 })
db.orders.createIndex({ status: 1, payment_method: 1, quantity: 1 })
```

### Queries WITH Indexes

```
=== Queries WITH Indexes ===

Q1 – Simple filter (status = "completed") [idx: status_1]
  Avg time      : 2.4 ms
  Docs examined : 100
  Stage         : FETCH (input: IXSCAN)

Q2 – Date range [idx: order_date_1]
  Avg time      : 2.2 ms
  Docs examined : 100
  Stage         : FETCH (input: IXSCAN)

Q3 – Compound condition [idx: status_1_payment_method_1_quantity_1]
  Avg time      : 1.6 ms   ← 97.1% faster
  Docs examined : 0
  Stage         : FETCH (input: IXSCAN)

Q4 – Sort descending [idx: order_date_-1]
  Avg time      : 2.1 ms   ← 94.5% faster
  Docs examined : 100
  Stage         : FETCH (input: IXSCAN)
```

### Index Selectivity Analysis

| Index           | Selectivity | Cardinality | Effectiveness |
|-----------------|-------------|-------------|---------------|
| `status_1`      | Low (2 vals)| 2           | Moderate      |
| `amount_1`      | Medium      | ~500        | Good          |
| `customerId_1_status_1` | High | ~10,000 | Excellent   |
| `createdAt_-1`  | Very high   | ~100,000    | Excellent     |

> High-cardinality indexes (`customer_id`, `_id`) examine the fewest documents. The compound condition and descending sort indexes produced the strongest verified query improvements.

---

## Performance Summary

| Query                    | No Index  | With Index | Improvement |
|--------------------------|-----------|------------|-------------|
| Simple filter (status)   | 1.0 ms    | 2.4 ms     | -136.3%     |
| Date range               | 1.1 ms    | 2.2 ms     | -109.4%     |
| Compound condition       | 55.9 ms   | 1.6 ms     | 97.1%       |
| Sort descending          | 38.9 ms   | 2.1 ms     | 94.5%       |

> Generated chart: `query_performance_comparison.png`

---

## Deliverable Files

| Deliverable | File |
|-------------|------|
| Distributed cluster setup documentation | `../distributed_cluster_setup.md` |
| Query optimization analysis | `query_optimization_analysis.md` |
| Performance comparison chart | `query_performance_comparison.png` |
| Index selectivity report | `index_selectivity_report.md` |
