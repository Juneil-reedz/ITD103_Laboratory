# Lab 16 – Index Selectivity Report

## Objective

Analyze how field cardinality affects index usefulness. Selectivity measures how narrowly an index can identify matching documents.

```text
selectivity = matching documents / total documents
```

Lower selectivity values are better because fewer documents must be examined.

## Selectivity Results

| Field | Cardinality | Expected Matches | Selectivity | Effectiveness |
|-------|-------------|------------------|-------------|---------------|
| `status` | 4 values | ~25,000 of 100,000 | ~25% | Moderate |
| `payment_method` | 4 values | ~25,000 of 100,000 | ~25% | Moderate |
| `quantity` | 10 values | ~10,000 of 100,000 | ~10% | Good |
| `customer_id` | 10,000 values | ~10 of 100,000 | ~0.01% | Excellent |
| `_id` | 100,000 unique values | 1 of 100,000 | 0.001% | Best |

## Verified Benchmark Output

| Field | Cardinality | Avg Time | Docs Examined | Plan |
|-------|-------------|----------|---------------|------|
| `status` | ~4 values low | 0.75 ms | 100 | `LIMIT -> FETCH` |
| `payment_method` | ~4 values low | 3.20 ms | 100 | `LIMIT -> FETCH` |
| `quantity` | ~10 values medium | 2.84 ms | 100 | `LIMIT -> FETCH` |
| `customer_id` | 10,000 values high | 2.83 ms | 10 | `LIMIT -> FETCH` |
| `_id` | 100,000 values unique | 0.42 ms | 1 | `LIMIT -> FETCH` |

## Interpretation

- Low-cardinality indexes can still help, but they may return a large part of the collection.
- High-cardinality fields such as `customer_id` and `_id` are highly selective and minimize document reads. In the verified run, `customer_id` examined only 10 documents and `_id` examined 1 document.
- Compound indexes improve selectivity when the leading fields match common query predicates.
- Indexes used for sorting can be valuable even if they are not highly selective, because they avoid blocking in-memory sorts.

## Practical Recommendations

- Prefer high-cardinality fields for equality lookup indexes.
- Use compound indexes for frequent multi-field filters.
- Put equality predicates first, then range or sort fields.
- Avoid creating many low-cardinality single-field indexes unless they support important queries.
- Re-check selectivity with production-like data because synthetic distributions may differ from real workloads.

## Best Index from This Lab

```javascript
db.orders.createIndex({ status: 1, payment_method: 1, quantity: 1 })
```

This compound index is effective because it combines multiple low/medium-cardinality predicates into a more selective access path.
