# Lab 16 – Query Optimization Analysis

## Objective

Measure how MongoDB indexes affect query latency, documents examined, and execution plans on a 100,000-document `orders` collection.

## Dataset

| Collection | Documents | Purpose |
|------------|-----------|---------|
| `products` | 1,000 | Product reference data |
| `customers` | 10,000 | Customer reference data |
| `orders` | 100,000 | Benchmark target collection |

## Benchmark Queries

| Query | Predicate / Operation | Baseline Plan | Indexed Plan |
|-------|------------------------|---------------|--------------|
| Q1 | `status = completed` | `COLLSCAN` | `IXSCAN` on `status_1` |
| Q2 | `order_date` range | `COLLSCAN` | `IXSCAN` on `order_date_1` |
| Q3 | `status + payment_method + quantity` | `COLLSCAN` | `IXSCAN` on compound index |
| Q4 | Sort by `order_date DESC` | `COLLSCAN + SORT` | `IXSCAN` on `order_date_-1` |

## Performance Summary

| Query | No Index | With Index | Improvement | Main Reason |
|-------|----------|------------|-------------|-------------|
| Q1 simple filter | 1.0 ms | 2.4 ms | -136.3% | Limit stops the collection scan early; index overhead is higher on this tiny result window |
| Q2 date range | 1.1 ms | 2.2 ms | -109.4% | Limit stops early in the unindexed scan; indexed path still examines only 100 docs |
| Q3 compound condition | 55.9 ms | 1.6 ms | 97.1% | Compound index removes the full 100,000-document scan |
| Q4 sort descending | 38.9 ms | 2.1 ms | 94.5% | Descending date index removes the blocking sort |

## Analysis

- Indexes produced major gains for the expensive query shapes: Q3 improved by 97.1% and Q4 improved by 94.5%.
- Q1 and Q2 are slower with indexes in this run because both queries use `limit(100)`, allowing the unindexed scan to stop early before scanning the whole collection.
- The compound index has the strongest filter benefit because it narrows by multiple predicates in index order.
- The descending `order_date` index removes the blocking sort stage, which is why Q4 improves substantially.
- Low-cardinality indexes such as `status` still help for large result sets, but they are less selective than high-cardinality fields.

## Recommended Indexes

```javascript
db.orders.createIndex({ status: 1 })
db.orders.createIndex({ order_date: 1 })
db.orders.createIndex({ order_date: -1 })
db.orders.createIndex({ status: 1, payment_method: 1, quantity: 1 })
db.orders.createIndex({ customer_id: 1 })
db.orders.createIndex({ status: 1, order_date: -1 })
db.orders.createIndex({ product_id: 1, status: 1 })
```

## Conclusion

The best index is the one aligned to the query shape. Equality predicates should appear first in compound indexes, followed by range or sort fields. For this workload, the compound condition and descending sort indexes provide the highest practical gains. Low-cardinality single-field indexes should be evaluated carefully when queries return only a small limited result set.
