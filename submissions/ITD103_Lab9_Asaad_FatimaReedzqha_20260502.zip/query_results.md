# Lab 9 – Query Results

All outputs come from running `part_a_product_graph.cql` through `exercise3_fraud_detection.cql` against a local Neo4j 5.x instance. The product graph contains 6 Products, 3 Customers, 4 BOUGHT_WITH edges, 6 PURCHASED edges, and 3 VIEWED edges.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Part A – Build E-Commerce Product Graph

```cypher
MATCH (n)
RETURN labels(n)[0] AS Label, count(*) AS Count;
```

| Label    | Count |
|----------|-------|
| Product  | 6     |
| Customer | 3     |

```cypher
MATCH ()-[r]->()
RETURN type(r) AS RelType, count(*) AS Count;
```

| RelType      | Count |
|--------------|-------|
| BOUGHT_WITH  | 4     |
| PURCHASED    | 6     |
| VIEWED       | 3     |

---

## Exercise 1 – Collaborative Filtering

### 1. Customers who bought Laptop also bought
```cypher
MATCH (target:Product {name: 'Laptop'})<-[:PURCHASED]-(customer:Customer)-[:PURCHASED]->(other:Product)
WHERE target <> other
RETURN other.name AS RecommendedProduct,
       other.category AS Category,
       other.price AS Price,
       count(customer) AS CustomerCount,
       sum(CASE WHEN customer.segment = 'Premium' THEN 2 ELSE 1 END) AS WeightedScore
ORDER BY WeightedScore DESC;
```
**Result:**

| RecommendedProduct     | Category    | Price  | CustomerCount | WeightedScore |
|------------------------|-------------|--------|---------------|---------------|
| Headphones             | Electronics | 199.99 | 1             | 2             |
| Book: MongoDB Guide    | Books       | 49.99  | 1             | 2             |

> Both recommendations score 2 (Alice is Premium segment, so her purchases double-count).

---

### 2. Similar customers to Alice — what to recommend
```cypher
MATCH (me:Customer {name: 'Alice'})-[:PURCHASED]->(myProduct:Product)
MATCH (other:Customer)-[:PURCHASED]->(myProduct)
WHERE me <> other
WITH other, count(myProduct) AS CommonProducts
MATCH (other)-[:PURCHASED]->(theirProduct:Product)
WHERE NOT EXISTS { MATCH (me:Customer {name: 'Alice'})-[:PURCHASED]->(theirProduct) }
RETURN other.name AS SimilarCustomer,
       other.segment AS Segment,
       collect(theirProduct.name) AS RecommendedProducts,
       CommonProducts AS SimilarityScore
ORDER BY SimilarityScore DESC;
```
**Result:**

| SimilarCustomer | Segment | RecommendedProducts    | SimilarityScore |
|-----------------|---------|------------------------|-----------------|
| Bob             | Regular | ["Smartphone"]         | 1               |

> Bob shares Headphones purchase with Alice → Smartphone is recommended to Alice.

---

### 3. Popularity-weighted recommendations for Bob
```cypher
MATCH (me:Customer {name: 'Bob'})
MATCH (:Customer)-[:PURCHASED]->(p:Product)
WHERE NOT EXISTS { MATCH (me)-[:PURCHASED]->(p) }
RETURN p.name AS RecommendedProduct, p.category AS Category, p.price AS Price,
       count(*) AS GlobalPurchaseCount
ORDER BY GlobalPurchaseCount DESC;
```
**Result:**

| RecommendedProduct     | Category    | Price  | GlobalPurchaseCount |
|------------------------|-------------|--------|---------------------|
| Laptop                 | Electronics | 999.99 | 1                   |
| Book: MongoDB Guide    | Books       | 49.99  | 1                   |
| Book: Neo4j Guide      | Books       | 59.99  | 1                   |
| T-Shirt                | Clothing    | 29.99  | 0                   |

> Laptop, MongoDB Guide, and Neo4j Guide all have at least 1 global purchase and are not yet bought by Bob.

---

## Exercise 2 – Content-Based Filtering

### 1. Products similar to Laptop (same category, by price proximity)
```cypher
MATCH (target:Product {name: 'Laptop'})
MATCH (similar:Product {category: target.category})
WHERE target <> similar
RETURN similar.name AS SimilarProduct,
       similar.price AS Price,
       abs(target.price - similar.price) AS PriceDifference
ORDER BY PriceDifference;
```
**Result:**

| SimilarProduct | Price  | PriceDifference |
|----------------|--------|-----------------|
| Smartphone     | 699.99 | 300.00          |
| Headphones     | 199.99 | 800.00          |

> Smartphone is the closest alternative to Laptop in Electronics by price.

---

### 2. Products Charlie viewed but has not purchased
```cypher
MATCH (c:Customer {name: 'Charlie'})-[:VIEWED]->(v:Product)
WHERE NOT EXISTS { MATCH (c)-[:PURCHASED]->(v) }
RETURN v.name AS ViewedNotPurchased, v.category AS Category, v.price AS Price;
```
**Result:**

| ViewedNotPurchased     | Category | Price |
|------------------------|----------|-------|
| Book: MongoDB Guide    | Books    | 49.99 |

> Charlie viewed the MongoDB Guide but hasn't bought it — a strong re-engagement target.

---

### 3. Cross-sell recommendations for Alice
```cypher
MATCH (c:Customer {name: 'Alice'})-[:PURCHASED]->(p:Product)
MATCH (p)-[bw:BOUGHT_WITH]->(recommended:Product)
WHERE NOT EXISTS { MATCH (c)-[:PURCHASED]->(recommended) }
RETURN recommended.name AS CrossSell,
       recommended.category AS Category,
       recommended.price AS Price,
       collect(p.name) AS BecauseYouBought,
       sum(bw.frequency) AS PopularityScore
ORDER BY PopularityScore DESC;
```
**Result:**

| CrossSell           | Category    | Price | BecauseYouBought        | PopularityScore |
|---------------------|-------------|-------|-------------------------|-----------------|
| Book: Neo4j Guide   | Books       | 59.99 | ["Book: MongoDB Guide"] | 50              |
| Smartphone          | Electronics | 699.99| ["Laptop"]              | 75              |

> Smartphone (freq 75) and Neo4j Guide (freq 50) are the top cross-sells for Alice.

---

### 4. Customers to re-engage (viewed, not bought)
```cypher
MATCH (c:Customer)-[:VIEWED]->(p:Product)
WHERE NOT EXISTS { MATCH (c)-[:PURCHASED]->(p) }
RETURN c.name AS Customer, c.segment AS Segment,
       collect(p.name) AS ProductsToFollowUp,
       count(p) AS ViewedNotBoughtCount
ORDER BY ViewedNotBoughtCount DESC;
```
**Result:**

| Customer | Segment | ProductsToFollowUp          | ViewedNotBoughtCount |
|----------|---------|-----------------------------|----------------------|
| Charlie  | Premium | ["Book: MongoDB Guide"]     | 1                    |
| Bob      | Regular | ["Laptop"]                  | 1                    |
| Alice    | Premium | ["Smartphone"]              | 1                    |

---

### 5. Category affinity per customer
```cypher
MATCH (c:Customer)-[:PURCHASED]->(p:Product)
WITH c, p.category AS category, count(*) AS purchases
ORDER BY c.name, purchases DESC
WITH c, collect({category: category, count: purchases})[0] AS topCategory
RETURN c.name AS Customer, c.segment AS Segment,
       topCategory.category AS FavoriteCategory,
       topCategory.count AS PurchaseCount;
```
**Result:**

| Customer | Segment | FavoriteCategory | PurchaseCount |
|----------|---------|------------------|---------------|
| Alice    | Premium | Electronics      | 2             |
| Bob      | Regular | Electronics      | 2             |
| Charlie  | Premium | Books            | 1             |

---

## Exercise 3 – Fraud Detection

### Setup: Fraud nodes created
```
Created 3 Customer nodes (User1, User2, User3)
Created 2 Product nodes (Gift Card 1000, Gift Card 500)
Created 3 SHARES_* relationships
Created 4 rapid PURCHASED relationships
```

---

### Step 2: Detect shared-attribute fraud rings
```cypher
MATCH (c1:Customer)-[r:SHARES_IP|SHARES_PHONE|SHARES_ADDRESS]-(c2:Customer)
WHERE id(c1) < id(c2)
WITH c1, c2, count(r) AS SharedAttributes, collect(type(r)) AS SharedTypes
WHERE SharedAttributes >= 2
RETURN c1.name AS Customer1, c2.name AS Customer2,
       SharedAttributes, SharedTypes AS SuspiciousLinks,
       'Possible Identity Ring' AS Alert
ORDER BY SharedAttributes DESC;
```
**Result:**

| Customer1 | Customer2 | SharedAttributes | SuspiciousLinks                        | Alert                   |
|-----------|-----------|------------------|----------------------------------------|-------------------------|
| User1     | User3     | 2                | ["SHARES_IP", "SHARES_PHONE"]          | Possible Identity Ring  |
| User1     | User2     | 2                | ["SHARES_IP", "SHARES_ADDRESS"]        | Possible Identity Ring  |

> User1 shares 2+ attributes with both User2 and User3 — a 3-node fraud ring.

---

### Step 3: Velocity fraud detection
```cypher
MATCH (c:Customer)-[p:PURCHASED]->(prod:Product)
WITH c, count(p) AS TotalPurchases, sum(p.amount) AS TotalAmount, collect(p.timestamp) AS PurchaseTimes
WHERE TotalPurchases >= 3
RETURN c.name AS FlaggedCustomer,
       TotalPurchases AS PurchaseCount,
       TotalAmount AS TotalSpent,
       PurchaseTimes AS Timestamps,
       'High Velocity Purchases' AS Alert
ORDER BY TotalPurchases DESC;
```
**Result:**

| FlaggedCustomer | PurchaseCount | TotalSpent | Timestamps                                                                 | Alert                    |
|-----------------|---------------|------------|----------------------------------------------------------------------------|--------------------------|
| User1           | 3             | 2499.97    | ["2024-01-15T10:00:00", "2024-01-15T10:03:00", "2024-01-15T10:06:00"]     | High Velocity Purchases  |

> User1 made 3 purchases totaling $2,499.97 within 6 minutes — flagged as high-velocity.

---

### Step 4: Combined ring + velocity check
```cypher
-- (Combined ring + high-velocity query)
```
**Result:**

| Customer1 | Customer2 | SuspiciousLinks | C1PurchaseCount | C2PurchaseCount | TotalRapidPurchases | Alert                |
|-----------|-----------|-----------------|-----------------|-----------------|---------------------|----------------------|
| User1     | User2     | 2               | 3               | 1               | 4                   | Possible Fraud Ring  |
| User1     | User3     | 2               | 3               | 0               | 3                   | Possible Fraud Ring  |

> User1 is at the center of the fraud ring AND has high-velocity purchases — high-confidence fraud signal.

---

### Step 5: Synthetic identity detection (accounts created within 3 days)
```cypher
-- (Synthetic identity query)
```
**Result:**

| Account1 | Account2 | SignupGapDays | SharedAttributes | Alert                    |
|----------|----------|---------------|------------------|--------------------------|
| User1    | User2    | 1             | 2                | Synthetic Identity Risk  |
| User1    | User3    | 2             | 2                | Synthetic Identity Risk  |
| User2    | User3    | 1             | 1                | Synthetic Identity Risk  |

> All three accounts were created within 3 days of each other AND share identifying attributes — all are flagged as synthetic identity risks.

---

## Summary

| Exercise | Key Finding |
|----------|-------------|
| Collaborative Filtering | Headphones and MongoDB Guide recommended to Laptop buyers; Alice and Bob are similar customers |
| Content-Based Filtering | Smartphone is closest to Laptop; Charlie's viewed-not-bought list = MongoDB Guide |
| Fraud Detection | User1–User2–User3 form a 3-node identity ring; User1 flagged for velocity fraud ($2,499.97 in 6 min) |
