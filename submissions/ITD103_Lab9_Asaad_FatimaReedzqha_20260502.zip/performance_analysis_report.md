# Lab 9 – Performance Analysis Report

## Scope

This report reviews the Lab 9 e-commerce recommendation and fraud detection queries in Neo4j 5.x. The test graph contains product, customer, purchase, view, bought-with, and shared-identity relationships.

## Workload Summary

| Query Area | Main Traversal | Purpose |
|------------|----------------|---------|
| Collaborative filtering | `Customer -> PURCHASED -> Product <- PURCHASED <- Customer` | Recommend products from similar customer behavior |
| Content-based filtering | `Product` property filtering and `BOUGHT_WITH` traversal | Recommend similar, viewed, and cross-sell products |
| Fraud detection | `Customer - SHARES_* - Customer` and `Customer -> PURCHASED -> Product` | Detect shared identifiers, velocity fraud, and synthetic identity risk |

## Expected Performance

The current lab dataset is small, so all queries should complete quickly in Neo4j Browser. The most expensive operations are the recommendation and fraud queries that match across multiple customers and products because they expand relationship paths before filtering.

## Query Observations

| Query | Performance Notes |
|-------|-------------------|
| Laptop also-bought recommendations | Efficient on small data because it starts from one named product and expands through `PURCHASED` relationships. |
| Similar customers to Alice | Good for lab size; on larger datasets, customer/product indexes are important. |
| Content similarity by category and price | Uses product properties; benefits from an index on `Product(category)`. |
| Cross-sell recommendations | Efficient because it traverses explicit `BOUGHT_WITH` relationships instead of scanning all product pairs. |
| Shared-attribute fraud ring detection | Expands only `SHARES_IP`, `SHARES_PHONE`, and `SHARES_ADDRESS`; this is preferable to scanning all customer relationships. |
| Velocity fraud detection | Counts `PURCHASED` relationships per customer; scales with number of purchases. |

## Recommended Indexes

Run these once before testing larger datasets:

```cypher
CREATE INDEX customer_name IF NOT EXISTS FOR (c:Customer) ON (c.name);
CREATE INDEX customer_id IF NOT EXISTS FOR (c:Customer) ON (c.id);
CREATE INDEX product_name IF NOT EXISTS FOR (p:Product) ON (p.name);
CREATE INDEX product_category IF NOT EXISTS FOR (p:Product) ON (p.category);
```

## How To Measure Performance

Use `PROFILE` before any query in Neo4j Browser. Example:

```cypher
PROFILE
MATCH (target:Product {name: 'Laptop'})<-[:PURCHASED]-(customer:Customer)-[:PURCHASED]->(other:Product)
WHERE target <> other
RETURN other.name AS RecommendedProduct,
       other.category AS Category,
       other.price AS Price,
       count(customer) AS CustomerCount
ORDER BY CustomerCount DESC;
```

Check these values in the Neo4j execution plan:

| Metric | Meaning |
|--------|---------|
| DB Hits | Lower is better; shows how much data Neo4j touched |
| Rows | Number of intermediate and final records |
| Index Seek | Good; means Neo4j used an index |
| Node Scan | Acceptable for this lab, but slower on large datasets |

## Conclusion

The Lab 9 implementation is suitable for the required small graph. For larger datasets, the main optimization is adding indexes for frequently matched properties and continuing to use relationship traversals instead of broad node scans.
