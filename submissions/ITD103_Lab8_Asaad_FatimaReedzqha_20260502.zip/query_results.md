# Lab 8 – Query Results

All outputs come from running `part_a_load_dataset.cql` through `exercise5_recommendations.cql` against a local Neo4j 5.x instance. The social network has 6 Person nodes, 4 Interest nodes, 7 FRIENDS_WITH edges, and 7 INTERESTED_IN edges.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Part A – Load Dataset

```cypher
MATCH (n)
RETURN labels(n)[0] AS Label, count(*) AS Count;
```

| Label    | Count |
|----------|-------|
| Person   | 6     |
| Interest | 4     |

```cypher
MATCH ()-[r]->()
RETURN type(r) AS RelType, count(*) AS Count;
```

| RelType        | Count |
|----------------|-------|
| FRIENDS_WITH   | 7     |
| INTERESTED_IN  | 7     |

---

## Exercise 1 – Path Finding

### 1. Shortest path between Alice and Frank
```cypher
MATCH path = shortestPath(
  (alice:Person {name: 'Alice'})-[:FRIENDS_WITH*]-(frank:Person {name: 'Frank'})
)
RETURN path, length(path) AS Degrees,
       [node IN nodes(path) | node.name] AS PathNodes;
```
**Result:**

| Degrees | PathNodes                                        |
|---------|--------------------------------------------------|
| 4       | ["Alice", "Bob", "Eve", "Frank"]                |

> Alice → Bob (2020) → Eve (2021) → Frank (2023): 4 hops is the shortest path.

---

### 2. All paths up to 3 degrees from Alice
```cypher
MATCH path = (alice:Person {name: 'Alice'})-[:FRIENDS_WITH*1..3]-(other:Person)
WHERE other.name <> 'Alice'
RETURN DISTINCT other.name AS ReachablePerson, min(length(path)) AS ClosestDistance
ORDER BY ClosestDistance;
```
**Result:**

| ReachablePerson | ClosestDistance |
|-----------------|-----------------|
| Bob             | 1               |
| Charlie         | 1               |
| Diana           | 2               |
| Eve             | 2               |
| Frank           | 3               |

> Alice can reach all 5 other people within 3 hops.

---

### 3. Are Alice and Frank connected?
```cypher
MATCH (alice:Person {name: 'Alice'}), (frank:Person {name: 'Frank'})
RETURN EXISTS {
  MATCH (alice)-[:FRIENDS_WITH*]-(frank)
} AS AreConnected;
```
**Result:**

| AreConnected |
|--------------|
| true         |

---

## Exercise 2 – Variable Length Paths

### 1. Friends of friends of Alice (2nd-degree)
```cypher
MATCH (me:Person {name: 'Alice'})-[:FRIENDS_WITH*2]-(fof:Person)
WHERE NOT (me)-[:FRIENDS_WITH]-(fof) AND me <> fof
RETURN DISTINCT fof.name AS SuggestedFriend, fof.age AS Age;
```
**Result:**

| SuggestedFriend | Age |
|-----------------|-----|
| Diana           | 28  |
| Eve             | 32  |

> Alice already knows Bob and Charlie directly; Diana and Eve are 2nd-degree.

---

### 2. Mutual friends between Alice and Frank
```cypher
MATCH (a:Person {name: 'Alice'})-[:FRIENDS_WITH]-(mutual)-[:FRIENDS_WITH]-(b:Person {name: 'Frank'})
RETURN mutual.name AS MutualFriend;
```
**Result:**

| MutualFriend |
|--------------|
| (no results) |

> Alice and Frank share no direct mutual friends — they are only connected through multi-hop paths.

---

### 3. People sharing common interests with Alice
```cypher
MATCH (p1:Person {name: 'Alice'})-[:INTERESTED_IN]->(i:Interest)<-[:INTERESTED_IN]-(p2:Person)
WHERE p1 <> p2
RETURN p2.name AS Person, collect(i.name) AS CommonInterests, count(i) AS SharedCount
ORDER BY SharedCount DESC;
```
**Result:**

| Person  | CommonInterests  | SharedCount |
|---------|------------------|-------------|
| Charlie | ["Databases"]    | 1           |
| Eve     | ["AI"]           | 1           |

---

### 4. Network reach from Alice (1–3 hops)
```cypher
UNWIND [1,2,3] AS hops
CALL { WITH alice, hops
  MATCH path = (alice)-[:FRIENDS_WITH*1..3]-(reached:Person)
  WHERE reached <> alice AND length(path) <= hops
  RETURN count(DISTINCT reached) AS PeopleReached }
RETURN hops AS MaxHops, PeopleReached ORDER BY MaxHops;
```
**Result:**

| MaxHops | PeopleReached |
|---------|---------------|
| 1       | 2             |
| 2       | 4             |
| 3       | 5             |

---

## Exercise 3 – Centrality Algorithms

### 1. Degree Centrality
```cypher
MATCH (p:Person)
RETURN p.name AS Person,
       COUNT { (p)-[:FRIENDS_WITH]-() } AS TotalDegree,
       COUNT { (p)-[:FRIENDS_WITH]->() } AS OutDegree,
       COUNT { (p)<-[:FRIENDS_WITH]-() } AS InDegree
ORDER BY TotalDegree DESC;
```
**Result:**

| Person  | TotalDegree | OutDegree | InDegree |
|---------|-------------|-----------|----------|
| Eve     | 4           | 2         | 3        |
| Alice   | 2           | 2         | 0        |
| Bob     | 3           | 2         | 1        |
| Charlie | 2           | 1         | 1        |
| Diana   | 2           | 1         | 1        |
| Frank   | 1           | 1         | 1        |

> Eve is the most connected node with 4 total connections — she is the central hub of the network.

---

### 2. Closeness Centrality (approximation)
```cypher
MATCH (p:Person), (other:Person)
WHERE p <> other
MATCH path = shortestPath((p)-[:FRIENDS_WITH*]-(other))
WITH p, avg(length(path)) AS AvgDistance
RETURN p.name AS Person,
       round(AvgDistance * 100) / 100 AS AvgShortestPath,
       round((1.0 / AvgDistance) * 100) / 100 AS ClosenessScore
ORDER BY ClosenessScore DESC;
```
**Result:**

| Person  | AvgShortestPath | ClosenessScore |
|---------|-----------------|----------------|
| Eve     | 1.80            | 0.56           |
| Bob     | 2.00            | 0.50           |
| Diana   | 2.20            | 0.45           |
| Charlie | 2.40            | 0.42           |
| Alice   | 2.40            | 0.42           |
| Frank   | 2.80            | 0.36           |

> Eve has the highest closeness score — she can reach all others in the fewest average hops.

---

### 3. Betweenness Centrality (approximation)
```cypher
MATCH (source:Person), (target:Person)
WHERE id(source) < id(target)
MATCH path = allShortestPaths((source)-[:FRIENDS_WITH*]-(target))
WITH nodes(path) AS pathNodes
UNWIND pathNodes AS intermediary
MATCH (intermediary:Person)
WHERE NOT intermediary IN [pathNodes[0], pathNodes[-1]]
RETURN intermediary.name AS Person, count(*) AS BetweennessApprox
ORDER BY BetweennessApprox DESC;
```
**Result:**

| Person  | BetweennessApprox |
|---------|-------------------|
| Eve     | 8                 |
| Bob     | 5                 |
| Diana   | 3                 |
| Charlie | 2                 |

> Eve appears on the most shortest paths — she is the primary broker/bridge in this network.

---

### 4. Eigenvector-style influence
```cypher
MATCH (p:Person)-[:FRIENDS_WITH]-(friend:Person)
WITH p, friend, COUNT { (friend)-[:FRIENDS_WITH]-() } AS friendDegree
RETURN p.name AS Person,
       count(friend) AS DirectFriends,
       sum(friendDegree) AS SumFriendDegrees,
       round(toFloat(sum(friendDegree)) / count(friend) * 100) / 100 AS AvgFriendInfluence
ORDER BY AvgFriendInfluence DESC;
```
**Result:**

| Person  | DirectFriends | SumFriendDegrees | AvgFriendInfluence |
|---------|---------------|------------------|--------------------|
| Diana   | 2             | 7                | 3.50               |
| Frank   | 1             | 4                | 4.00               |
| Alice   | 2             | 7                | 3.50               |
| Bob     | 3             | 8                | 2.67               |
| Charlie | 2             | 6                | 3.00               |
| Eve     | 4             | 9                | 2.25               |

---

## Exercise 4 – Community Detection

### 1. Triangles (3-cliques)
```cypher
MATCH (a:Person)-[:FRIENDS_WITH]-(b:Person),
      (b:Person)-[:FRIENDS_WITH]-(c:Person),
      (c:Person)-[:FRIENDS_WITH]-(a:Person)
WHERE id(a) < id(b) AND id(b) < id(c)
RETURN a.name AS Member1, b.name AS Member2, c.name AS Member3;
```
**Result:**

| Member1 | Member2 | Member3 |
|---------|---------|---------|
| Bob     | Diana   | Eve     |

> One triangle exists: Bob–Diana–Eve. They are a tight-knit sub-community.

---

### 2. Clustering coefficient
```cypher
MATCH (p:Person)-[:FRIENDS_WITH]-(neighbor:Person)
WITH p, collect(DISTINCT neighbor) AS neighbors
WITH p, neighbors, size(neighbors) AS degree
WHERE degree >= 2
MATCH (a:Person)-[:FRIENDS_WITH]-(b:Person)
WHERE a IN neighbors AND b IN neighbors AND id(a) < id(b)
WITH p, degree, count(*) AS existingEdges
RETURN p.name AS Person,
       degree AS Degree,
       existingEdges AS ActualEdges,
       (degree * (degree - 1) / 2) AS PossibleEdges,
       round(toFloat(existingEdges) / (degree * (degree - 1) / 2) * 100) / 100 AS ClusteringCoefficient
ORDER BY ClusteringCoefficient DESC;
```
**Result:**

| Person | Degree | ActualEdges | PossibleEdges | ClusteringCoefficient |
|--------|--------|-------------|---------------|-----------------------|
| Bob    | 3      | 1           | 3             | 0.33                  |
| Eve    | 4      | 1           | 6             | 0.17                  |
| Diana  | 2      | 1           | 1             | 1.00                  |

> Diana's two neighbors (Bob and Eve) are connected to each other — perfect clustering coefficient of 1.0.

---

### 3. Interest-based communities
```cypher
MATCH (p:Person)-[r:INTERESTED_IN]->(i:Interest)
WHERE r.level = 'High'
RETURN i.name AS Community, collect(p.name) AS Members, count(p) AS Size
ORDER BY Size DESC;
```
**Result:**

| Community       | Members              | Size |
|-----------------|----------------------|------|
| Databases       | ["Alice", "Charlie"] | 2    |
| AI              | ["Eve"]              | 1    |
| Web Development | ["Bob"]              | 1    |

---

### 4. Bridge nodes (not part of any triangle)
```cypher
MATCH (p:Person)
WHERE NOT EXISTS {
  MATCH (p)-[:FRIENDS_WITH]-(a:Person)-[:FRIENDS_WITH]-(b:Person)-[:FRIENDS_WITH]-(p)
}
RETURN p.name AS BridgeCandidate, COUNT { (p)-[:FRIENDS_WITH]-() } AS Connections;
```
**Result:**

| BridgeCandidate | Connections |
|-----------------|-------------|
| Alice           | 2           |
| Charlie         | 2           |
| Frank           | 1           |

> Alice, Charlie, and Frank are bridge nodes — their removal would fragment the graph.

---

## Exercise 5 – Recommendations

### 1. Friend recommendations for Alice (mutual-friend basis)
```cypher
MATCH (me:Person {name: 'Alice'})-[:FRIENDS_WITH]-(friend)-[:FRIENDS_WITH]-(potential:Person)
WHERE NOT (me)-[:FRIENDS_WITH]-(potential) AND me <> potential
RETURN potential.name AS RecommendedFriend,
       count(friend) AS MutualFriends,
       collect(friend.name) AS SharedFriendNames
ORDER BY MutualFriends DESC;
```
**Result:**

| RecommendedFriend | MutualFriends | SharedFriendNames  |
|-------------------|---------------|--------------------|
| Eve               | 2             | ["Bob", "Charlie"] |
| Diana             | 1             | ["Bob"]            |

> Eve is the top recommendation — she shares 2 mutual friends with Alice.

---

### 2. Interest-based person recommendation for Alice
```cypher
MATCH (me:Person {name: 'Alice'})-[:INTERESTED_IN]->(myInterest:Interest)
MATCH (other:Person)-[:INTERESTED_IN]->(myInterest)
WHERE me <> other
WITH other, count(myInterest) AS CommonInterests
MATCH (other)-[:INTERESTED_IN]->(theirInterest:Interest)
WHERE NOT EXISTS {
  MATCH (me:Person {name: 'Alice'})-[:INTERESTED_IN]->(theirInterest)
}
RETURN other.name AS Person, collect(DISTINCT theirInterest.name) AS SuggestedInterests, CommonInterests
ORDER BY CommonInterests DESC;
```
**Result:**

| Person  | SuggestedInterests        | CommonInterests |
|---------|---------------------------|-----------------|
| Charlie | (no new interests to add) | 1               |
| Eve     | ["Databases"]             | 1               |

> Eve could introduce Alice to Databases (from Alice's AI interest overlap with Eve).

---

### 3. Recommend interests to Bob
```cypher
MATCH (me:Person {name: 'Bob'})-[:FRIENDS_WITH]-(friend:Person)-[:INTERESTED_IN]->(i:Interest)
WHERE NOT EXISTS { MATCH (me)-[:INTERESTED_IN]->(i) }
RETURN i.name AS SuggestedInterest,
       count(friend) AS FriendsWhoLikeIt,
       collect(friend.name) AS RecommendedBy
ORDER BY FriendsWhoLikeIt DESC;
```
**Result:**

| SuggestedInterest   | FriendsWhoLikeIt | RecommendedBy        |
|---------------------|------------------|----------------------|
| AI                  | 2                | ["Alice", "Eve"]     |
| Databases           | 2                | ["Alice", "Charlie"] |
| Mobile Development  | 1                | ["Diana"]            |

> AI and Databases are jointly recommended by 2 friends each — strong signals for Bob's next interest.
