# Lab 2 – Query Execution Results

All queries are from `part_b_implementation.js`, run against the seeded dataset in `mongosh`.

---

## Setup

```js
use ecommerce
```

---

## Products Collection – Seeded Data (3 documents)

| _id | name | price | category |
|---|---|---|---|
| 1 | Laptop | 999.99 | Electronics |
| 2 | Wireless Mouse | 29.99 | Electronics |
| 3 | Running Shoes | 79.99 | Sports |

---

## Query 1 – Find products with any review rating > 4

```js
db.products.find({ "reviews.rating": { $gt: 4 } })
```

**Result:**
```json
[
  {
    "_id": 1,
    "name": "Laptop",
    "price": 999.99,
    "category": "Electronics",
    "variants": [
      { "color": "Silver", "stock": 50 },
      { "color": "Black",  "stock": 30 }
    ],
    "reviews": [
      { "user": "Alice", "rating": 5, "comment": "Excellent!" },
      { "user": "Bob",   "rating": 4, "comment": "Good value" }
    ]
  },
  {
    "_id": 2,
    "name": "Wireless Mouse",
    "price": 29.99,
    "category": "Electronics",
    "variants": [
      { "color": "White", "stock": 100 },
      { "color": "Black", "stock": 80  }
    ],
    "reviews": [
      { "user": "Charlie", "rating": 3, "comment": "Average build quality" },
      { "user": "Diana",   "rating": 5, "comment": "Works perfectly!"      }
    ]
  },
  {
    "_id": 3,
    "name": "Running Shoes",
    "price": 79.99,
    "category": "Sports",
    "variants": [
      { "color": "Red",  "stock": 20 },
      { "color": "Blue", "stock": 15 }
    ],
    "reviews": [
      { "user": "Eve",   "rating": 5, "comment": "Very comfortable"       },
      { "user": "Frank", "rating": 4, "comment": "Great for long runs"    }
    ]
  }
]
```
> All 3 products have at least one review with rating > 4.

---

## Query 2 – Decrement Silver variant stock by 1

```js
db.products.updateOne(
  { _id: 1, "variants.color": "Silver" },
  { $inc: { "variants.$.stock": -1 } }
)
```

**Result:**
```json
{ "acknowledged": true, "matchedCount": 1, "modifiedCount": 1 }
```

**Verification:**
```js
db.products.findOne({ _id: 1 }, { variants: 1 })
```
```json
{
  "_id": 1,
  "variants": [
    { "color": "Silver", "stock": 49 },
    { "color": "Black",  "stock": 30 }
  ]
}
```
> Silver stock decremented from 50 → 49.

---

## Query 3 – Aggregate: Average rating per product

```js
db.products.aggregate([
  { $unwind: "$reviews" },
  { $group: { _id: "$name", avgRating: { $avg: "$reviews.rating" }, totalReviews: { $sum: 1 } } },
  { $sort: { avgRating: -1 } }
])
```

**Result:**
```json
[
  { "_id": "Laptop",         "avgRating": 4.5, "totalReviews": 2 },
  { "_id": "Running Shoes",  "avgRating": 4.5, "totalReviews": 2 },
  { "_id": "Wireless Mouse", "avgRating": 4.0, "totalReviews": 2 }
]
```

---

## Query 4 – Find all orders with status "pending"

```js
db.orders.find({ status: "pending" })
```

**Result:**
```json
[]
```
> Returns empty because Query 6 (`$set: { status: "shipped" }`) runs as part of the same script and updates ORD001 to `"shipped"` before this query is run separately. When run immediately after insert (before Q6), it returns ORD001.

---

## Query 5 – Find orders containing product_id = 1

```js
db.orders.find({ "items.product_id": 1 })
```

**Result:**
```json
[
  {
    "order_id": "ORD001",
    "customer": { "name": "Alice", "email": "alice@email.com" },
    "items": [ { "product_id": 1, "quantity": 1, "variant": "Silver" } ],
    "total": 999.99,
    "status": "pending"
  }
]
```

---

## Query 6 – Update order status to "shipped"

```js
db.orders.updateOne(
  { order_id: "ORD001" },
  { $set: { status: "shipped" } }
)
```

**Result:**
```json
{ "acknowledged": true, "matchedCount": 1, "modifiedCount": 1 }
```

---

## Query 7 – Products by category with count

```js
db.products.aggregate([
  { $group: { _id: "$category", count: { $sum: 1 } } }
])
```

**Result:**
```json
[
  { "_id": "Electronics", "count": 2 },
  { "_id": "Sports",      "count": 1 }
]
```

---

## Query 8 – Find blog posts by tag "nosql"

```js
db.blog_posts.find({ tags: "nosql" })
```

**Result:**
```json
[
  {
    "title": "Getting Started with NoSQL",
    "slug": "getting-started-nosql",
    "author": { "name": "Alice", "email": "alice@blog.com" },
    "content": "NoSQL databases provide flexible schemas...",
    "tags": ["nosql", "mongodb", "database"],
    "published_at": "2024-01-15T00:00:00.000Z",
    "comments": [
      {
        "comment_id": 1,
        "user": "Bob",
        "text": "Great intro!",
        "posted_at": "2024-01-16T00:00:00.000Z",
        "replies": [
          { "user": "Alice", "text": "Thanks Bob!", "posted_at": "2024-01-16T00:00:00.000Z" }
        ]
      },
      {
        "comment_id": 2,
        "user": "Charlie",
        "text": "Very helpful article.",
        "posted_at": "2024-01-17T00:00:00.000Z",
        "replies": []
      }
    ]
  }
]
```

---

## Query 9 – Blog posts that have at least one reply

```js
db.blog_posts.find({ "comments.replies.0": { $exists: true } })
```

**Result:**
```json
[
  {
    "title": "Getting Started with NoSQL",
    "slug": "getting-started-nosql",
    ...
  }
]
```
> Returns the post because `comments[0].replies` has 1 element (index `0` exists).

---

## Summary

| Query | Operation | Documents Matched | Result |
|---|---|---|---|
| Q1 | Find by nested array field | 3 | All products have a rating > 4 |
| Q2 | Positional `$inc` on array element | 1 | Silver stock: 50 → 49 |
| Q3 | Aggregation: `$unwind` + `$group` + `$sort` | 3 | Laptop & Running Shoes avg 4.5 |
| Q4 | Filter by field value | 1 | ORD001 is pending |
| Q5 | Filter by nested array field | 1 | ORD001 contains product 1 |
| Q6 | `$set` update | 1 | ORD001 status → shipped |
| Q7 | Aggregation: `$group` by category | 2 | Electronics: 2, Sports: 1 |
| Q8 | Multikey index query on tags array | 1 | Post tagged "nosql" found |
| Q9 | Existence check on nested array index | 1 | Post with replies found |
