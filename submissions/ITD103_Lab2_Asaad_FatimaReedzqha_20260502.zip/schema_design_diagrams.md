# Lab 2 – Schema Design Diagrams

## System 1: E-Commerce Product Catalog

### Design Decisions
| Sub-document | Strategy | Rationale |
|---|---|---|
| `variants` | **Embedded** | Always fetched with the product; small, bounded array |
| `reviews` | **Embedded** | Usually read alongside the product; bounded in size |
| `orders → product_id` | **Referenced** | Products change independently of orders |

---

### `products` Collection

```
┌──────────────────────────────────────────────┐
│ products                                     │
├──────────────────────────────────────────────┤
│ _id          : Number  (PK)                  │
│ name         : String                        │
│ price        : Number                        │
│ category     : String                        │
│                                              │
│ variants     : Array (EMBEDDED)              │
│   └── [ { color: String, stock: Number } ]   │
│                                              │
│ reviews      : Array (EMBEDDED)              │
│   └── [ { user: String,                      │
│            rating: Number,                   │
│            comment: String } ]               │
└──────────────────────────────────────────────┘
```

### `orders` Collection

```
┌──────────────────────────────────────────────┐
│ orders                                       │
├──────────────────────────────────────────────┤
│ order_id    : String  (PK)                   │
│ total       : Number                         │
│ status      : String                         │
│ created_at  : Date                           │
│                                              │
│ customer    : Object (EMBEDDED SNAPSHOT)     │
│   └── { name: String, email: String }        │
│                                              │
│ items       : Array                          │
│   └── [ { product_id: Number,  ─────────────┼──► products._id
│            quantity: Number,                 │
│            variant: String } ]               │
└──────────────────────────────────────────────┘
```

### Relationship Diagram

```
products (_id) ◄─────────────── orders.items[].product_id
     │
     ├── variants[]   (embedded)
     └── reviews[]    (embedded)

orders
     └── customer     (embedded snapshot – denormalized at write time)
```

---

## System 2: Blog Platform

### Design Decisions
| Sub-document | Strategy | Rationale |
|---|---|---|
| `author` | **Embedded snapshot** | Captures name/email at publish time; avoids broken references |
| `comments` | **Embedded array** | Read together with the post; bounded and hierarchical |
| `comments[].replies` | **Nested embedded array** | Replies are tightly coupled to their parent comment |
| `tags` | **Embedded string array** | Simple scalar values; queried efficiently with a multikey index |

---

### `blog_posts` Collection

```
┌──────────────────────────────────────────────────────────┐
│ blog_posts                                               │
├──────────────────────────────────────────────────────────┤
│ title        : String                                    │
│ slug         : String  (unique)                          │
│ content      : String                                    │
│ published_at : Date                                      │
│                                                          │
│ author       : Object (EMBEDDED SNAPSHOT)                │
│   └── { name: String, email: String }                    │
│                                                          │
│ tags         : Array<String>  (EMBEDDED)                 │
│   └── ["nosql", "mongodb", ...]                          │
│                                                          │
│ comments     : Array (EMBEDDED)                          │
│   └── [ { comment_id : Number,                           │
│            user       : String,                          │
│            text       : String,                          │
│            posted_at  : Date,                            │
│            replies    : Array (NESTED EMBEDDED)          │
│              └── [ { user      : String,                 │
│                       text      : String,                │
│                       posted_at : Date } ] } ]           │
└──────────────────────────────────────────────────────────┘
```

### Nesting Depth Visualization

```
blog_posts
├── author          (depth 1 – embedded object)
├── tags[]          (depth 1 – embedded array of strings)
└── comments[]      (depth 1 – embedded array of objects)
    └── replies[]   (depth 2 – nested embedded array)
```

---

## Embedding vs. Referencing: Decision Matrix

| Factor | Embed | Reference |
|---|---|---|
| Data always read together | ✅ | ❌ |
| Data changes independently | ❌ | ✅ |
| Bounded / small size | ✅ | — |
| Unbounded growth possible | ❌ | ✅ |
| Need atomic updates | ✅ | ❌ |
| Shared across many documents | ❌ | ✅ |
