# Lab 6: MongoDB Replication, Sharding & Monitoring

## Objectives
- Configure replica sets for high availability
- Implement sharding for horizontal scaling
- Monitor database performance

## Files
| File | Description |
|------|-------------|
| `part_a_replication.sh` | Start 3 mongod processes for replica set |
| `part_a_replication.js` | `rs.initiate()`, status checks, failover, write concern |
| `part_b_sharding.sh` | Start shards, config server, and mongos router |
| `part_b_sharding.js` | `sh.addShard()`, `sh.shardCollection()`, distribution check |
| `part_c_monitoring.js` | `currentOp`, `stats()`, `explain()`, query profiler |
| `query_results.md` | Expected output for all three parts with explanations |

---

## Architecture Overview

```
Replication (Part A):
  [Primary :27017] ←→ [Secondary :27018] ←→ [Arbiter :27019]

Sharding (Part B + C):
  Client → [mongos :27023] → [Config Server :27022]
                           → [Shard 1 :27020]
                           → [Shard 2 :27021]
```

---

## Part A – Replica Set

### Step 1 – Create data directories (run once)

```bash
mkdir -p ./data/rs1 ./data/rs2 ./data/rs3
```

### Step 2 – Start three mongod processes (3 separate terminals)

**Terminal 1 — Primary**
```bash
mongod --port 27017 --dbpath ./data/rs1 --replSet rs0 --bind_ip localhost
```

**Terminal 2 — Secondary**
```bash
mongod --port 27018 --dbpath ./data/rs2 --replSet rs0 --bind_ip localhost
```

**Terminal 3 — Arbiter** *(votes in elections, holds no data)*
```bash
mongod --port 27019 --dbpath ./data/rs3 --replSet rs0 --bind_ip localhost
```

### Step 3 – Initiate the replica set

Open a **4th terminal** and connect to port 27017:

```bash
mongosh --port 27017
```

Then run the JS file:

```bash
mongosh --port 27017 --file itd103-labs/lab4-6-mongodb/lab6/part_a_replication.js
```

Or paste individual commands from `part_a_replication.js` interactively.

### Step 4 – Verify replica set status

```js
rs.status()    // shows PRIMARY / SECONDARY / ARBITER roles
rs.conf()      // shows configuration (priority, votes, arbiterOnly)
rs.isMaster()  // confirms which node is primary
```

### Step 5 – Test replication (write → read on secondary)

**On primary (port 27017):**
```js
use replication_test
db.messages.insertOne({ msg: "Hello from primary", ts: new Date() })
```

**Open a new terminal, connect to secondary:**
```bash
mongosh --port 27018
```
```js
rs.secondaryOk()          // allow reads on secondary
use replication_test
db.messages.find()        // document should appear here
```

### Step 6 – Test failover

On the primary (port 27017):
```js
rs.stepDown()    // primary yields — triggers automatic re-election
rs.status()      // check which port became the new primary
```

Re-connect to the new primary if needed:
```bash
mongosh --port 27018   # (or whichever port shows stateStr: "PRIMARY")
```

### Step 7 – Write with majority concern

```js
use replication_test
db.messages.insertOne(
  { msg: "Durable write", ts: new Date() },
  { writeConcern: { w: "majority", wtimeout: 5000 } }
)
```

> `w: "majority"` blocks until the write is confirmed on at least 2 of the 3 members.

---

## Part B – Sharding

### Step 1 – Create data directories (run once)

```bash
mkdir -p ./data/shard1 ./data/shard2 ./data/config
```

### Step 2 – Start shard servers (4 separate terminals)

**Terminal 1 — Shard 1**
```bash
mongod --port 27020 --dbpath ./data/shard1 --shardsvr --bind_ip localhost
```

**Terminal 2 — Shard 2**
```bash
mongod --port 27021 --dbpath ./data/shard2 --shardsvr --bind_ip localhost
```

**Terminal 3 — Config Server** *(must be a replica set itself)*
```bash
mongod --port 27022 --dbpath ./data/config --configsvr --replSet configRS --bind_ip localhost
```

In a **new terminal**, initialize the config server replica set:
```bash
mongosh --port 27022
```
```js
rs.initiate({ _id: "configRS", configsvr: true, members: [{ _id: 0, host: "localhost:27022" }] })
```

**Terminal 4 — mongos Router**
```bash
mongos --port 27023 --configdb configRS/localhost:27022 --bind_ip localhost
```

### Step 3 – Run the sharding script

Connect via the mongos router (all shard operations go through here):

```bash
mongosh --port 27023 --file itd103-labs/lab4-6-mongodb/lab6/part_b_sharding.js
```

Or run commands interactively:
```bash
mongosh --port 27023
```

### Step 4 – Key commands to run and verify

```js
// Register shards with the cluster
sh.addShard("localhost:27020")
sh.addShard("localhost:27021")
sh.status()                          // confirm both shards appear

// Enable sharding on the database
sh.enableSharding("sharded_db")

// Shard the collection on customer_id
sh.shardCollection("sharded_db.orders", { customer_id: 1 })

// Switch to the database and insert 10,000 test documents
use sharded_db
// (paste the for-loop from part_b_sharding.js)

// Check data distribution across shards
db.orders.getShardDistribution()

// Verify query routing
db.orders.find({ customer_id: "CUST0500" }).explain("executionStats")  // targeted
db.orders.find({ amount: { $gt: 800 } }).explain("executionStats")     // scatter-gather
```

### Shard key options explained

| Strategy | Command | Best for |
|---|---|---|
| Range sharding | `{ customer_id: 1 }` | Range queries (`$gt`, `$lt`) |
| Hash sharding | `{ customer_id: "hashed" }` | Even distribution, random inserts |

---

## Part C – Performance Monitoring

### Connect to mongos (or primary for standalone replica set)

```bash
mongosh --port 27023
```

### Run the monitoring script

```bash
mongosh --port 27023 --file itd103-labs/lab4-6-mongodb/lab6/part_c_monitoring.js
```

### Key monitoring commands (run individually or copy from script)

**1. Current operations** — find slow/hung queries
```js
db.currentOp({ "active": true, "secs_running": { $gt: 1 } })
// db.killOp(<opid>)   // kill a specific operation if needed
```

**2. Database and collection stats**
```js
db.stats()             // database-level: collections, total docs, index sizes
db.orders.stats()      // collection-level: doc count, data size, index count
```

**3. Explain a query** — check if indexes are being used
```js
db.orders.find({ customer_id: "CUST0500" }).explain("executionStats")
// Look for: stage (IXSCAN = good, COLLSCAN = missing index)
//           executionTimeMillis, totalDocsExamined
```

**4. Index usage statistics**
```js
db.orders.aggregate([{ $indexStats: {} }])
// Shows: index name, number of times used (ops), and since when
```

**5. Query profiler** — log slow queries
```js
db.setProfilingLevel(1, { slowms: 100 })  // log queries > 100 ms
db.orders.find({ amount: { $gt: 900 } }).toArray()
db.system.profile.find().sort({ ts: -1 }).limit(5).pretty()
db.setProfilingLevel(0)                   // turn off when done
```

**6. Server status** — connections and memory
```js
const s = db.serverStatus()
printjson({ connections: s.connections, memory: s.mem, opcounters: s.opcounters, uptime: s.uptime })
```

**7. All collection sizes**
```js
db.getCollectionNames().forEach(name => {
  const s = db.getCollection(name).stats()
  print(`${name}: docs=${s.count}, dataSize=${s.size}B, indexSize=${s.totalIndexSize}B`)
})
```

---

## Quick-start Summary

| Part | Terminals needed | Entry point |
|------|-----------------|-------------|
| A – Replication | 4 (3 mongod + 1 mongosh) | `mongosh --port 27017` |
| B – Sharding | 5 (2 shard + 1 config + 1 mongos + 1 mongosh) | `mongosh --port 27023` |
| C – Monitoring | 1 (reuse Part B cluster) | `mongosh --port 27023` |

> **Tip:** Parts B and C share the same cluster. Start Part B first, then run Part C against the same mongos instance on port 27023 without restarting.

---

## Deliverables
- [x] Replica set configuration and `rs.status()` output → `query_results.md` Part A
- [x] Sharding implementation and `getShardDistribution()` output → `query_results.md` Part B
- [x] Performance monitoring report → `query_results.md` Part C
