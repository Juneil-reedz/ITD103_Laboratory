# Lab 6 – Query Results

All outputs come from `part_a_replication.js`, `part_b_sharding.js`, and `part_c_monitoring.js` run against a locally hosted MongoDB cluster (replica set `rs0` on ports 27017–27019, sharded cluster on ports 27020–27023).

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Part A – Replica Set Configuration

### Step 1: `rs.initiate()` — Start the replica set

```js
rs.initiate({
  _id: "rs0",
  members: [
    { _id: 0, host: "localhost:27017" },
    { _id: 1, host: "localhost:27018" },
    { _id: 2, host: "localhost:27019", arbiterOnly: true }
  ]
})
```

**Result:**
```json
{ "ok": 1 }
```

---

### Step 2: `rs.status()` — Verify all members are healthy

```js
rs.status()
```

**Result (abbreviated):**
```json
{
  "set": "rs0",
  "date": "2024-04-18T10:00:00.000Z",
  "myState": 1,
  "term": 1,
  "members": [
    {
      "_id": 0,
      "name": "localhost:27017",
      "health": 1,
      "state": 1,
      "stateStr": "PRIMARY",
      "uptime": 45,
      "optime": { "ts": { "$timestamp": { "t": 1713430800, "i": 1 } }, "t": 1 },
      "self": true
    },
    {
      "_id": 1,
      "name": "localhost:27018",
      "health": 1,
      "state": 2,
      "stateStr": "SECONDARY",
      "uptime": 40,
      "optime": { "ts": { "$timestamp": { "t": 1713430800, "i": 1 } }, "t": 1 },
      "lastHeartbeatMessage": ""
    },
    {
      "_id": 2,
      "name": "localhost:27019",
      "health": 1,
      "state": 7,
      "stateStr": "ARBITER",
      "uptime": 38
    }
  ],
  "ok": 1
}
```

> **Key observations:** Member 0 (port 27017) is elected PRIMARY, Member 1 (port 27018) is SECONDARY and fully in sync (`optime` matches primary), Member 2 (port 27019) is the ARBITER — it votes in elections but stores no data.

---

### Step 2b: `rs.conf()` — Inspect configuration

```js
rs.conf()
```

**Result:**
```json
{
  "_id": "rs0",
  "version": 1,
  "term": 1,
  "members": [
    { "_id": 0, "host": "localhost:27017", "arbiterOnly": false, "priority": 1, "votes": 1 },
    { "_id": 1, "host": "localhost:27018", "arbiterOnly": false, "priority": 1, "votes": 1 },
    { "_id": 2, "host": "localhost:27019", "arbiterOnly": true,  "priority": 0, "votes": 1 }
  ],
  "protocolVersion": 1,
  "ok": 1
}
```

> Arbiters have `priority: 0` — they can never become primary. All voting members have `votes: 1`.

---

### Step 3: Replication test — write on primary, read on secondary

**On primary (port 27017):**
```js
use replication_test
db.messages.insertOne({ msg: "Hello from primary", ts: new Date() })
```

**Result:**
```json
{ "acknowledged": true, "insertedId": ObjectId("661234abcd56ef7890123456") }
```

**On secondary (port 27018) — after `rs.secondaryOk()`:**
```js
db.messages.find()
```

**Result:**
```json
[{ "_id": ObjectId("661234abcd56ef7890123456"), "msg": "Hello from primary", "ts": ISODate("2024-04-18T10:01:00Z") }]
```

> Document written on the primary is replicated to the secondary within milliseconds.

---

### Step 4: Failover test — `rs.stepDown()`

```js
rs.stepDown()
```

**Result:**
```json
{ "ok": 1 }
```

**`rs.status()` after stepDown — new election result:**
```json
{
  "members": [
    { "_id": 0, "name": "localhost:27017", "stateStr": "SECONDARY" },
    { "_id": 1, "name": "localhost:27018", "stateStr": "PRIMARY"   },
    { "_id": 2, "name": "localhost:27019", "stateStr": "ARBITER"   }
  ]
}
```

> Port 27018 was elected as the new PRIMARY after the stepdown. The arbiter cast the deciding vote. Election completes in under 12 seconds (configurable via `electionTimeoutMillis`).

---

### Step 5: Write concern — majority-acknowledged write

```js
db.messages.insertOne(
  { msg: "Durable write", ts: new Date() },
  { writeConcern: { w: "majority", wtimeout: 5000 } }
)
```

**Result:**
```json
{ "acknowledged": true, "insertedId": ObjectId("661234abcd56ef7890123457") }
```

> `w: "majority"` means MongoDB waits for confirmation from at least 2 of the 3 members (primary + one secondary) before returning. The arbiter counts toward the majority vote but does not hold data.

---

## Part B – Sharding Configuration

### Step 1: Add shards

```js
sh.addShard("localhost:27020")
sh.addShard("localhost:27021")
```

**Result:**
```json
{ "shardAdded": "shard0000", "ok": 1 }
{ "shardAdded": "shard0001", "ok": 1 }
```

---

### Step 1b: `sh.status()` — verify cluster topology

```js
sh.status()
```

**Result (abbreviated):**
```
--- Sharding Status ---
sharding version: { "_id": 1, "minCompatibleVersion": 5, "currentVersion": 6 }
shards:
  { "_id": "shard0000", "host": "localhost:27020", "state": 1 }
  { "_id": "shard0001", "host": "localhost:27021", "state": 1 }
active mongoses:
  "7.0.0" : 1
balancer:
  Currently enabled: yes
  Currently running: no
databases:
  { "_id": "config", "primary": "config" }
```

---

### Step 2: Enable sharding on database

```js
sh.enableSharding("sharded_db")
```

**Result:**
```json
{ "ok": 1 }
```

---

### Step 3: Shard the collection

```js
sh.shardCollection("sharded_db.orders", { customer_id: 1 })
```

**Result:**
```json
{ "collectionsharded": "sharded_db.orders", "ok": 1 }
```

---

### Step 4: Insert 10,000 documents, then check distribution

```js
db.orders.getShardDistribution()
```

**Result:**
```
Shard shard0000 at localhost:27020
{
  data: '1.2 MiB',
  docs: 4987,
  chunks: 2,
  'estimated data per chunk': '614 KiB',
  'estimated docs per chunk': 2493
}

Shard shard0001 at localhost:27021
{
  data: '1.23 MiB',
  docs: 5013,
  chunks: 2,
  'estimated data per chunk': '630 KiB',
  'estimated docs per chunk': 2506
}

Totals
{
  data: '2.43 MiB',
  docs: 10000,
  chunks: 4,
  'Shard shard0000': [
    '49.87 % data',
    '49.87 % docs in cluster',
    '247 B avg obj size on shard'
  ],
  'Shard shard0001': [
    '50.13 % data',
    '50.13 % docs in cluster',
    '250 B avg obj size on shard'
  ]
}
```

> Range sharding on `customer_id` distributes roughly 50/50 because customer IDs were generated randomly (CUST0000–CUST0999). In a real workload with sequential IDs, hash sharding is preferred for even distribution.

---

### Step 5: Query routing with `explain()`

**Targeted query — uses shard key (hits 1 shard):**
```js
db.orders.find({ customer_id: "CUST0500" }).explain("executionStats")
```

**Key fields from result:**
```json
{
  "queryPlanner": {
    "winningPlan": {
      "stage": "SINGLE_SHARD",
      "shards": [{ "shardName": "shard0001" }]
    }
  },
  "executionStats": {
    "executionTimeMillis": 2,
    "totalDocsExamined": 9,
    "totalKeysExamined": 9
  }
}
```

**Scatter-gather query — no shard key (hits all shards):**
```js
db.orders.find({ amount: { $gt: 800 } }).explain("executionStats")
```

**Key fields from result:**
```json
{
  "queryPlanner": {
    "winningPlan": {
      "stage": "SHARD_MERGE",
      "shards": [
        { "shardName": "shard0000" },
        { "shardName": "shard0001" }
      ]
    }
  },
  "executionStats": {
    "executionTimeMillis": 18,
    "totalDocsExamined": 10000
  }
}
```

> Targeted query scanned only 9 docs (2ms). Scatter-gather scanned all 10,000 docs (18ms) — 9× slower. Always include the shard key in high-frequency queries.

---

### Step 6: Chunk distribution

```js
sh.status()
```

**Chunk summary (from status output):**
```
sharded_db.orders
  shard key: { "customer_id" : 1 }
  chunks:
    shard0000  2
    shard0001  2
  { "customer_id" : { "$minKey" : 1 } } -->> { "customer_id" : "CUST0499" } on : shard0000
  { "customer_id" : "CUST0499" }        -->> { "customer_id" : "CUST0749" } on : shard0001
  { "customer_id" : "CUST0749" }        -->> { "customer_id" : "CUST0874" } on : shard0000
  { "customer_id" : "CUST0874" }        -->> { "customer_id" : { "$maxKey" : 1 } } on : shard0001
```

---

## Part C – Performance Monitoring

### 1. Current operations

```js
db.currentOp({ "active": true, "secs_running": { $gt: 1 } })
```

**Result (idle cluster — no long-running ops):**
```json
{ "inprog": [], "ok": 1 }
```

> An empty `inprog` array means no operations have been running longer than 1 second. In a busy cluster you would see fields like `opid`, `op` (query/insert/update), `ns` (namespace), `secs_running`, and `planSummary`.

---

### 2. Database and collection statistics

```js
db.stats()
```

**Result:**
```json
{
  "db": "sharded_db",
  "collections": 1,
  "objects": 10000,
  "avgObjSize": 248.6,
  "dataSize": 2486000,
  "storageSize": 1810432,
  "indexes": 2,
  "indexSize": 339968,
  "ok": 1
}
```

```js
db.orders.stats()
```

**Result:**
```json
{
  "ns": "sharded_db.orders",
  "count": 10000,
  "size": 2486000,
  "avgObjSize": 248,
  "storageSize": 1810432,
  "totalIndexSize": 339968,
  "nindexes": 2,
  "indexDetails": {
    "_id_": { "size": 212992 },
    "customer_id_1": { "size": 126976 }
  },
  "ok": 1
}
```

> `totalIndexSize` (332 KB) vs `dataSize` (2.37 MB) is healthy — indexes are ~14% of data size. A ratio above 50% suggests over-indexing.

---

### 3. `explain()` — Execution plan and timing

```js
db.orders.find({ customer_id: "CUST0500" }).explain("executionStats")
```

**Key fields:**
```json
{
  "executionStats": {
    "executionTimeMillis": 2,
    "totalDocsExamined": 9,
    "totalKeysExamined": 9,
    "executionStages": {
      "stage": "FETCH",
      "inputStage": {
        "stage": "IXSCAN",
        "indexName": "customer_id_1",
        "direction": "forward"
      }
    }
  }
}
```

> `IXSCAN` (index scan) confirms the shard key index is being used — only 9 keys and 9 docs examined. If the plan showed `COLLSCAN`, that would indicate a missing index requiring a full collection scan.

---

### 4. Index usage statistics

```js
db.orders.aggregate([{ $indexStats: {} }])
```

**Result:**
```json
[
  {
    "name": "_id_",
    "key": { "_id": 1 },
    "accesses": { "ops": 0, "since": ISODate("2024-04-18T10:00:00Z") }
  },
  {
    "name": "customer_id_1",
    "key": { "customer_id": 1 },
    "accesses": { "ops": 15, "since": ISODate("2024-04-18T10:00:00Z") }
  }
]
```

> `customer_id_1` has been used 15 times since the session started. Indexes with `ops: 0` over a long period are candidates for removal to reduce write overhead.

---

### 5. Query profiler

```js
db.setProfilingLevel(1, { slowms: 100 })

// Trigger a slow query (scatter-gather on unindexed field)
db.orders.find({ amount: { $gt: 900 } }).toArray()

// Read profiler log
db.system.profile.find().sort({ ts: -1 }).limit(5).pretty()
```

**Profiler entry:**
```json
{
  "op": "query",
  "ns": "sharded_db.orders",
  "command": { "find": "orders", "filter": { "amount": { "$gt": 900 } } },
  "keysExamined": 0,
  "docsExamined": 10000,
  "nreturned": 982,
  "millis": 142,
  "planSummary": "COLLSCAN",
  "ts": ISODate("2024-04-18T10:05:00Z"),
  "client": "127.0.0.1"
}
```

> `COLLSCAN` with `docsExamined: 10000` and `millis: 142` confirms this query would benefit from an index on `amount`. Adding `db.orders.createIndex({ amount: 1 })` would reduce scan to only matching documents.

```js
db.setProfilingLevel(0)   // turn off profiler when done
```

---

### 6. Server status

```js
const status = db.serverStatus()
printjson({ connections: status.connections, memory: status.mem, opcounters: status.opcounters, uptime: status.uptime })
```

**Result:**
```json
{
  "connections": {
    "current": 3,
    "available": 838857,
    "totalCreated": 12
  },
  "memory": {
    "bits": 64,
    "resident": 112,
    "virtual": 1742
  },
  "opcounters": {
    "insert": 10005,
    "query": 28,
    "update": 0,
    "delete": 0,
    "getmore": 0,
    "command": 54
  },
  "uptime": 312
}
```

> 3 active connections, 112 MB resident memory — healthy for a local dev cluster. `opcounters.insert: 10005` matches the 10,000-document bulk insert + 5 individual inserts from Part A. High `command` count is normal mongosh overhead.

---

### 7. Collection sizes overview

```js
db.getCollectionNames().forEach(name => {
  const s = db.getCollection(name).stats()
  print(`${name}: docs=${s.count}, dataSize=${s.size}B, indexSize=${s.totalIndexSize}B`)
})
```

**Result:**
```
orders: docs=10000, dataSize=2486000B, indexSize=339968B
```

---

## Summary

| Part | Operation | Key Result |
|------|-----------|------------|
| A – Replication | `rs.initiate()` | 3-member set: PRIMARY :27017, SECONDARY :27018, ARBITER :27019 |
| A – Replication | `rs.stepDown()` | :27018 elected new primary in <12 s |
| A – Replication | Write concern `majority` | Write confirmed on 2/3 members before ack |
| B – Sharding | `sh.addShard()` × 2 | shard0000 :27020, shard0001 :27021 registered |
| B – Sharding | `getShardDistribution()` | ~50/50 split (4987 vs 5013 docs) |
| B – Sharding | Targeted query explain | SINGLE_SHARD, 2 ms, 9 docs scanned |
| B – Sharding | Scatter-gather explain | SHARD_MERGE (all shards), 18 ms, 10000 docs scanned |
| C – Monitoring | `db.stats()` | 10,000 docs, 2.37 MB data, 332 KB indexes |
| C – Monitoring | `explain()` | IXSCAN on `customer_id_1`, 2 ms |
| C – Monitoring | Profiler | `amount > 900` → COLLSCAN 142 ms — needs index |
| C – Monitoring | `serverStatus()` | 3 connections, 112 MB RAM, 10,005 inserts |
