# Lab 15 – Query Results

All outputs come from running `lab15_rag_basic.py`, `lab15_rag_advanced.py`, and `lab15_evaluation.py` using the `datasets/articles.csv` corpus (10 articles) and FAISS for retrieval. The scripts use OpenAI GPT when `OPENAI_API_KEY` has quota, and fall back to retrieved-context answers when OpenAI is unavailable.

## How to Preview This File

Open `query_results.md` in Visual Studio Code, then press `Ctrl + Shift + V` to view the Markdown preview.

You can also right-click the file tab and choose `Open Preview`.

---

## Exercise 1 – Basic RAG Pipeline

### System setup

```
Embedding model: all-MiniLM-L6-v2 (384-dim)
Generation: gpt-3.5-turbo or offline context fallback
FAISS index: IndexFlatL2 (10 vectors)
Top-K retrieval: 3
```

### Query 1

```
Question: How can I improve database query performance?
------------------------------------------------------------
Retrieved context:
  [0.612] SQL Optimization (Database)
  [0.407] GraphQL vs REST (API)
  [0.385] MongoDB Tutorial (Database)

Answer:
Based on the retrieved articles, techniques to optimize SQL query performance include proper indexing strategies, query execution plan analysis, avoiding N+1 queries, using database caching, and normalizing or denormalizing data structures based on read and write patterns.
```

### Query 2

```
Question: What are the benefits of regular exercise?
------------------------------------------------------------
Retrieved context:
  [0.455] Healthy Eating Habits (Health)
  [0.431] Mental Health Awareness (Health)
  [0.384] Renewable Energy (Science)

Answer:
Based on the retrieved articles, nutrition plays a crucial role in overall health and well-being. A balanced diet rich in fruits, vegetables, lean proteins, and whole grains can prevent chronic diseases, boost energy levels, and improve mental health and cognitive function.
```

### Query 3

```
Question: What are the latest developments in artificial intelligence?
------------------------------------------------------------
Retrieved context:
  [0.523] Introduction to AI (Technology)
  [0.426] Python Programming (Programming)
  [0.383] Blockchain Technology (Technology)

Answer:
Based on the retrieved articles, artificial intelligence is transforming industries by enabling machines to learn from data, make decisions, and perform tasks that previously required human intelligence. Machine learning algorithms, neural networks, and deep learning are core components of modern AI systems.
```

---

## Exercise 2 – Advanced RAG

### Chunking and Re-ranking

```
Total chunks: 10
CrossEncoder re-ranker loaded.

Query: machine learning algorithms
  [Technology] Introduction to AI: Artificial Intelligence is transforming industries by enabling machines to learn...
  [Programming] Python Programming: Python is versatile for data science, web development, automation, and artificia...
  [Database] MongoDB Tutorial: Learn how to use MongoDB for modern applications. MongoDB is a document-oriented...
```

### Conversation Memory

```
User : What is machine learning?
Bot  : Artificial Intelligence is transforming industries by enabling machines to learn from data, make decisions, and perform tasks that previously required human intelligence. Machine learning algorithms, neural networks, and deep learning are core components of modern AI systems.

User : How does it relate to databases?
Bot  : Techniques to optimize SQL query performance include proper indexing strategies, query execution plan analysis, avoiding N+1 queries, using database caching, and normalizing or denormalizing data structures based on read and write patterns.

User : Can you give a concrete example?
Bot  : Artificial Intelligence is transforming industries by enabling machines to learn from data, make decisions, and perform tasks that previously required human intelligence.
```

### Streaming RAG

```
Streaming answer for: What are the best practices for database indexing?
------------------------------------------------------------
Techniques to optimize SQL query performance include proper indexing strategies, query execution plan analysis, avoiding N+1 queries, using database caching, and normalizing or denormalizing data structures based on read and write patterns. Learn how to use MongoDB for modern applications.
```

---

## Exercise 3 – Evaluation Metrics and Analysis

### Ground Truth Test Set

| ID | Question | Relevant Doc IDs |
|----|----------|------------------|
| 1 | How to optimize database queries? | [10, 3] |
| 2 | What are benefits of exercise? | [8, 4] |
| 3 | Latest AI developments | [1, 7, 9] |
| 4 | Climate change solutions | [2, 6] |
| 5 | Python programming tips | [7] |

### Per-query Results

```
Query 1: How to optimize database queries?
  Retrieved IDs : [10, 5, 3]  |  Relevant: [10, 3]
  P@3=0.67  R@3=1.00  F1=0.80  AnsRel=0.79  Faithfulness=0.47

Query 2: What are benefits of exercise?
  Retrieved IDs : [4, 8, 6]  |  Relevant: [8, 4]
  P@3=0.67  R@3=1.00  F1=0.80  AnsRel=0.40  Faithfulness=0.74

Query 3: Latest AI developments
  Retrieved IDs : [1, 7, 9]  |  Relevant: [1, 7, 9]
  P@3=1.00  R@3=1.00  F1=1.00  AnsRel=0.52  Faithfulness=0.60

Query 4: Climate change solutions
  Retrieved IDs : [2, 6, 8]  |  Relevant: [2, 6]
  P@3=0.67  R@3=1.00  F1=0.80  AnsRel=0.54  Faithfulness=0.44

Query 5: Python programming tips
  Retrieved IDs : [7, 10, 1]  |  Relevant: [7]
  P@3=0.33  R@3=1.00  F1=0.50  AnsRel=0.59  Faithfulness=0.64
```

### Aggregate Metrics

```
Mean scores:
  precision@3           : 0.6667
  recall@3              : 1.0000
  f1                    : 0.7800
  answer_relevance      : 0.5688
  faithfulness          : 0.5784
```

| Metric | Score | Analysis |
|--------|-------|----------|
| Precision@3 | 0.6667 | Good for a small corpus; most top-3 results are relevant |
| Recall@3 | 1.0000 | Excellent; all expected relevant documents were retrieved |
| F1 | 0.7800 | Good balance between precision and recall |
| Answer Relevance | 0.5688 | Moderate because offline fallback answers are context-heavy rather than synthesized |
| Faithfulness | 0.5784 | Moderate in offline mode; re-run with OpenAI quota for LLM-judge faithfulness |

---

## RAG Architecture Summary

```
User Query
    |
    v
[SentenceTransformer] all-MiniLM-L6-v2 -> 384-dim query vector
    |
    v
[FAISS Index] IndexFlatL2 -> Top-K documents/chunks
    |
    v
[CrossEncoder Re-ranker] advanced mode only
    |
    v
[Context Assembly] retrieved documents/chunks -> prompt
    |
    v
[OpenAI GPT or Offline Context Fallback] -> grounded answer
```

---

## Output Files Generated

| File | Description |
|------|-------------|
| `datasets/rag_evaluation_results.csv` | Per-query evaluation metrics |
| `optimization_recommendations.md` | Optimization recommendations |
| `performance_comparison_report.md` | Basic vs advanced RAG comparison |

---

## Deliverables

- Complete RAG system implementation: `lab15_rag_basic.py` and `lab15_rag_advanced.py`
- Evaluation metrics and analysis: `lab15_evaluation.py`, `datasets/rag_evaluation_results.csv`, and this report
- Optimization recommendations: `optimization_recommendations.md`
- Performance comparison report: `performance_comparison_report.md`
