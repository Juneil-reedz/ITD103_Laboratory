# Lab 15 – Performance Comparison Report

## Test Setup

- Dataset: `datasets/articles.csv`
- Corpus size: 10 articles
- Embedding model: `all-MiniLM-L6-v2`
- Vector index: FAISS `IndexFlatL2`
- Advanced retrieval: sentence chunks plus optional CrossEncoder re-ranking
- Generation mode used for verification: offline context fallback because OpenAI quota may be unavailable

## Implementation Comparison

| System | Retrieval Unit | Re-ranking | Generation | Best Use Case |
|--------|----------------|------------|------------|---------------|
| Basic RAG | Full article | No | GPT or context fallback | Simple document QA |
| Advanced RAG | Sentence chunk | Yes, when available | GPT streaming/chat or fallback | Multi-turn and higher precision QA |
| Evaluation Pipeline | Full article | No | GPT or context fallback | Metric tracking and regression checks |

## Evaluation Results

| Metric | Mean Score | Interpretation |
|--------|------------|----------------|
| Precision@3 | 0.6667 | About two of the top three retrieved documents are relevant on average |
| Recall@3 | 1.0000 | All expected relevant documents were found within top three |
| F1 | 0.7800 | Good retrieval balance for a small corpus |
| Answer Relevance | 0.5688 | Moderate semantic match between generated answers and user queries |
| Faithfulness | 0.5784 | Moderate in offline mode; GPT judge scoring was replaced by embedding similarity fallback |

## Observations

- Basic RAG is sufficient for the 10-article corpus and retrieves the expected category for most queries.
- Advanced RAG demonstrates chunking, re-ranking, conversation memory, and streaming behavior, but the short articles create only 10 chunks.
- Recall is perfect because relevant documents are generally in the top three results.
- Precision can improve by adding metadata filters, query expansion, or a larger labeled evaluation set.
- Faithfulness should be re-measured with OpenAI enabled because the offline fallback uses semantic similarity instead of an LLM judge.

## Recommendation

Use Basic RAG for this small lab dataset and keep Advanced RAG as the scalable design for larger documents. For production-style usage, add more documents, enable OpenAI generation, and compare results before and after CrossEncoder re-ranking.
