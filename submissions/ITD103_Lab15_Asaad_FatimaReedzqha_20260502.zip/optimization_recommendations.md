# Lab 15 – Optimization Recommendations

## Retrieval Quality

- Increase corpus size before tuning advanced indexes; the current 10-document dataset is useful for demonstration but too small for stable ranking conclusions.
- Use domain-specific query expansion for weak queries such as `benefits of exercise`, adding related terms like `health`, `well-being`, and `lifestyle`.
- Store document metadata such as category and source, then apply metadata filters when the user intent is clearly domain-specific.

## Chunking

- Keep sentence-based chunking for this dataset because the articles are short and each article currently produces one meaningful chunk.
- For larger documents, use 150-300 word chunks with 30-50 word overlap to preserve context across boundaries.
- Avoid very small chunks because they reduce answer faithfulness by removing supporting context.

## Re-ranking

- Use the CrossEncoder re-ranker for the top 10-20 FAISS candidates when latency allows.
- Skip re-ranking for very small datasets or low-latency demos because FAISS already retrieves relevant results quickly.
- Log both initial retrieval rank and final re-ranked rank to identify systematic ranking errors.

## Generation

- Keep the prompt instruction that answers must use only retrieved context to reduce hallucinations.
- Use low temperature (`0.1` to `0.3`) for factual answers.
- Keep the offline context fallback for lab reproducibility when OpenAI quota is unavailable.

## Evaluation

- Track Precision@3, Recall@3, F1, Answer Relevance, and Faithfulness after every retrieval/prompt change.
- Add more ground-truth questions per category to reduce variance from the small test set.
- Review low answer relevance cases manually because retrieved documents may be relevant even when wording differs from the query.
